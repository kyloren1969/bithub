package cs.test

import amit.common.file.PlaintextFileProperties
import cs.test.Config._
import mux.reflect.web._


object GenerateTradeClientHTML extends amit.common.file.TraitPlaintextFileProperties {  
  val propertyFile = "tradingEngineWebAutoGen.properties"
  val includeOnlyFile = read("includeOnlyFile", "tradingEngineWebAutoGen.crypto.properties")  
  val includeOnlyProps = new PlaintextFileProperties(includeOnlyFile)
  implicit val ignoreMethodStr = List( // these methods will not be in html
    ("exch.Exchange", "addOnOBChange"),
    ("exch.Exchange", "addOnTrade"),
    ("exch.Exchange", "addOnCreateBid"),
    ("exch.Exchange", "addOnCreateAsk"),
    ("exch.Exchange", "addOnCancelBid"),
    ("exch.Exchange", "addOnCancelAsk"),
    ("exch.Exchange", "addOnCloseBid"),
    ("exch.Exchange", "addOnCloseAsk"),
    ("exch.Wallet", "addOnConfDeposit"),
    ("exch.Wallet", "addOnUnconfDeposit")
  ).map{
    case (x, y) => (y, x) // need to fix this. Why do we need to reverse?
  }
  
  def main(args:Array[String]) { 
    println("Auto-Generating file")
    formClasses.foreach{o => cg.c :+= o}
    try {
      cg.pageTitle = "CS Admin All"
      cg.autoGenerateToFile(htmlFileName, htmlFileDir, prefixString)(ignoreMethodStr)    	
      //cg.pageTitle = "CS Admin Simple"
    } catch { case t:Throwable => t.printStackTrace } 
    finally System.exit(0)
  }
}



