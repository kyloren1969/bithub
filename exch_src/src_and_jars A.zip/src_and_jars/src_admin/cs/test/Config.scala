
package cs.test

import amit.common.file.TraitPlaintextFileProperties
import exch._
import mux.reflect.web.HTMLClientCodeGenerator
import scala.collection.mutable.{Set => MSet}

object Config extends TraitPlaintextFileProperties {
  lazy val propertyFile = "misc.properties"
  
  val formInfo = "No Info" // cs.util.Info.getInfo
  val formUrl = "/web"
  val htmlFileName = "index"
  val htmlFileDir = "website"
  val prefixString = ""
  
  // restricted methods (not allowed in web UI)
  val restrict:Array[String] = read("restrictMethods", "").split(";").filterNot(_.isEmpty) // Array("*.fiat.*")
  def toDo = read("toDo", "").split(';')
  
  lazy val formObjects:MSet[AnyRef] = MSet(
    BTC_RPCNode,
    BCH_RPCNode,
    Wallet,
    Exchange
    //BTC_Inspector,
    //BCH_Inspector,
  ) 

  lazy val cg = new HTMLClientCodeGenerator(
    formObjects.toList.sortWith{
      (l, r) => l.getClass.getCanonicalName < r.getClass.getCanonicalName
    }, 
    formUrl, formInfo, None, false, false
  )
  
  val formClasses:List[AnyRef] = Nil
}

///////////////////////////////////////////
///////////////////////////////////////////
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          
                                                                                                                                          

