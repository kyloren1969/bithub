package cs.test

import cs.datastructures.Currencies._
//import exch.WalletsMgr._
import exch._

object AutoStart {
  println("AutoStarting TECommonWeb [This is the main project]")
  val objectsToAutoStart  = List( // these need to be start for various things on app load
    Wallet,
    Exchange
//    Admin
//    cs.MarketINRBTC,
//    cs.MarketETHBTC,
//    cs.INR_BTC_TradeHandlersWrapper,
//    cs.ETH_BTC_TradeHandlersWrapper,
//    cs.LiveFeedWrapperINRBTC
  )
  mux.reflect.DefaultTypeHandler.addType[Amt[_]](
    classOf[Amt[_]], 
    string => ???, 
    amt => amt.toString
  )
  mux.reflect.DefaultTypeHandler.addType[Rate[_, _]](
    classOf[Rate[_, _]], 
    string => ???, 
    rate => rate.toString
  )
  mux.reflect.DefaultTypeHandler.addType[FeePercent[_]](
    classOf[FeePercent[_]], 
    string => ???, 
    fee => fee.toString
  )
  
  objectsToAutoStart.foreach{c =>
    amit.common.Util.doOnceNow(
      println(s" [${this.getClass.getName}] auto-started ${c.getClass.getCanonicalName}")
    )
  }
  
  println("\n MAIN THREAD DONE. PLEASE WAIT FOR APP TO LOAD\n")
}

//  /////////////////////////