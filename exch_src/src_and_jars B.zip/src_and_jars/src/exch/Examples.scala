
package exch

object Examples{
  Wallet.assignAddress("BCH", "alice", "first addr")
  Wallet.getUnconfDeposits("BCH", "alice", Long.MaxValue, 100, 0)
  
  Wallet.addOnConfDeposit("BCH", x => {
      //x.address
      //x.amt
      //x.info
      //x.userID
      // ....
    }
  ) 
  
  Exchange.createBid("INRBTC", "alice", 1.1, 20000)
  Exchange.addOnCancelAsk("INRBTC", x => {
      //x.id // orderID
      //x.origVol
      //x.rate
      //x.status
      //x.time
      //x.userID
      //x.vol
    }
  )
  Exchange.addOnCloseAsk("INRBTC", x => {
      //x.tradeID
      //x.id // orderID
      //x.origVol
      //x.rate// rate specified, NOT the rate actually used for trade
      //x.status
      //x.time
      //x.userID
      //x.vol // secondary currency ("BTC")
      //x.feeCollected
      //x.feePercent
      //x.fiat // primary currency ("INR")
      //x.rateUsed
    }
  )
  Exchange.addOnTrade("INRBTC", t => {
      //  t.id   tradeID
      //  t.vol  coin
      //  t.amt  fiat
      //  t.time
      //  t.avgRate
      //  t.maxRate
      //  t.minRate
      //  t.ordType // "Bid" or "Ask"
      //  t.initiator:UserID // who triggered
    }
  )
}

