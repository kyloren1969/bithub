
package exch

import cs.datastructures.Currencies._
import cs.datastructures.Transfers._
import cs.datastructures.Wallets._
import cs.wallet.CryptoWallet
import mux.coin.CoinTx
import mux.coin.Dest
import mux.coin.Util._
import mux.coin.bch.BitcoinCashSTx
import mux.coin.bch.BitcoinCashSUtil
import sh.bch.PrvKey_P2PKH_UAHF
import sh.btc.BitcoinS
import sh.btc.BitcoinS._
import sh.btc.DataStructures.TxIn
import sh.btc.DataStructures.TxOut
import sh.btc.PrvKey
import sh.btc.TxParser
import sh.ecc.ECCPrvKey
import sh.ecc.Util._


object BCH_CryptoWallet extends CryptoWallet(BCH_ExchangeWallet) {
  import $exchangeWallet._
  val $minConf = 1
  BCH_Notifier.defaultMinConfs = $minConf    
  def $addAddressToWatch(address: String) = BCH_Listener.addAddressToWatch(address, "exchwallet")
  def isValidAddress(address: String) = BitcoinS.isP2PKH_Address(address)
  protected def $addOnCoinReceive(onCoinReceive: mux.coin.Util.OnCoinReceive): Unit = 
    BCH_Listener.addOnCoinsReceive("exchwallet", onCoinReceive)
  def $getAddress(prvKey: BigInt): String = 
    new PrvKey_P2PKH_UAHF(ECCPrvKey(prvKey mod n, true), isMainNet).pubKey.address
  def getWatchedAddresses = BCH_Notifier.watchAddrMap.keys.toArray
  
  val $maxNoOfInputs = 250
  val $maxNoOfOutputs = 100  
  val $maxFeePerWithdraw = BigDecimal(0.01)  
  val $minChangeAmount:BD = BigDecimal(0.0001)

  // monitor code not there??
  def $pushTxAndMonitor(tx:CoinTx):TxHash = BCH_RPCNode.pushTx(tx.coinSerializeHex)

  val $maxFeePerByte = BigDecimal(0.00000050)
  val $minFeePerByte = BigDecimal(0.00000001)
  val $defaultFeePerByte = BigDecimal(0.00000010)
  
  // is it 1000 or 1024 below?
  def $estimateFeePerByte:Option[BD] = BCH_RPCNode.$optRPC.map(_.estimateSmartFee(6, false)/1000)
  def $computeApproxSize(ins:Seq[Spendable], outs:Seq[To]):Int = {
     /*
      * New formula for calculation:
      * 
      * Before signing, the tx has empty scriptSigs
      * 
      * For uncompressed keys, each scriptSig contains following data (taking from signing code):
      * 
      *       tx.ins(i).setScriptSig((sigBytes.size.toByte +: sigBytes) ++ (pubKey.bytes.size.toByte +: pubKey.bytes))
      *       
      * i.e., 1 byte representing signature sizes 
      * signature bytes (one r and one s value, DER encoded: average 71 bytes https://bitcoin.stackexchange.com/a/12556/2075) 
      * 1 byte representing pub key size
      * pub key bytes (pub key always 64 bytes+1 sign byte 0x04) total of 65 bytes
      * https://bitcoin.org/en/glossary/compressed-public-key
      * 
      * gives total of 65+1+71+1 = 138 bytes for scriptSig (uncompressed)
      * gives total of 33+1+71+1 = 106 bytes for scriptSig (compressed)
      * 
      * 
      * formula for ACTUAL signed signature is 
      * 
      *   size of unsigned tx
      * + number of inputs * 106 (scriptSig)
      * 
      *   
      */
    val numOuts = outs.size + 1 // always assume change
    val extraSignedSize = ins.size*106
    val dummySCs = ins.map{in => new In(in.txID, in.vOut)}
    val dummyDests = outs.map(out => Dest(out.address, 0)).toArray // dummy value because we dont care about data, just size
    val txUnsignedSize = BitcoinCashSUtil.createGenericTx(
      dummySCs, 
      dummyDests :+ dummyDests(0)
    ).tx.size // dummy change
    txUnsignedSize + extraSignedSize
    // to check BCH formula. This is pretty much the BTC formula
  }
  def $createSignedTx(insKeys:Seq[(Spendable, PrivKeyInt)], outs:Seq[To]):CoinTx = {
    val (ins, keys) = insKeys.unzip
    val txIns = ins.map(in => new TxIn(in.txID, in.vOut))
    val txOuts = outs.map(out => new TxOut(out.address, $cur.toSmallestUnit(out.amt)))
    val unsignedBytes = BitcoinS.createTxRaw(txIns, txOuts)
    val signingDetails = insKeys.map{
      case (in, key) => (BitcoinCashSUtil.getKeyFromIntCompressed(key.bigInteger).prvKey, $cur.toSmallestUnit(in.amt))
    }    
    val signedBytes = BitcoinS.signTx(unsignedBytes, signingDetails)
    BitcoinCashSTx(new TxParser(signedBytes).getTx)
  }
}
