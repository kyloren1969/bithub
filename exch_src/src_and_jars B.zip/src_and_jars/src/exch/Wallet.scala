package exch

import cs.datastructures.Users._
import cs.datastructures.Currencies._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Transfers._
import cs.datastructures.Wallets._
import java.util.concurrent.atomic.AtomicInteger
object Foo  extends App {
  try {
    Wallet.getWallets//.foreach(println)
    Thread.sleep(10000)
    println("Wallet.getWallets")
    println("Resp: ")
    Wallet.getWallets.foreach(println)
    println("end")
  } catch {
    case e:Any =>
      e.printStackTrace
  } finally System.exit(1)
}
object Wallet {
  import WalletsMgr._
  import ExchangeMgr._
  import Exchange._ 
   
  def getWallets = wallets.values.map{w => w.$cur}.toArray
  //  def getInfo = {
  //    Array("Wallets") ++ getWallets ++ 
  //    Array("Markets") ++ getMarkets
  //  }
  def newDeposit(cur:String, userID:String, receivedAmt:BD, depositFee:BD, externalID:String, info:String, sender:String) = getWallet(cur).newDeposit(userID, receivedAmt, depositFee, externalID, info, sender)  
  def newWithdraw(cur:String, userID:String, amtToSend:BD, withdrawFee:BD, externalID:String, info:String, receiver:String) = getWallet(cur).newWithdraw(userID, amtToSend, withdrawFee, externalID, info, receiver) 
  def getDeposits(cur:String, userID:UserID, to:Time, max:Int, offset:Long) = getWallet(cur).getDeposits(userID, to, max, offset)
  def getWithdraws(cur:String, userID:UserID, to:Time, max:Int, offset:Long) = getWallet(cur).getWithdraws(userID, to, max, offset)  
  def getDeposit(cur:String, userID:UserID, id:TransferID) = getWallet(cur).getDeposit(userID, id)
  def getWithdraw(cur:String, userID:UserID, id:TransferID) = getWallet(cur).getWithdraw(userID, id)  
  @deprecated("Does not have caching added yet.", "28 Nov 2017")
  def getBalance(cur:String, userID:String) = getWallet(cur).getBalance(userID)
  def getTotalBalance(cur:String) = getWallet(cur).getTotalBalance 
  def create(cur:String, userID:String) = getWallet(cur).createWallet(userID)
  def exists(cur:String, userID:String) = getWallet(cur).existsWallet(userID)
  
  def getLockedBalances(userID:String):Map[CurrencySymbol, LockedBal] = {
    markets.toArray.flatMap{
      case (market, (_th, te, _feed)) =>
        val fiatSym = te.$fiatWallet.$cur.symbol
        val coinSym = te.$coinWallet.$cur.symbol
        val lockedFiat = te.getLockedAmtBids(userID)
        val lockedCoin = te.getLockedAmtAsks(userID)
        Array(
          fiatSym -> (market, lockedFiat),
          coinSym -> (market, lockedCoin)
        )
    }.groupBy{
      case (curSym, (market, lockedAmt)) => curSym 
    }.map{
      case (curSym, array) => 
        curSym -> LockedBal(
          array.map{
            case (_curSym, (market, lockedAmt)) => (market, lockedAmt)
          }.toMap
        )
    }
  }
  
  def getUnlockedBalances(userID:String):Map[CurrencySymbol, BD] = {
    wallets.map{
      case (wallet, w) => wallet -> w.$getBalance(userID).map(_.amt).getOrElse(BigDecimal(0))
    }.toMap
  }

  def getBalances(userID:String):Array[TotalBal] = {
    val lockedBals:Map[CurrencySymbol, LockedBal] = getLockedBalances(userID)
    val unlockedBals:Map[CurrencySymbol, BD]  = getUnlockedBalances(userID)    
    unlockedBals.map{
      case (cur, amt) => 
        val lockedBal = lockedBals.get(cur).getOrElse(throw new Exception(s"Locked balance not found for $cur")) // should never happen
        TotalBal(cur, amt, lockedBal)
    }.toArray
  }
  
  def assignAddress(cur:String, userID:String, label:String) = getCryptoWallet(cur).assignAddress(userID:String, label:String)
  def generateOfflineAddresses(cur:String, max:Int, seed:String, password:String) = getCryptoWallet(cur).generateOfflineAddresses(max:Int, seed:String, password)
  def getUserID(cur:String, address:String):Option[String] = getCryptoWallet(cur).getUserID(address:String)
  def assignTopUpAddress(cur:String, label:String) = getCryptoWallet(cur).assignTopUpAddress(label:String)
  def getWatchedAddresses(cur:String) = getCryptoWallet(cur).getWatchedAddresses
  
  //// deposit
  def getUnconfDeposits(cur:String, userID:String, to:Time, max:Int, offset:Long) = getCryptoWallet(cur).getUnconfDeposits(userID:String, to:Time, max:Int, offset:Long)
  def newUnconfDeposit(cur:String, addr:String, txid:String, vOut:Int, amount:BD) = getCryptoWallet(cur).newUnconfDeposit(addr:String, txid:String, vOut:Int, amount:BD)

  val $int = new AtomicInteger(0)
  def addOnUnconfDeposit(cur:String, f:SimpleTransfer => Unit) = getCryptoWallet(cur).$unconfDepositHandler.addOn($int.incrementAndGet, f)
  def addOnConfDeposit(cur:String, f:SimpleTransfer => Unit) = getWallet(cur).$depositHandler.addOn($int.incrementAndGet, f)
  
  //// withdraws
  def getCompletedWithdraws(cur:String, userID:String, to:Long, max:Int, offset:Long) = getCryptoWallet(cur).getCompletedWithdraws(userID, to, max, offset)
  def getVerifiedWithdraws(cur:String, userID:String, to:Long, max:Int, offset:Long) = getCryptoWallet(cur).getVerifiedWithdraws(userID, to, max, offset)
  def getUnverifiedWithdraws(cur:String, userID:String, to:Long, max:Int, offset:Long) = getCryptoWallet(cur).getUnverifiedWithdraws(userID, to, max, offset)
  def getCanceledWithdraws(cur:String, userID:String, to:Long, max:Int, offset:Long) = getCryptoWallet(cur).getCanceledWithdraws(userID, to, max, offset)
  def loadSeed(cur:String, seed:String) = getCryptoWallet(cur).loadSeed(seed)
  def unloadSeed(cur:String, seedHash:String) = getCryptoWallet(cur).unloadSeed(seedHash)
  def getLoadedSeedHashes(cur:String) = getCryptoWallet(cur).getLoadedSeedHashes
  def markWithdrawsAsComplete(cur:String, withdrawIDs:Array[TransferID], internalTxID:String, info:String) = getCryptoWallet(cur).markWithdrawsAsComplete(withdrawIDs, internalTxID, info)
  def verifyWithdraw(cur:String, userID:UserID, withdrawID:TransferID) = getCryptoWallet(cur).verifyWithdraw(userID:UserID, withdrawID:TransferID)
  def cancelWithdraw(cur:String, userID:UserID, withdrawID:TransferID, info:String, canceledBy:String) = getCryptoWallet(cur).cancelWithdraw(userID, withdrawID, info, canceledBy)
  def getAvailableFunds_NoSeed(cur:String, maxRows:Int) = getCryptoWallet(cur).getAvailableFunds_NoSeed(maxRows:Int)
  def getAvailableFunds(cur:String, maxRows:Int) = getCryptoWallet(cur).getAvailableFunds(maxRows:Int)
  def getAllVerifiedWithdraws(cur:String, maxRows:Int, maxAmt:BD) = getCryptoWallet(cur).getAllVerifiedWithdraws(maxRows:Int, 0, maxAmt)
}
