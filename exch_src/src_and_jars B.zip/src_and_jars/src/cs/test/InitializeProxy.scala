
package cs.test

import cs.test.Config._
//import cs.test.db.WebAccessDB
import javax.servlet.http.HttpServlet
import mux.reflect.DefaultTypeHandler
import mux.reflect.Proxy
//import cs.test.util.{TrustedBlockExplorer => Xmas}
//import mux.reflect.web.WebDataStructures.Req

class InitializeProxyServlet extends HttpServlet {
  InitializeProxy // refer to initialize object to start Proxy server
}
object InitializeProxy {
  //sh.btc.BitcoinS.isMainNet = false
  formObjects.foreach(Proxy.addProcessor(prefixString, _, DefaultTypeHandler, true))
  formClasses.foreach(Proxy.addProcessor(prefixString, _, DefaultTypeHandler, true))
  restrict.foreach(Proxy.preventMethod)
  println("\n LOADED FORM OBJECTS\n")
  //cs.frontend.AutoStart
  AutoStart
}








