package cs.wallet

import CryptoWalletUtil._
import amit.common.Util._
import cs.datastructures.Currencies._
import mux.coin._
import mux.coin.Util._
import mux.db.BetterDB._
import mux.db.core.DataStructures._
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.Numbers._
import cs.datastructures.Currencies._
import cs.datastructures.CommonDBCols._
import cs.util._
import cs.util.Common._
import cs.util.Transfers._
import cs.util.Users._
import cs.util.DBs._ // also for conversions between Rate and Amt to BigDecimal
import cs.datastructures.Exceptions._
import mux.db.core.FKDataStructures._

trait CryptoWalletDepositUTXO[C <: Cur] extends CryptoWalletAddress[C]{
  import $exchangeWallet._
  ////////////////////////////////////////////////////////////////////
  ////// Abstract method
  ////////////////////////////////////////////////////////////////////
  // this method is to be called to add a listener
  protected def $addOnCoinReceive(onCoinReceive:OnCoinReceive):Unit 
  
  val $unconfDepositHandler = new Handler[SimpleTransfer]
  val $minConf:Int
  
  // WARNING: Never delete from this DB
  protected val $confDepDB = Tab.withName(s"confDep_${$cur.symbol}").withConfig($dbconfig).withCols(
    addrCol, txidCol, vOutCol, $amountCol, timeCol // amount is in BigDecimal (BTC)
  ).withPriKey(txidCol, vOutCol)
  
  $confDepDB.addForeignKey(new Link(addrCol, $assignedDB.getTable, FkRule(Restrict, Restrict)))

  // Delete from below as funds are spent
  protected val $unspentDB = Tab.withName(s"unspent_${$cur.symbol}").withConfig($dbconfig).withCols(
    txidCol, vOutCol
  ).withPriKey(txidCol, vOutCol) 
  
  $unspentDB.addForeignKey(new Link(Array(txidCol, vOutCol), $confDepDB.getTable, FkRule(Restrict, Restrict))) 

  protected val $unconfDepDB = Tab.withName(s"unconfDep_${$cur.symbol}").withConfig($dbconfig).withCols(
    addrCol, txidCol, vOutCol, $amountCol, timeCol
  ).withPriKey(txidCol, vOutCol) 
  
  $unconfDepDB.addForeignKey(new Link(addrCol, $assignedDB.getTable, FkRule(Restrict, Restrict)))

  
  def getUnconfDeposits(userID:String, to:Time, max:Int, offset:Long) = {
    if (max > 100) throw new Exception(s"Max is 100")
    $unconfDepDB.select(
      userIDCol.of($assignedDB),  // userID
      constCol("None"),           // transferID
      txidCol,                    // externalID
      $amountCol,                 // amt
      constCol(0),                // fee
      addrCol,                    // senderOrReceiver
      vOutCol.castAs(STR),        // info
      timeCol
    ).where(
      addrCol === addrCol.of($assignedDB), 
      userIDCol.of($assignedDB) === userID,
      timeCol <= to 
    ).max(max).offset(offset).orderBy(timeCol.decreasing).as($toSimpleTransfer)
  }
  
  def newUnconfDeposit(addr:String, txid:String, vOut:Int, amount:BD) = {
    if ($unconfDepDB.exists(txidCol === txid, vOutCol === vOut)) throw new Exception("Already unconfirmed")
    if ($confDepDB.exists(txidCol === txid, vOutCol === vOut)) throw new Exception("Already confirmed")
    val time = getTime
    usingCount($unconfDepDB.insert(addr, txid, vOut, amount, time), "Unable to add unconfirmed deposit $txid:$vOut")
    getUserID(addr).map{userID =>
      $unconfDepositHandler.doOn(SimpleTransfer(userID, "none", txid+":"+vOut, amount, 0, addr, "unconfirmed deposit", time))  
    }    
    "Ok"
  }
  
  def confDeposit(txid:String, vOut:Int) = {
    if ($confDepDB.exists(txidCol === txid, vOutCol === vOut)) throw new Exception("Already confirmed")
    val (addr, amount) = $unconfDepDB.select(addrCol, $amountCol).where(
      txidCol === txid, vOutCol === vOut
    ).as(
      a => (a(0).as[String], a(1).as[BD])
    ).headOption.getOrElse(throw new Exception("Unconfirmed deposit not found"))
    val time = getTime
    usingCount($confDepDB.insert(addr, txid, vOut, amount, time), s"Unable to add confirmed deposit $txid:$vOut")
    usingCount($unconfDepDB.deleteWhere(txidCol === txid, vOutCol === vOut), "Unable to delete unconfirmed deposit $txid:$vOut")
    // val userID = getUserID(addr)
    getUserID(addr).map{userID =>
      if (userID != topUpID) $exchangeWallet.newDeposit(userID, amount, 0, txid+":"+vOut, "confirmed depsit", addr)    
    }
    "Ok"
  }

  def $doOnCoinReceive(addr:Address, coins:Seq[SpendableCoins], conf:Conf) = {
    println("On coin receive triggered for address: "+addr)
    if (conf < $minConf) coins.foreach(coin => tryIt(newUnconfDeposit(addr, coin.tx_hash, coin.n, $cur.fromSmallestUnit(coin.value).amt)))
    else coins.foreach{coin => 
      tryIt(newUnconfDeposit(addr, coin.tx_hash, coin.n, $cur.fromSmallestUnit(coin.value).amt))
      tryIt(confDeposit(coin.tx_hash, coin.n))
    }
  }
  /// below is added to listener 
  $addOnCoinReceive($doOnCoinReceive)

}
