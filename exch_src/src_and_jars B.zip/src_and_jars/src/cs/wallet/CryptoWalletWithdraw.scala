
package cs.wallet

import CryptoWalletUtil._
import amit.common.Util._
import cs.datastructures.Currencies._
import mux.coin._
import java.util.concurrent.atomic.AtomicBoolean
import mux.coin.Util._
import mux.db.BetterDB._
import mux.db.DBManager
import mux.db.core.DataStructures._
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.Numbers._
import cs.datastructures.Currencies._
import cs.datastructures.Wallets._
import cs.datastructures.CommonDBCols._
import cs.util._
import cs.util.Common._
import cs.util.Transfers._
import cs.util.Users._
import cs.util.DBs._ // also for conversions between Rate and Amt to BigDecimal
import cs.datastructures.Exceptions._
import mux.db.core.FKDataStructures._

trait CryptoWalletWithdraw[C <: Cur] extends CryptoWalletAddress[C] {
  import $exchangeWallet._

  protected val $verifiedTimeCol = Col("verifiedTime", ULONG)
  protected val $isVerifiedCol = Col("verified", BOOL)
  protected val $internalTxIDCol = Col("internalTxID", STR)

  $withdrawHandler.addOn(-123, w => tryIt($pendingWithdrawDB.insert(w.id, false, w.time)))
  
  $preWithdrawHandler.addOn(-123, w => if (!isValidAddress(w.receiver)) 
    throw new Exception(s"Invalid address ${w.receiver}")
  )
  
  $preWithdrawHandler.addOn(-124, w => getUserID(w.receiver).map{userID =>
      if (w.userID == userID) throw new Exception(s"Cannot send to self: ${w.receiver}")
    }
  )

  val $verifiedWithdrawHandler = new Handler[SimpleTransfer]
  val $completedWithdrawHandler = new Handler[SimpleTransfer]
  val $canceledWithdrawHandler = new Handler[SimpleTransfer]
  
  // delete from below on completion
  protected val $pendingWithdrawDB = Tab.withName(s"pendingWithdraw_${$cur.symbol}").withConfig($dbconfig).withCols(
    transferIDCol, $isVerifiedCol, timeCol // verifiedTime (created time is in ExchangeWallet withdraw table)
  ).withPriKey(transferIDCol) 
  protected val $completedWithdrawDB = Tab.withName(s"completedWithdraw_${$cur.symbol}").withConfig($dbconfig).withCols(
    transferIDCol, 
    $internalTxIDCol, // not txID!
    $verifiedTimeCol, 
    infoCol, // txID
    timeCol // completedTime (created time is in ExchangeWallet withdraw table)
  ).withPriKey(transferIDCol) 

  protected val $canceledWithdrawDB = Tab.withName(s"canceledWithdraw_${$cur.symbol}").withConfig($dbconfig).withCols(
    transferIDCol, 
    $internalTxIDCol, // depositID
    infoCol, timeCol // rejectedTime (created time is in ExchangeWallet withdraw table)
  ).withPriKey(transferIDCol) 

  def getAllVerifiedWithdraws(maxRows:Int, minAmt:BD, maxAmt:BD) = {
    $withdrawDB.selectStar.where(
      transferIDCol === transferIDCol.of($pendingWithdrawDB),
      $amountCol <= maxAmt,
      $amountCol >= minAmt,
      $isVerifiedCol.of($pendingWithdrawDB) === true
    ).orderBy(timeCol.decreasing).max(maxRows).as($toSimpleTransfer).toArray
  }

  def markWithdrawsAsComplete(withdrawIDs:Array[TransferID], internalTxID:String, info:String) = {
    $pendingWithdrawDB.select(transferIDCol, constCol(internalTxID), timeCol, constCol(getTime), constCol(info)).where(
      transferIDCol in withdrawIDs, 
      $isVerifiedCol === true
    ).into($completedWithdrawDB)
    $pendingWithdrawDB.deleteWhere(
      transferIDCol in withdrawIDs, 
      $isVerifiedCol === true
    )
  }
  private val $unverifiedLock = new Object 
  def verifyWithdraw(userID:UserID, withdrawID:TransferID) = $unverifiedLock.synchronized{
    $pendingWithdrawDB.exists(
      transferIDCol === withdrawID, 
      $isVerifiedCol === false,
      transferIDCol === transferIDCol.of($withdrawDB),
      userIDCol.of($withdrawDB) === userID
    ) match {
      case true =>
        $getWithdraw(userID, withdrawID).map{w => 
          $pendingWithdrawDB.update($isVerifiedCol <-- true, timeCol <-- getTime).where(transferIDCol === withdrawID)            
          $verifiedWithdrawHandler.doOn(w.toSimpleTransfer)
          w.toSimpleTransfer
        }
      case _ => throw new Exception(s"No such unverified withdraw ID: $withdrawID")
    }
  }
  
  def cancelWithdraw(userID:UserID, withdrawID:TransferID, info:String, canceledBy:String) = $unverifiedLock.synchronized{
    $pendingWithdrawDB.exists(
      transferIDCol === withdrawID, 
      $isVerifiedCol === false,
      transferIDCol === transferIDCol.of($withdrawDB),
      userIDCol.of($withdrawDB) === userID
    ) match {
      case true =>
        usingCount($pendingWithdrawDB.deleteWhere(transferIDCol === withdrawID), s"Unable to delete pending withdrawID $withdrawID")
        $getWithdraw(userID, withdrawID).map{w =>        
          val dep = newDeposit(userID, w.amt.amt+w.fee.amt, 0, s"Reverse withdrawID $withdrawID", info, canceledBy)
          $canceledWithdrawDB.insert(transferIDCol, dep.id, info, getTime)
          $canceledWithdrawHandler.doOn(w.toSimpleTransfer)
          w.toSimpleTransfer
        }
      case _ => throw new Exception(s"No such unverified withdraw ID: $withdrawID")
    }
  }
    
  private def $getPendingWithdraws(userID:UserID, to:Long, max:Int, offset:Long, isVerified:Boolean) = {
    $withdrawDB.selectStar.where(
      timeCol <= to, 
      transferIDCol === transferIDCol.of($pendingWithdrawDB),
      $isVerifiedCol.of($pendingWithdrawDB) === isVerified
    ).orderBy(timeCol.decreasing).max(max).offset(offset).as($toSimpleTransfer)
  }
  
  private def $getWithdraws(userID:UserID, to:Long, max:Int, offset:Long, whichDB:DBManager) = {
    $withdrawDB.selectStar.where(
      timeCol <= to, 
      transferIDCol === transferIDCol.of(whichDB)
    ).orderBy(timeCol.decreasing).max(max).offset(offset).as($toSimpleTransfer)
  }
  
  def getVerifiedWithdraws(userID:String, to:Long, max:Int, offset:Long) = $getPendingWithdraws(userID, to, max, offset, true)
  def getUnverifiedWithdraws(userID:String, to:Long, max:Int, offset:Long) = $getPendingWithdraws(userID, to, max, offset, false)
  def getCompletedWithdraws(userID:String, to:Long, max:Int, offset:Long) = $getWithdraws(userID, to, max, offset, $completedWithdrawDB)
  def getCanceledWithdraws(userID:String, to:Long, max:Int, offset:Long) = $getWithdraws(userID, to, max, offset, $canceledWithdrawDB)
  
  private val $withdrawLock = new AtomicBoolean(false)
  protected def usingWithdrawLock[T](f: => T) = if ($withdrawLock.compareAndSet(false, true)) {
    try f
    finally $withdrawLock.set(false)
  } else throw new Exception("Send() is already locked by another process")
  
  def processWithdraws(maxRows:Int, minAmt:BD, maxAmt:BD) = usingWithdrawLock{
    // todo lock those withdraws
    val all = getAllVerifiedWithdraws(maxRows, minAmt, maxAmt)
    val offChainIDs = $processOffChainWithdraws(all)
    val (offChainCompleted, incomplete) = all.partition(w => offChainIDs.contains(w.id))
    val onChainCompleted = $processOnChainWithdraws(incomplete, (ids, internalID, txID) => markWithdrawsAsComplete(ids, internalID, txID)).toArray.flatMap{
      case (completedIDs, txID) => incomplete.filter(w => completedIDs.contains(w.id)).map(_.setExternalID(txID))        
    }
    val allCompleted = onChainCompleted ++ offChainCompleted.map(_.setExternalID("offchain"))
    allCompleted.foreach($completedWithdrawHandler.doOn)
    allCompleted
  }
  // Do not make public, else we will have to implement locking
  private def $processOffChainWithdraws(withdraws:Array[SimpleTransfer]) = {
    val (offChain, onChain) = withdraws.map {w =>
      (w, getUserID(w.address))
    }.partition{
      case (w, optReceiverUserID) => optReceiverUserID.isDefined
    }
    val offChainWUsers = offChain.map{
      case (w, Some(receiverUserID)) => (w, receiverUserID)
      case _ => ??? // should not happen
    }
    val (offChainW, offChainUserIDs) = offChainWUsers.unzip
    val offChainWIDs = offChainW.map(_.id)

    if (offChainWUsers.nonEmpty) {
      val internalID = randomAlphanumericString(35)      
      markWithdrawsAsComplete(offChainWIDs, internalID, "offchain") // also invokes listeners?
      offChainWUsers map {
        case (w, receiverUserID) =>
          val deposit = newDeposit(
            receiverUserID, // offchain receiver userID
            w.amt, // amount
            0, // fee 
            internalID,  // externalID (use internalID as externalID)
            s"offchain ${w.id}", // info (add withdrawID)
            w.address // address (use address of receiver)
          )        
          $completedWithdrawDB.update($internalTxIDCol <-- deposit.id).where(transferIDCol === w.id)
      } 
    }
    offChainWIDs
  }
  
  protected var $seeds:Map[SeedHash, Seed] = Map()
  // add password
  def loadSeed(seed:Seed) = {
    val hash = getSeedHash(seed)
    if ($seeds.contains(hash)) throw new Exception("Seed already loaded with hash: "+hash)
    $seeds += (hash -> seed)
  }
  def unloadSeed(seedHash:SeedHash) = {
    $seeds -= seedHash
  }
  def getLoadedSeedHashes:Array[SeedHash] = {
    $seeds.keys.toArray
  }
  
  // Do not make public, else we will have to implement locking
  protected def $processOnChainWithdraws(
    withdraws:Array[SimpleTransfer], 
    doBeforeSend:(Array[TransferID], InternalID, ExternalID) => Unit
  ):Option[(Array[TransferID], ExternalID)]
  
  
}
