package cs.datastructures

import amit.common.json.JSONUtil.JsonFormatted
//import cs.util.Numbers._
import cs.util.Transfers._
import cs.util.Common._
import cs.util.Users._
import amit.common.Util._
import cs.datastructures.Currencies._
import cs.datastructures.Numbers._
import cs.datastructures.Users._
import scala.collection.mutable.{Set => MSet}

object Transfers {
  type TransferID = String
  type ExternalID = String
  type InternalID = String
  type SenderOrReceiver = String
  
  case class Transfer[C <: Cur](
    userID:String, id:TransferID, externalID:ExternalID, amt:Amt[C], fee:Amt[C], address:SenderOrReceiver, info:String, time:Time
  ) extends JsonFormatted {
    val keys = Array("userID", "id", "externalID", "amt", "fee", "address", "info", "time", "humanTime")
    val vals = Array(userID,    id,   externalID,   amt,   fee,   address,   info,   time,  toDateString(time))
    def toSimpleTransfer = SimpleTransfer(
      userID:String, id:TransferID, externalID:ExternalID, amt.amt, fee.amt, address:SenderOrReceiver, info:String, time:Time
    )
  
  }
  
  type WithdrawBlockChecks = MSet[(Int, UserID => Boolean)]
  
  case class SimpleTransfer(
    userID:String, id:TransferID, externalID:ExternalID, amt:BD, fee:BD, address:SenderOrReceiver, info:String, time:Time
  ) extends JsonFormatted {
    val keys = Array("userID", "id", "externalID", "amt", "fee", "address", "info", "time", "humanTime")
    val vals = Array(userID,    id,   externalID,   amt,   fee,   address,   info,   time,  toDateString(time))
    def setExternalID(newExternalID:String) = {
      new SimpleTransfer(
         userID:String, id:TransferID, newExternalID:ExternalID, amt:BD, fee:BD, address:SenderOrReceiver, info:String, time:Time
      )
    }
  }
}
