package cs.datastructures

import cs.datastructures.OrderBook._
import mux.db.core.DataStructures._

object CommonDBCols {
  
  val STR = VARCHAR(255)  
  val userIDCol = Col("userID", STR)  
  val timeCol = Col("time", ULONG)  
  val infoCol = Col("info", STR)
  val transferIDCol = Col("transferID", STR) // internal id
  val externalIDCol = Col("externalID", STR) // external reference id (e.g. tx ID, or bank deposit ID)  
  val senderOrReceiverCol = Col("senderOrReceiver", STR)

  // for orders
  val orderIDCol = Col("orderID", STR)
  
  // for trades (completed orders, )
  val tradeIDCol = Col("tradeID", STR)
  val isBidCol = Col("isBid", BOOL)  
  def toIsBid(ordType:OrdType) = ordType match {
    case Bid => true
    case Ask => false
    case _ => ??? // should never happen
  }
  def fromIsBid(isBid:Any) = isBid match {
    case true => Bid 
    case false => Ask
    case any => ??? // should never happen
  }
  
  val txidCol = Col("txid", STR)
  val vOutCol = Col("vOut", UINT) // Should it be ULONG (for ETH Nonce)
  val addrCol = Col("addr", STR)

}
