package cs.trade

import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.CommonDBCols._
import cs.util.Common._
import cs.util.DBs._
import cs.util.Users._
import amit.common.Util._
import mux.db.BetterDB._
import mux.db.core.DataStructures._
import scala.util.Try
import amit.common.file.TraitFilePropertyReader
import mux.db.config.TraitDBConfig
  
class TradeDB[Fiat <: Cur, Coin <: Cur](fiat:Fiat, coin:Coin)(implicit ev: Fiat =!= Coin) {
  type FIAT = Amt[Fiat]
  type COIN = Amt[Coin]
  type RATE = Rate[Fiat, Coin]
  type HISTORY = History[Fiat, Coin]
  type FIAT_VOL = FiatVol[Fiat, Coin]
  implicit val numericFiat = num(fiat) // for doing sum on fiat amount
  implicit val numericCoin = num(coin) // for doing sum on coin amount
  
  val market = s"${fiat.symbol}${coin.symbol}" 
  
  implicit val dbConfig:TraitDBConfig = new TraitDBConfig with TraitFilePropertyReader{
    val propertyFile = s"exchange_$market.properties"
    val dbname = read ("dbname", s"cs_exchange_$market")
    val dbuser = read ("dbuser", "cs")
    val dbpass = read ("dbpass", "eipoxj4i4xm4lmw")
    val dbhost = read ("dbhost", "localhost")
    val dbms = read ("dbms", "h2")
    //val dbms = read ("dbms", "postgresql")
    val connTimeOut = read("dbConnTimeOut", 2000)
    val usePool = read("usePool", true)
    val configSource = "file:"+propertyFile
  }

  val volType = UBIGDEC(coin.scale, coin.decimals)
  val fiatType = UBIGDEC(fiat.scale, fiat.decimals)
  val rateType = fiatType
  
  val volCol = Col("vol", volType)  
  val fiatCol = Col("fiat", fiatType)  
  val rateCol = Col("rate", rateType)  

  val feeType = UBIGDEC(2+feePercentMaxDecimals, feePercentMaxDecimals)
  val feePercentCol = Col("fee", feeType)  // max 99 % implies 3 digits
  
  val makerFeePercentCol = Col("makerFee", feeType)  // max 99 % implies 3 digits
  val takerFeePercentCol = Col("takerFee", feeType)  // max 99 % implies 3 digits

  val minRateCol = Col("minRate", rateType)  
  val maxRateCol = Col("maxRate", rateType)  
  val avgRateCol = Col("avgRate", rateType)  
  
  val rateUsedCol = Col("rateUsed", rateType)
  
  // add db config too
  val refUserIDCol = Col("refUserID", STR)
  val origVolCol = Col("origVol", volType)
  
  val orderCols =         Array(orderIDCol, userIDCol, rateCol, volCol, timeCol, origVolCol)
  val openCols:Cols =     orderCols ++ Array(makerFeePercentCol, takerFeePercentCol, refUserIDCol)

  val canceledCols:Cols = orderCols 
  
  val orderRecordCols:Cols =  Array( // user order from external, not internal (partial) orders
    orderIDCol, userIDCol, rateCol, volCol, timeCol, makerFeePercentCol, takerFeePercentCol, refUserIDCol, isBidCol
  )
  // orders fired by any user, for record and dispute purposes. Never deleted. 
  val userOrdersRecordDB = Tab(s"copy_UserOrder_${market}").withCols(
    orderRecordCols
  ).withPriKey(orderIDCol)
  
  // below userIDCol is the initiator of the trade
  val tradeCols:Cols = Array(
    tradeIDCol, volCol, fiatCol, timeCol, avgRateCol, maxRateCol, minRateCol, isBidCol //, userIDCol 
  ) /* In above, userIDCol represents the initiator */
  val tradeDB = Tab(s"trades_${market}").withCols(tradeCols).withPriKey(tradeIDCol)
  
  val prevVolCol = Col("prevVol", volType)
  
  val partialRecordCols:Cols = Array(
    tradeIDCol, orderIDCol, volCol, prevVolCol, timeCol
  )
  
  val tradedUserIDCol = Col("tradedUserID", STR) // for managing referrals (this userID is one who's fee was used)

  // orders fired by any user, for record and dispute purposes. Never deleted. 
  // No priKey for efficiency
  //val userOrdersRecordDB = Tab(s"copy_UserOrders_${market}").withCols(orderRecordCols).withPriKey()

  class OrderDB[Sold <:Cur, Bought <:Cur](val ordType:OrdType, soldCur:Sold, boughtCur:Bought) {
    implicit val numericBought = num(boughtCur) // for doing sum on coin amount
    
    if (ordType == Bid && soldCur != fiat) throw new Exception("Invalid configuration")
    val obRateOrder = if (ordType == Bid) rateCol.decreasing else rateCol.increasing
      
    val boughtType = UBIGDEC(boughtCur.scale, boughtCur.decimals)
    val feeCollectedCol = Col("feeCollected", boughtType)    
    val refPaidCol = Col("refPaid", boughtType)
    
    val openDB = Tab(s"open_ords_${market}_$ordType").withCols(openCols).withPriKey(orderIDCol)

    val closedCols:Cols = (tradeIDCol +: orderCols) ++ Array(feePercentCol, feeCollectedCol, fiatCol, rateUsedCol)
    
    val closedDB = Tab(s"closed_ords_${market}_$ordType").withCols(
      closedCols
    ).withPriKey(tradeIDCol, orderIDCol) 
    
    // for storing older data (say, older than 15 days)
    val closedArchiveDB = Tab(s"closedArchive_${market}_$ordType").withCols(
      closedCols
    ).withPriKey() // no primary key to ensure efficiency
    
    val canceledDB = Tab(s"canceled_ords_${market}_$ordType").withCols(canceledCols).withPriKey(orderIDCol) // .indexedBy(timeCol)
    
    // for storing older data (say, older than 15 days)
    val canceledArchiveDB = Tab(s"canceledArchive_${market}_$ordType").withCols(
      canceledCols
    ).withPriKey()//.indexedBy(timeCol, userIDCol) // no primary key to ensure efficiency, no indexing too ??
            
    val refPaidCols:Cols = Array(userIDCol, tradedUserIDCol, tradeIDCol, orderIDCol, refPaidCol, feePercentCol, timeCol) // feePercentCol represents ref fee percent
    val refPaidDB = Tab(s"refPaid_${market}_$ordType").withCols(refPaidCols).withPriKey(orderIDCol)
    
    import amit.common.Util._
    doHourly{
      val oldTime = getTime - (OneWeek * 2) // 2 weeks 
      Try{
        canceledDB.selectStar.where(timeCol < oldTime).into(canceledArchiveDB)
        canceledDB.deleteWhere(timeCol < oldTime)  
      }
      Try{
        closedDB.selectStar.where(timeCol < oldTime).into(closedArchiveDB)
        closedDB.deleteWhere(timeCol < oldTime)  
      }
    }
    
    // orders fired by any user, for record and dispute purposes. Never deleted. 
    // No priKey for efficiency
    
    // orders fired by internal ob (partial orders), for record and dispute purposes. Never deleted
    // No priKey for efficiency
    val partialOrdersRecordsDB = Tab(s"copy_PartialOrders_${market}_$ordType").withCols(
      partialRecordCols
    ).withPriKey()
  
    def putPartialRecord( // Record implies a permanent record for audit and dispute resolving
      tradeID:TradeID, orderID:OrderID, currVol:COIN, prevVol:COIN, time:Time
    ) = partialOrdersRecordsDB.insert(tradeID, orderID, currVol, prevVol, time)  
    
    def deleteOpen(id:OrderID) = usingCount(
      openDB.deleteWhere(orderIDCol === id), 
      s"Error deleting open order $id from $openDB"
    )
    def putCanceledOrd(
      userID:UserID, ordID:OrderID, rate:RATE, vol:COIN, time:Time, origVol:COIN
    ) = usingCount(
      canceledDB.insert(ordID, userID, rate, vol, time, origVol), 
      s"Error inserting new orderID $ordID in $canceledDB"
    )
    def putOpenOrd(
      userID:UserID, ordID:OrderID,
      rate:RATE, vol:COIN, time:Time, origVol:COIN, 
      makerFeePercent:FeePercent[Bought], takerFeePercent:FeePercent[Bought], refUserID:RefUserID
    ) = usingCount(
      //orderIDCol, userIDCol, rateCol, coinCol, timeCol, origVolCol, feePercentCol, refUserIDCol         
      openDB.insert (ordID, userID, rate, vol, time, origVol, makerFeePercent, takerFeePercent, refUserID.getOrElse("")), // empty string
      s"Error inserting new orderID $ordID in $openDB"
    )

    def updateOpen(ordID:OrderID, vol:COIN) = usingCount(
      openDB.update(volCol <-- vol.amt).where(orderIDCol === ordID),
      s"Error updating orderID $ordID in $openDB"
    )

    def recordOpenOrd(
      userID:UserID,  rate:RATE, vol:COIN, time:Time,
      makerFeePercent:FeePercent[Bought], takerFeePercent:FeePercent[Bought], refUserID:RefUserID
    ):OrderID = {
      
      // don't use 'usingCount' because below does not return 1, but rather the auto-incremented orderID
      val orderID = getPriKeyID(userOrdersRecordDB)
      userOrdersRecordDB.insert(
        orderID, userID, rate, vol, time, makerFeePercent, takerFeePercent, refUserID, toIsBid(ordType)
      )
      orderID
    }
    //tradeID, ordID, userID, rate, vol, fiat, time, origVol, feePercent, fees
    def putClosed(
      tradeID:TradeID, ordID:OrderID, userID:UserID, 
      rateSpecified:RATE, vol:COIN, time:Time, // rateUsed is computed from fiat and coin
      origVol:COIN, feePercent:FeePercent[Bought],
      feeCollected:Amt[Bought], fiat:FIAT, rateUsed:RATE
    ) = usingCount(
      //
      closedDB.insert(
        tradeID, ordID, userID, rateSpecified, vol, time, origVol, feePercent, feeCollected, fiat, rateUsed
      ), s"Error inserting complete order $ordID in ${closedDB.getTable}"
    )
    def putRefPaid(
      paidUserID:UserID, tradedUserID:UserID, tradeID:TradeID, ordID:OrderID, 
      refFeePercent:FeePercent[Bought],
      refShare:Amt[Bought], time:Time
    ) = { // not using usingCount ??
      refPaidDB.insert(paidUserID, tradedUserID, tradeID, ordID, refShare, refFeePercent, time)
      // what about depositID? 
      // refUtil.markRefPaid(refID, oldUserID, refRatio, userID, tradeID, ordID, depositID, refShare)
    }
    //////////////////////////////////////////////////
    // archive closed, canceled after 15 days
    //////////////////////////////////////////////////
    def getAllMemOpen = // memory orders (i.e., to load in OB, not for displaying to end users
      openDB.select(
        orderCols ++ Array(makerFeePercentCol, refUserIDCol)
      ).as(toMemOpen)
    
    def getMaxOrMinOrdIDs(userID:UserID, rate:RATE, op:Aggr) = {
      val leqOrGeq:Op = op match {
        case Max => Ge
        case Min => Le
        case _ => ??? // should not happen
      }
      MaxOrMin(rate, getOrdsForRate(userID, rate, leqOrGeq))
      //  getMaxOrMinRate(userID, op) match {
      //    case Some(rate) => MaxOrMin(rate, getOrdsForRate(userID, rate, leqOrGeq))
      //    case _ => throw EmptyOrderBookException
      //  }
    }
    private def getOrdsForRate(userID:UserID, rate:RATE, leqOrGeq:Op) = 
      openDB.select(orderIDCol).where(
        userIDCol === userID,
        Where(rateCol, leqOrGeq, rate)
      ).firstAsT[OrderID]
    
    
    def getMaxOrMinRate(userID:UserID, op:Aggr):Option[RATE] = try {
      val bdRate = openDB.aggregate(Aggregate(rateCol, op)).where(userIDCol === userID).firstAsBigDecimal
      Some(new Rate(bdRate, fiat, coin))
    } catch {case a:Any => None}
    
    // for displaying to users
    def getArchiveUserOrders(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      userOrdersRecordDB.select(
        orderIDCol, userIDCol, rateCol, volCol, timeCol
      ).where(
        timeCol <= to, 
        userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as{
        a =>  
        val vol = a(3) // origVol
        toOrd(a :+ vol)(Unknown)
      }
    }
    ///////////////////////////////////
    ///// CHECK BELOW 
    ///////////////////////////////////
    def getArchivePartialOrders(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      partialOrdersRecordsDB.select(
        orderIDCol, userIDCol, rateCol, volCol, timeCol
      ).where(
        timeCol <= to, userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toOrd(_)(Unknown))
    }
    def getOpenUserOrders(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      openDB.select(orderCols).where(
        timeCol <= to, userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toOrd(_)(Open))
    }
    def getCanceledUserOrders(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      canceledDB.select(orderCols).where(
        timeCol <= to, userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toOrd(_)(Canceled))
    }
    def getOpenOrders(to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      openDB.select(orderCols).where(
        timeCol <= to
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toOrd(_)(Open))
    }
    def getAllCanceledOrders(to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      canceledDB.select(orderCols).where(
        timeCol <= to
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toOrd(_)(Canceled))
    }

    //////////////////////////////////////////
    ///// Closed start
    //////////////////////////////////////////
    
    def getClosedUserOrders(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      closedDB.select(closedCols).where(
        timeCol <= to, userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toClosed)
    }

    def getClosedUserOrders(userID:UserID, orderID:OrderID) = {
      closedDB.select(closedCols).where(
        orderIDCol === orderID, userIDCol === userID
      ).as(toClosed)
    }

    def getClosedOrders(to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      closedDB.select(closedCols).where(
        timeCol <= to
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toClosed)
    }
    def getAllOpenOrders(max:Int) = ensuringMaxLimit(max) {
      openDB.select(orderCols).orderBy(obRateOrder).max(max).as(toOrd(_)(Open))
    }

    //    def getClosedOrdersAggr(userID:UserID, to:Time) = {
    //      closedDB.aggregate(orderIDCol, volCol.sum, feeCollectedCol.sum, fiatCol.sum, rateUsedCol.avg).where(
    //        timeCol <= to, userIDCol === userID
    //      ).groupBy(orderIDCol).asBigDecimal.map(toClosedAggr)
    //    }
    
    //    def getClosedOrdersNew(userID:UserID, to:Time) = {
    //      closedDB.aggregate(
    //        orderIDCol, 
    //        rateCol.max, 
    //        volCol.sum, 
    //        timeCol.max, 
    //        origVolCol.max, 
    //        feeCollectedCol.sum, 
    //        fiatCol.sum, 
    //        rateUsedCol.avg
    //      ).where(
    //        timeCol <= to, userIDCol === userID
    //      ).groupBy(orderIDCol).asBigDecimal.map(toClosedNew(_)(userID))
    //    }
    
//    def getClosedOrdersForID(userID:UserID, orderID:OrderID) = {
//      closedDB.select(closedCols).where(
//        orderIDCol === orderID, userIDCol === userID
//      ).as(toClosed)
//    }
//    
    //////////////////////////////////////////
    ///// Closed end
    //////////////////////////////////////////
    def getOpenOrder(orderID:OrderID) = {
      openDB.select(orderCols).where(
        orderIDCol === orderID
      ).as(toOrd(_)(Open)).headOption
    }

    def getOpenOrdersForID(userID:UserID, orderID:OrderID) = {
      openDB.select(orderCols).where(
        orderIDCol === orderID, userIDCol === userID
      ).as(toOrd(_)(Open))
    }
    def getCanceledOrdersForID(userID:UserID, orderID:OrderID) = {
      canceledDB.select(orderCols).where(
        orderIDCol === orderID, userIDCol === userID
      ).as(toOrd(_)(Canceled))
    }
    def getNumTrades(userID:UserID, to:Time) = closedDB.countWhere(userIDCol === userID, timeCol <= to)
    
    // "From" implies the trader, not the one gettig the ref. 
    def getRefsPaidFrom(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      refPaidDB.select(refPaidCols).where(
        timeCol <= to, tradedUserIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toRefPaid)
    }
    def getRefsPaidTo(userID:UserID, to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
      refPaidDB.select(refPaidCols).where(
        timeCol <= to, userIDCol === userID
      ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toRefPaid)
    }
    
    def getOrder(userID:UserID, orderID:OrderID):Option[OrigOrder[Fiat, Coin, Bought]] = { 
      val open = getOpenOrdersForID(userID, orderID).toArray
      val closed = getClosedUserOrders(userID, orderID).toArray
      val canceled = getCanceledOrdersForID(userID, orderID).toArray

      val all = open ++ closed ++ canceled

      // if (all.isEmpty) throw new Exception(s"No order(s) found with ID: $orderID")
      if (all.isEmpty) None else {
        val time = all.map(_.time).min
        val userIDs = all.map(_.userID).toSet
        val origVols = all.map(_.origVol)
        val origVolAmts = origVols.map(_.amt).toSet

        //println("-- uid start ")
        //userIDs.foreach(println)
        //println("-- uid end ")
        if (userIDs.size > 1) throw new Exception(s"Multiple userIDs matched. Expected 1. Found ${userIDs.size}")

        //println("-- origVols start ")
        //origVolAmts.foreach(println)
        //println("-- origVols end ")
        if (origVolAmts.size > 1) throw new Exception(s"Multiple origVols matched. Expected 1. Found ${origVolAmts.size}")

        val rateBD = all.map(_.rate.rate).toSet
        if (rateBD.size > 1) throw new Exception(s"Multiple rates matched. Expected 1. Found ${rateBD.size}")

        val rateSpecified = all.head.rate
        val userID = userIDs.head
        val origVol = origVols.head

        val closedVol = closed.map(_.vol).sum
        val closedFiat = closed.map(_.fiat).sum
        val closedFeeCollected = closed.map(_.feeCollected).sum
        val openVol = open.map(_.vol).sum
        val canceledVol = canceled.map(_.vol).sum

        val status:OrderStatus = 
          if (open.nonEmpty) Open 
          else if (canceled.nonEmpty) Canceled 
            else if (closed.nonEmpty) Closed 
              else Unknown

        Some(new OrigOrder(
          orderID, userID, rateSpecified, // rateSpec
          closedVol, openVol, canceledVol, time, // time
          closedFiat, closedFeeCollected, origVol,
          closed.map(_.tradeID), status
        ))
      }
    }
    
    private def toRefPaid(a:Array[Any]) = {
      val i = a.toIterator
      new RefPaid(
        asUserID(i.next),  // userID
        asUserID(i.next),  // tradedUserID
        asTradeID(i.next),
        asOrderID(i.next), // id
        new Amt(asBD(i.next), boughtCur),
        new FeePercent(asBD(i.next), boughtCur),
        asTime(i.next)
      )
    }

    @deprecated("Unused. Aggregates are bad because they don't support Max", "26 Nov 2017") 
    private def toClosedAggr(a:Array[Any]) = {
      val i = a.toIterator
      new ClosedAggr(
        asOrderID(i.next),  // orderID
        new Amt(asBD(i.next), coin), // vol
        new Amt(asBD(i.next), boughtCur), // feeCollected
        new Amt(asBD(i.next), fiat), // fiat
        new Rate(asBD(i.next), fiat, coin) // avgRate
      )
    }

    private def toOrd(a:Array[Any])(status:OrderStatus) = {
      val i = a.toIterator
      new Order[Fiat, Coin, Bought](
        asOrderID(i.next), // id
        asUserID(i.next),  // userID
        new Rate(asBD(i.next), fiat, coin),
        new Amt(asBD(i.next), coin), // vol
        asTime(i.next),
        new Amt(asBD(i.next), coin), // origVol
        status
      ){
        val keys = keysData
        val vals = valsData
      }
    }

    private def toClosed(a:Array[Any]) = {
      val i = a.toIterator
      new ClosedOrder[Fiat, Coin, Bought](
        asTradeID(i.next),        
        asOrderID(i.next),
        asUserID(i.next), 
        new Rate(asBD(i.next), fiat, coin),
        new Amt(asBD(i.next), coin), // vol
        asTime(i.next),
        new Amt(asBD(i.next), coin), // orig vol
        new FeePercent(asBD(i.next), boughtCur),
        new Amt(asBD(i.next), boughtCur), // fee collected
        new Amt(asBD(i.next), fiat),  // fiat
        new Rate(asBD(i.next), fiat, coin) // rate used
      )
    }

    //    @deprecated("Unused. Aggregates are bad because they don't support Max", "26 Nov 2017") 
    //    private def toClosedNew(a:Array[Any])(userID:String) = {
    //      val i = a.toIterator
    //      new ClosedOrderNew[Fiat, Coin, Bought](
    //        asOrderID(i.next),
    //        userID, 
    //        new Rate(asBD(i.next), fiat, coin),
    //        new Amt(asBD(i.next), coin), // vol
    //        asTime(i.next),
    //        new Amt(asBD(i.next), coin), // orig vol
    //        new Amt(asBD(i.next), boughtCur), // fee collected
    //        new Amt(asBD(i.next), fiat),  // fiat
    //        new Rate(asBD(i.next), fiat, coin) // rate used
    //      )
    //    }

    private def toMemOpen(a:Array[Any]) = {
      val i = a.toIterator
      new MemOpen[Fiat, Coin, Bought](
        asOrderID(i.next), // id
        asUserID(i.next),  // userID
        new Rate(asBD(i.next), fiat, coin),
        new Amt(asBD(i.next), coin),
        asTime(i.next),
        new Amt(asBD(i.next), coin), // orig vol
        new FeePercent(asBD(i.next), boughtCur),
        asOptString(asUserID(i.next))
      )
    }
  }
  
  def ensuringMaxLimit[T](max:Int)(f: => T) = {
    if (max <= MaxLimit) f else throw new Exception(s"Max must be <= $MaxLimit. Currently $max")
  }
  private def asOptString(s:String) = if (s.isEmpty) None else Some(s)
  
  val bidsDB = new OrderDB(Bid, fiat, coin) // last is currency in which fee is collected, currency bought
  val asksDB = new OrderDB(Ask, coin, fiat) // last is currency in which fee is collected, currency bought
  
  def getLowestBidRate(userID:UserID) = bidsDB.getMaxOrMinRate(userID, Max)

  def getHighestAskRate(userID:UserID) = asksDB.getMaxOrMinRate(userID, Min)

  def putTrade(
    coinTraded:COIN, fiatTraded:FIAT, time:Time, 
    avgRate:RATE, maxRate:RATE, minRate:RATE, ordType:OrdType
  ) = {
    // don't use usingCount because this is supposed to return the auto-incremented id
    val tradeID = getPriKeyID(tradeDB)
    usingCount(
      tradeDB.insert(tradeID, coinTraded, fiatTraded, time, avgRate, maxRate, minRate, toIsBid(ordType)), 
      s"Error inserting trade [vol:$coinTraded,fiat:$fiatTraded,time:$time,ordType:$ordType] in ${tradeDB.getTable}"
    )
    tradeID
  }
  
  def getTrades(to:Time, max:Int, offset:Long) = ensuringMaxLimit(max) {
    tradeDB.select(tradeCols).where(
      timeCol <= to
    ).orderBy(timeCol.decreasing).max(max).offset(offset).as(toTrade)
  }
  def getTrade(tradeID:TradeID) = {
    tradeDB.select(tradeCols).where(
      tradeIDCol === tradeID
    ).as(toTrade).headOption
  }
  def getTrades(tradeIDs:Array[TradeID]) = {
    tradeDB.select(tradeCols).where(
      tradeIDCol in tradeIDs
    ).as(toTrade)
  }
  def getTradeAggregateHistory(from:Time, to:Time, interval:Time):List[HISTORY] = {
    tradeDB.aggregate(
      minRateCol.min, maxRateCol.max, avgRateCol.avg, fiatCol.sum, volCol.sum, timeCol.top, avgRateCol.first, avgRateCol.last, tradeIDCol.count    
    ).where(
      timeCol >= from, timeCol <= to
    ).groupByInterval(timeCol \ interval).asBigDecimal.map(toHistory)
  }

  def getAllNumTrades(to: Time) = 
    tradeDB.countWhere(timeCol <= to)
  
  def getAllNumTradesOfType(to: Time, orderType:OrdType) = 
    tradeDB.countWhere(isBidCol === toIsBid(orderType), timeCol <= to)
    
  //  private def getAggr[T](to:Time, aggregates:Aggregates, func:Seq[BD] => T) = 
  //    func(tradeDB.aggregate(aggregates:_*).where(timeCol >= from, timeCol <= to).asBigDecimal.map(asBD))
  //  
  //  private def getAggrFiatVol(to:Time, aggr:Aggr):FIAT_VOL = 
  //    try getAggr(
  //      from, to, Array(Aggregate(fiatCol, aggr), Aggregate(volCol, aggr)),
  //      arr => FiatVol(new Amt(arr(0), fiat), new Amt(arr(1), coin))
  //    ) catch {
  //      case a:Any => FiatVol(new Amt(0, fiat), new Amt(0, coin))
  //    }
  //
  //  def getSumFiatVolByDate(to:Time):FIAT_VOL = getAggrFiatVol(from, to, Sum)
  //
  //  def getAvgFiatVolByDate(to:Time):FIAT_VOL = getAggrFiatVol(from, to, Avg)
  //
  //  def getMaxFiatVolByDate(to:Time):FIAT_VOL = getAggrFiatVol(from, to, Max)
  //
  //  def getMinFiatVolByDate(to:Time):FIAT_VOL = getAggrFiatVol(from, to, Min)
  //
  //  private def getAggrRate(to:Time, someRateCol:Col, aggr:Aggr):RATE = 
  //    getAggr(from, to, Array(Aggregate(someRateCol, aggr)), arr => new Rate(arr(0), fiat, coin))

  //db_getRecentData(fromMillis:Time):(FIAT_VOL, RATE, RATE) // Sum(FiatVol), maxRate, minRate
  def getAllData(from:Time, to:Time) = try {
    val a = tradeDB.aggregate(
      fiatCol.sum, volCol.sum, 
      avgRateCol.avg, 
      maxRateCol.max,
      minRateCol.min
    ).where(
      timeCol >= from, timeCol <= to
    ).asBigDecimal.map(
      asBD
    )
    val i = a.toIterator
    AggrData(
      FiatVol(new Amt(i.next, fiat), new Amt(i.next, coin)),
      new Rate(i.next, fiat, coin),
      new Rate(i.next, fiat, coin),
      new Rate(i.next, fiat, coin)      
    )
  } catch {
    case a:Any => 
      AggrData(
        FiatVol(zero(fiat), zero(coin)),
        zeroRate(fiat, coin),
        zeroRate(fiat, coin),
        zeroRate(fiat, coin)      
      )
  }
  //  def getMinRateByDate(to:Time):RATE = 
  //    try getAggrRate(from, to, minRateCol, Min) catch {case a:Any => zeroRate(fiat, coin)}
  //
  //  def getMaxRateByDate(to:Time):RATE = 
  //    try getAggrRate(from, to, maxRateCol, Max) catch {case a:Any => infiniteRate(fiat, coin)}
  
  private def toTrade(a:Array[Any]) = {
    val i = a.toIterator
    new TradeDetail[Fiat, Coin](
      asTradeID(i.next), // tradeID
      new Amt(asBD(i.next), coin),
      new Amt(asBD(i.next), fiat),
      asTime(i.next),
      new Rate(asBD(i.next), fiat, coin),
      new Rate(asBD(i.next), fiat, coin),
      new Rate(asBD(i.next), fiat, coin),
      fromIsBid(i.next)
    )    
  }
  
  private def toHistory(a:Array[Any]) = {
    val i = a.map(asBD).toIterator // all numbers
    new History(
      new Rate(i.next, fiat, coin),
      new Rate(i.next, fiat, coin),
      new Rate(i.next, fiat, coin),
      new Amt(i.next, fiat),
      new Amt(i.next, coin),
      asBD(i.next).toLong, // time
      new Rate(i.next, fiat, coin),
      new Rate(i.next, fiat, coin),
      asBD(i.next).toLong  // numTrades
    )
  }
}
