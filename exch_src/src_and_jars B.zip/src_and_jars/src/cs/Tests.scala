//
//package cs
//
//import exch._
//import exch.WalletsMgr._
//import cs.datastructures.Currencies._
//import cs.wallet.ExchangeWallet
//
//object TestRateAdd extends App {
//  val aa = Array(
//    (new Rate(1223.33, INR, BTC), new Amt(1.2, BTC)),
//    (new Rate(1223.34, INR, BTC), new Amt(2.2, BTC)),
//    (new Rate(1223.35, INR, BTC), new Amt(3.2, BTC)),
//    (new Rate(1223.36, INR, BTC), new Amt(4.2, BTC)),
//    (new Rate(1223.37, INR, BTC), new Amt(5.2, BTC)),
//    (new Rate(1223.38, INR, BTC), new Amt(6.2, BTC))
//  ).toIterator
//
//  val maxFiat = new Amt(100000.63, INR)
//  var accum = zero(INR)
//  var valid:List[(Amt[INR.type], Amt[INR.type], Rate[INR.type, BTC.type])] = Nil
//  while(accum < maxFiat && aa.hasNext) {
//    val a = aa.next
//    valid :+= (accum, {accum += a._1 * a._2; accum}, a._1)
//  }
//  println("Accum "+accum)
//  println
//  println("Valid "+valid.size)
//  valid foreach println
//  println
//  
//  val (completeTuple, tmpPartial) = 
//    valid.partition{case (startFiat, endFiat, rate) => endFiat <= maxFiat}
//
//  println("Complete "+completeTuple.size)
//  completeTuple foreach println
//  println
//  
//  println("Partial "+tmpPartial.size)
//  tmpPartial foreach println
//  println
//}
//object TestCur {
//  val x = new Rate(1223.3, INR, BTC)
//  val aa = Array(
//    new Rate(1223.313, INR, BTC),
//    new Rate(1223.313, INR, BTC),
//    new Rate(1223.313, INR, BTC),
//    new Rate(1223.313, INR, BTC),
//    new Rate(1223.313, INR, BTC),
//    new Rate(1223.313, INR, BTC)
//  ).toSet
//  println (" -------->aa "+aa.size)
//  println (" -------->aa1 "+(new Rate(1223.31, INR, BTC) compare new Rate(1223.32, INR, BTC)))
//  println (" -------->aa2 "+(new Rate(1223.32, INR, BTC) compare new Rate(1223.32, INR, BTC)))
//  println (" -------->aa3 "+(new Rate(1223.33, INR, BTC) compare new Rate(1223.32, INR, BTC)))
//  aa foreach println
//  println (" --------> "+aa.head)
//  val bb = aa.map(_.rate)
//  println (" -------->bb "+bb.size)
//  bb foreach println
//  println (" --------> "+bb.head)
//  new Rate(1223.3, INR, BTC) < 33 // new Rate(-1223.3, INR, BTC)
//  new Rate(1223.3, INR, BTC) === 33 // new Rate(-1223.3, INR, BTC)
////  val x = new Rate(1223.3, BTC, INR)
//  val x1 = new Rate(12222222.32999292929299222, ETH, BTC)
////  val x = Rate(12.3, INR, INR) // should give error
//  val a = new Amt(100, BTC)
////  val a = new Amt(10, BTC)
////  val b = Amt(102.3, ZEC) // should cause error next line (expected BTC, found ZEC)
//  val b = new Amt(1022322.3, INR) 
//  println(" ---> "+b.toCurrency(BTC))
////  new Amt(1022322.3, INR) === new Amt(1022322.3, ZEC)
////  val y = a * x
//  
////  x * b
////  val dd = 
//  val y = a * x
////  val y1 = b * x
//  val z = x * a
//  val w = b / x
//  println(" 1 ---> "+x1 \ new Amt(1002222.22222, ETH))
//  println(" 2 ---> "+x1 * new Amt(1002222.22222, BTC))
//  println(" 3 ---> "+x1)
//  println(" 4 ---> "+(new Amt(1002222.22222, ETH)+new Amt(1002222.22222, ETH)))
//  println(" 5 ---> "+(new Amt(1002222.22222, ETH)*new Rate(1223.3, INR, ETH)))
//  println(" 6 ---> "+x1 * new Amt(0.0000000000000001, BTC))
//  println(" 6a ---> "+new Amt(0.0000000000000005, BTC))
//  println(" 6b ---> "+x1 * new Amt(0.0000000000000005, BTC))
//  println(" 7 ---> "+(x1 * new Amt(0.0000000000000001, BTC) / x1))
//  println(" 8 ---> "+x)
//  println(" 9 ---> "+z)
////  println(" 0 ---> "+w)
//  println(" 0 ---> "+new Amt(100.005, INR))
//  println(" 0 ---> "+new Amt(100, INR))
//  println(" 0 ---> "+new Amt(1000000, BTC) / new Amt(100.004, INR))
//  println(" 0 ---> "+new Amt(1000000, INR) / new Amt(100, BTC))
//  val fee = new FeePercent(0.000000000001, BTC) // percent
//  println(" A = "+a)
//  println(" -A = "+(-a))
//  println(" FEE = "+fee)
//  val s = new Amt(2999.33333, BTC)
//  println(" ---> "+s.asUnsigned)
//  println(" FEE FRAC = "+fee * a)
//  println(" FEE FRAC = "+(fee * a === 0))
//  println(" FEE FRAC = "+(fee * a > 0))
//  println(" FEE FRAC = "+(fee * a - 0))
////  println(" FEE = "+fee * a)
//  
//  //
////  println(" 1 ---> "+Amount(10, BTC).at(Rate(1223.3, INR, BTC)))
////  println(" 2 ---> "+Amount(2345, INR).at(Rate(1223.3, INR, BTC))
//}
//object TestWallet extends App{
//  try {
//    val b = new ExchangeWallet(BTC)
//    //b.createWallet("alice")
//    //b.createWallet("bob")
//  //  b.incrementBalance("alice", new Amt(-100.123222222222222222, BTC), "")
//    b.$incrementBalance("bob", new Amt(393.12334993, BTC), "")
//    println(" ---> "+b.getBalance("alice"))
//    println(" ---> "+b.existsWallet("alice"))
//    println(" ---> "+b.getTotalBalance)
//
//    println(" ---> "+b.$newDeposit("alice", new Amt(44, BTC), new Amt(1, BTC), "externalID", "info", "sender"))
//  //  println(" ---> "+b.newDeposit("alice", new Amt(44, BTC), "externalID", "info", "sender"))
//  //  println(" ---> "+b.newWithdraw("alice", new Amt(44, BTC), "externalID", "info", "sender"))
//  //  println(" ---> "+b.newWithdraw("alice", new Amt(44, BTC), "externalID", "info", "sender")) // should give error
//  } catch {
//    case a:Any => a.printStackTrace
//  } finally System.exit(1)
//}
//
//
////
////package cs
////
////import cs.datastructures.Currencies._
////import cs.trade._
////import cs.trade.util._
////import cs.wallet.ExchangeWallet
////
////
////import exch.WalletsMgr._
////
////private object INR_BTC_TradeHandlers extends TradeHandlers(INR, BTC) // actual handlers
////
////// Wrapper for above. Exposes only required methods, hides junk methods not needed externally
////object INR_BTC_TradeHandlersWrapper extends TradeHandlersWrapper(INR_BTC_TradeHandlers)
////
////object INR_BTC_Ask_RefPercent extends FeePercent(10.0, INR) // how much to be given to referrals
////object INR_BTC_Bid_RefPercent extends FeePercent(10.0, BTC) // how much to be given to referrals
////
////private object INR_BTC_TradeDB extends TradeDB(INR, BTC)
////
////object WalletINR extends ExchangeWallet(INR)
////object WalletBTC extends ExchangeWallet(BTC)
////
////private object INR_BTC_TradeRequests extends TradeRequests(WalletINR, WalletBTC, INR_BTC_TradeDB)
////private object INR_BTC_TradeResults extends TradeResults(
////  WalletINR, WalletBTC, INR_BTC_TradeDB, INR_BTC_TradeHandlers, 
////  INR_BTC_Ask_RefPercent, INR_BTC_Bid_RefPercent
////)
////private object INR_BTC_MemOrderBook extends MemOrderBook(INR, BTC)
////
////object MarketINRBTC extends TradeEngine(
////  INR_BTC_TradeHandlers, WalletINR, WalletBTC,
////  INR_BTC_TradeRequests,
////  INR_BTC_TradeResults,
////  INR_BTC_TradeDB,
////  INR_BTC_MemOrderBook
////)
////
////private object LiveFeedINRBTC extends LiveFeed ( // actual feeds stored and fired from here
////  MarketINRBTC, INR_BTC_TradeHandlersWrapper 
////) { val qSize: Int = 100 }
////// above should not be directly accessed, hence private. 
////// Contains too many methods, many of which are not to be exposed (e.g., to mux.reflect api)
////// Below is a nice wrapper to be exposed to external code, and contains only required methods.
////// This style is from old exchange code and too much work to change for small benefit. So leaving as is.
////
////object LiveFeedWrapperINRBTC extends FeedWrapper(LiveFeedINRBTC) // wrapper for above, hides lots of junk methods
////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////// ETH BTC BELOW ///////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
////
////private object ETH_BTC_TradeHandlers extends TradeHandlers(ETH, BTC)
////object ETH_BTC_TradeHandlersWrapper extends TradeHandlersWrapper(ETH_BTC_TradeHandlers)
////
////object ETH_BTC_Ask_RefPercent extends FeePercent(10.0, ETH) // how much to be given to referrals
////object ETH_BTC_Bid_RefPercent extends FeePercent(10.0, BTC) // how much to be given to referrals
////
////object WalletETH extends ExchangeWallet(ETH)
////
////private object ETH_BTC_TradeDB extends TradeDB(ETH, BTC)
////private object ETH_BTC_TradeRequests extends TradeRequests(WalletETH, WalletBTC, ETH_BTC_TradeDB)
////private object ETH_BTC_TradeResults extends TradeResults(
////  WalletETH, WalletBTC, ETH_BTC_TradeDB, ETH_BTC_TradeHandlers, 
////  ETH_BTC_Ask_RefPercent, ETH_BTC_Bid_RefPercent
////)
////private object ETH_BTC_MemOrderBook extends MemOrderBook(ETH, BTC)
////
////object MarketETHBTC extends TradeEngine(
////  ETH_BTC_TradeHandlers, WalletETH, WalletBTC,
////  ETH_BTC_TradeRequests,
////  ETH_BTC_TradeResults,
////  ETH_BTC_TradeDB,
////  ETH_BTC_MemOrderBook
////)
////
////private object LiveFeedETHBTC extends LiveFeed ( // actual feeds stored and fired from here
////  MarketETHBTC, ETH_BTC_TradeHandlersWrapper 
////) { val qSize: Int = 100 }
////
////object LiveFeedWrapperETHBTC extends FeedWrapper(LiveFeedETHBTC) // wrapper for above, hides lots of junk methods
import cs.datastructures.Currencies._
import cs.datastructures.Wallets
import exch.Wallet

object Test extends App {
  Wallet.getBalances("email").foreach{x => 
   // x.currency // "BTC"
   // x.walletBal // "how much in wallet"
   // x.amt // total (wallet + locked)
   val y = x.lockedBal.locked // locked Bal details
   val lockedINRBTC:Option[BD] = y.get("INRBTC") // None if the market does not exist
   val lockedBCHBTC:Option[BD] = y.get("BCHBTC") // None if the market does not exist
   println("Currency "+x.currency)
   y.foreach{
     case (market, amount) => println(s"$amount locked in market $market")     
   }
  }
  import Wallets._
  val l = LockedBal(Map("INRBTC" -> 10991.2, "ZECBTC" -> 1000.222, "BCHBTC" -> 233.5))
  val t = TotalBal("BTC", 1234.44, l)
  println("-> "+t)
}
