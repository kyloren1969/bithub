
package cs.util

import amit.common.Util._ 
import cs.datastructures.Numbers._
  
object Common {
  private val randStringSize = 25
  def getID = randomAlphanumericString(randStringSize)
  def asString(a:Any) = a.asInstanceOf[String]
  def asTime(a:Any):Time = a.asInstanceOf[Long]
  //
  //  // used to ensure that two types are not the same
  //  //https://stackoverflow.com/a/6944070/243233
  //  trait =!=[A, B]
  //  implicit def neq[A, B] : A =!= B = null
  //  // This pair excludes the A =:= B case
  //  implicit def neqAmbig1[A] : A =!= A = null
  //  implicit def neqAmbig2[A] : A =!= A = null    
  //  
  //  // used to ensure that type X is either A or B
  //  //  http://milessabin.com/blog/2011/06/09/scala-union-types-curry-howard/
  //  type ¬[A] = A => Nothing
  //  type ¬¬[A] = ¬[¬[A]]
  //  type ∨[T, U] = ¬[¬[T] with ¬[U]]
  //

}
