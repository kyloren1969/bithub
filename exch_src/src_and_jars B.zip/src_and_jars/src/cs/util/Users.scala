package cs.util

import Common._
object Users {
  def asUserID(a:Any) = asString(a)
}
