
package cs.util

import scala.collection.mutable.{Set => MSet}
import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import amit.common.Util._

object TestHandler extends App {
  case class Foo(i:Int, s:String)
  val h1 = new Handler[Foo](true)
  val h2 = new Handler[Foo](false)
  def bar(foo:Foo) = {
    Thread.sleep(1000)
    println("bar invoked on "+foo)
    throw new Exception()
  }
  h1.addOn(1, bar)
  h2.addOn(1, bar)
  
  h1.doOn(Foo(1, "h1"))  
  println("H1 invoked")
  
  h2.doOn(Foo(1, "h2"))
  println("H2 invoked")
  //H1 invoked
  //bar invoked on Foo(1,h2)
  //Exception in thread "main" java.lang.Exception
  //	at cs.util.TestHandler$.bar(Handler.scala:17)
  //	at cs.util.TestHandler$$anonfun$2.apply(Handler.scala:20)
  //	at cs.util.TestHandler$$anonfun$2.apply(Handler.scala:20)
  //	at amit.common.Util$$anonfun$doInvokeNoTry$2.apply(Util.scala:103)
  //	at amit.common.Util$$anonfun$doInvokeNoTry$2.apply(Util.scala:103)
  //	at amit.common.Util$.doInvokeNoTry(Util.scala:103)
  //	at cs.util.Handler.doOn(Handler.scala:42)
  //	at cs.util.TestHandler$.delayedEndpoint$cs$util$TestHandler$1(Handler.scala:23)
  //	at cs.util.TestHandler$delayedInit$body.apply(Handler.scala:10)
  //bar invoked on Foo(1,h1)
  //	at cs.util.TestHandler$.main(Handler.scala:10)
  //	at cs.util.TestHandler.main(Handler.scala)
  // [TRYIT]: java.lang.Exception:null
  // 
  //System.exit(1)
}
class Invoker[T](h:Handler[T]) extends Actor {
  def receive = {
    case any => 
      val t = any.asInstanceOf[T]
      doInvoke(h.on, t)
  }
}
class Handler[T](doNotThrow:Boolean = true) {
  private [util] val on:MSet[(Int, T => Unit)] = MSet()

  val system = ActorSystem("InvokerSystem")
  val invoker = system.actorOf(Props(new Invoker(this)), name = "InvokerActor_"+this.hashCode)

  def addOn(id:Int, f:T => Unit) = addUnique(id, on, f)
  def doOn(t:T) = if (doNotThrow) {invoker ! t } else doInvokeNoTry(on, t)
}
