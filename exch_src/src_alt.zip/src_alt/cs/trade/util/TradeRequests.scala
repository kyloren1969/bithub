
package cs.trade.util

import cs.datastructures.Currencies._
import cs.trade._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades.Order
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.CommonDBCols._
import cs.wallet.ExchangeWallet
import cs.util.ErrorLog
import cs.util.Common._
import cs.util.DBs._
import amit.common.Util._
import mux.db.BetterDB._
import mux.db.core.DataStructures._

class TradeRequests[Fiat <: Cur, Coin <: Cur](
  fiatWallet:ExchangeWallet[Fiat], coinWallet:ExchangeWallet[Coin], tradeDB:TradeDB[Fiat, Coin]
) {
  val $fiat = fiatWallet.$cur
  val $coin = coinWallet.$cur
  
  import tradeDB._
  type RATE = Rate[Fiat, Coin]
  type COIN = Amt[Coin]
  type FIAT = Amt[Fiat]
  
  
  //@deprecated("Needs to be coded. Refs wont work.", "20 Nov 2017")
  //def getRefUserID(newUserID:UserID):RefUserID = None // returning None for now
  
  private val bidReqUtil = new OrderReqUtil(fiatWallet, (fiat, vol) => fiat, bidsDB)  
  private val askReqUtil = new OrderReqUtil(coinWallet, (fiat, vol) => vol,  asksDB)
  
  // Adds bid to db. Does not touch memory orderbook
  def addNewBidToDB(
    userID:UserID, vol:COIN, rate:RATE, makerFee:FeePercent[Coin], takerFee:FeePercent[Coin], refUserID:RefUserID
  ) = 
    bidReqUtil.addNewOrderToDB(userID, vol, rate, makerFee, takerFee, refUserID)
  
  // Adds ask to db. Does not touch memory orderbook
  def addNewAskToDB(
    userID:UserID, vol:COIN, rate:RATE, makerFee:FeePercent[Fiat], takerFee:FeePercent[Fiat], refUserID:RefUserID) = 
    askReqUtil.addNewOrderToDB(userID, vol, rate, makerFee, takerFee, refUserID)
  
  // Deletes bid from db. Does not touch memory orderbook. Before calling, validate userID from Mem orderbook
  // updates balance too
  def deleteBidFromDB(orderID:OrderID) = bidReqUtil.deleteOrderFromDB(orderID)
  
  // Deletes ask from db. Does not touch memory orderbook. Before calling, validate userID from Mem orderbook
  // updates balance too
  def deleteAskFromDB(orderID:OrderID) = askReqUtil.deleteOrderFromDB(orderID)
  
  // Adds order to/removes orderfrom Database. Does not touch memory orderbook
  private class OrderReqUtil[Sold <: Cur, Bought <: Cur](
    wallet:ExchangeWallet[Sold], required:(FIAT, COIN) => Amt[Sold], orderDB:OrderDB[Sold, Bought]
  )(implicit ev: ¬¬[Bought] <:< (Fiat ∨ Coin) /* Bought must be one of Fiat or Coin */, ev1: Bought =!= Sold) {
    import orderDB._
    val (minFiat, minVol, minRate) = (minOrdAmt($fiat), minOrdAmt($coin), new Rate(minOrdAmt($fiat).amt, $fiat, $coin))
    def addNewOrderToDB(
      userID:UserID, specifiedVol:COIN, rate:RATE, makerFee:FeePercent[Bought], takerFee:FeePercent[Bought], refUserID:RefUserID
    ) = {
      if (userID == "") throw EmptyUserException
      if (rate < minRate) throw new Exception(s"Rate cannot be < $minRate. Currently $rate")
      
      // TODO check max vol, rate, fiat // market.validateOrder(rate, vol) // validate order.. i.e. min and max limits satisfied
      // TODO convert specifiedVol to cleaned up vol (i.e, multiple of something, etc) // val vol = market.roundVol(specifiedVol)
      val vol = specifiedVol 
      if (vol < minVol) throw new MinimumAmountException($coin.symbol, minVol, vol)
      val fiat = rate * vol
      if (fiat < minFiat) throw new MinimumAmountException($fiat.symbol, minFiat, fiat)
      val reqd = required(fiat, vol)
      wallet.$getBalance(userID) match {        
        case Some(bal) if bal >= reqd => // sufficient balance... now decrement 
          val time = getTime
          // later on use auto generated orderID
          // need to see how it'll work for mem trades
          try {
            
            usingCount(wallet.$decrementBalance(userID, reqd, s"Create new order for: ${$fiat.symbol}${$coin.symbol}"), s"Error subtracting balance of $reqd from $userID")
            // Tirst put a copy for further reference, since open Database keeps changing
            // This step will also generate the auto incremented primary key (orderID)
            val ordID = recordOpenOrd(userID, rate, vol, time, makerFee, takerFee, refUserID) // for archive purpose only. Can remove?
            
            // Next, put open order in Database
            putOpenOrd(userID, ordID, rate, vol, time, vol /* origVol */, makerFee, takerFee, refUserID)          
             
            // Finally return a "Memory" order, one that is kept in Memory OB
            // MemOpen will be sent back, possibly to be sent to Mem order queue            
            new MemOpen(ordID, userID, rate, vol, time, vol /* origVol */, makerFee, refUserID)
            
          } catch {
            case e:Throwable =>
              val errorMsg = s"Error in newReq. UserID = $userID. Vol = $vol. Rate = $rate. Reqd = $reqd"
              ErrorLog.logException("TradeRequests.OrderReqUtil.addNewOrderToDB", e, errorMsg, true)
              throw e
          }
        case Some(bal) => throw new InsufficientBalanceException(userID, bal, reqd)
        case None => throw new WalletNotFoundException(userID, wallet.$cur)
      }
    }
    def deleteOrderFromDB(orderID:OrderID):Order[Fiat, Coin, Bought] = {
      //  IMPORTANT !!! Before calling, ensure that orderID is deleted from Mem OB. Use below code snippet outside this method
      //  getFromMemOB(orderID) match {
      //    case Some(open) =>
      //      deleteFromMemOB(orderID) // delete from Mem OB first ?
      //      // call this method
      //    case _ => // not found in mem ob
      //      throw OrderNotFoundException(orderID) // maybe give more specific exception (i.e. not in mem)
      //  }
      orderDB.getOpenOrder(orderID) match {
        case Some(open) =>
          deleteOpen(orderID) // delete from open Database
          val (rate, vol) = (open.rate, open.vol)
          putCanceledOrd(open.userID, orderID, rate, vol, getTime, open.origVol) // add to canceled Database
          wallet.$incrementBalance(open.userID, required(rate * vol, vol), s"Canceled $ordType id $orderID")
          open.toStatus(Canceled)
        case _ => // not found in mem ob
          throw OrderNotFoundException(orderID) // maybe give more specific exception (i.e. not in mem)
      }
    } 
  }
    
  //    private def getMaxOrMinOrdIDs(userID:UserID, getMaxOrMinRate:UserID => Option[BigNum]) = getMaxOrMinRate(userID) match {
  //      case Some(rate) => MaxOrMin(rate, getOrdsForRate(userID, rate))
  //      case _ => throw EmptyOrderBookException
  //    }
}
