
package cs.trade.util

import cs.datastructures.Users._
import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
import cs.util.Common._
import scala.collection.immutable.TreeMap
import amit.common.Util._
import cs.util.Users._
//import cs.util.Numbers._

class MemOrderBookUtil[Fiat <: Cur, Coin <: Cur](fiat:Fiat, coin:Coin)(implicit ev: Fiat =!= Coin){
  type COIN = Amt[Coin]
  type FIAT = Amt[Fiat]
  type RATE = Rate[Fiat, Coin]
  type MEM_OPEN[Bought <: Cur] = MemOpen[Fiat, Coin, Bought]
  type MEM_COMPLETE[Bought <: Cur] = MemComplete[Fiat, Coin, Bought]
  type MEM_PARTIAL[Bought <: Cur] = MemPartial[Fiat, Coin, Bought]
  type MEM_TRADE[Bought <: Cur] = MemTrade[Fiat, Coin, Bought]
  
  case class OrderDetails[Bought <: Cur](
    vol:COIN, time:Time, 
    origVol:COIN, // for partial order. If this is a partial order, will 
    userID:UserID, feePercent:FeePercent[Bought], refUserID:RefUserID
  ) extends Ordered[OrderDetails[Bought]] {
    /* code copy-pasted from http://stackoverflow.com/a/19348339/243233 
    // following import Required as of Scala 2.11 for reasons unknown - the companion to Ordered should already be in implicit scope
    */
    override def toString = "(Vol:"+vol+",Time:"+time+")"
    import scala.math.Ordered.orderingToOrdered
    import scala.math.Ordering.Implicits._

    // http://stackoverflow.com/a/12290441/243233 (see link for below code)
    // implicitly[Ordering[Tuple2[Priority, Time]]]
    // def compare(that: OrderDetails[Bought]): Int = (this.priority, this.time) compare (that.priority, that.time)
    implicitly[Ordering[Time]]
    def compare(that: OrderDetails[Bought]): Int = this.time compare that.time
  }
  // for searching orders. Maps orderID to rate. To search for an order, find the rate and then search the RateMap
  // for the order... This is more efficient than plain collections because TreeMap always keeps the data 
  // sorted by keys (default is increasing order). This allows efficient binary search (internally by Scala)
  type OrderMap = TreeMap[OrderID, RATE]
  // for finding matching orders when a new bid or ask comes in (or a new market order comes in)
  // RateMap maps rates to the structure below. The Volume is precomputed so we can efficiently reject unneeded
  // orders. The structure is generic representing both bids and asks
  type RateMap[Bought <: Cur] = TreeMap[RATE, (COIN, TreeMap[OrderID, OrderDetails[Bought]])]
  // represents a partial trade. If an order is partially completed, it gives the info here
  object DecreasingOrder extends Ordering[RATE] { def compare(a:RATE, b:RATE) = b compare a }  
  object IncreasingOrder extends Ordering[RATE] { def compare(a:RATE, b:RATE) = a compare b }  

  def getTotalVolume[Bought <: Cur](
    rates:RateMap[Bought]
  ):COIN = {
    val vols = rates map (_._2._1) 
    if (vols.size > 0) vols reduceLeft(_ + _) else new Amt[Coin](0, coin)
  }
  
  def getOrder[Bought <: Cur](
    id:OrderID, orderMap:OrderMap, rateMap:RateMap[Bought]
  ):Option[MEM_OPEN[Bought]] = {
    orderMap.get(id) match {
      case Some(rate) => 
        rateMap.get(rate) match {
          case Some((vol, treeMap)) => 
            treeMap.get(id) match {
              case Some(info) => 
                Some(new MemOpen(id, info.userID, rate, vol, info.time, info.origVol, info.feePercent, info.refUserID))
              case _ => None
            }
          case _ => None
        }
      case _ => None
    }
  }
  
  def getMapsForUnmatchedOrder[Bought <: Cur](
    o:MEM_OPEN[Bought], orderMap:OrderMap, rateMap:RateMap[Bought]
  ):(OrderMap, RateMap[Bought]) = {
    //    println("Adding new order: "+o)
    //    println("MAPS BEFORE")
    //    printMaps(orderMap, rateMap)
    //    println("MAPS BEFORE END")
    if (orderMap.contains(o.id)) throw new OrderBookException(s"Order book already has orderID ${o.id}")    
    val newOrderMap = orderMap + (o.id -> o.rate)
    val rateEntry = rateMap.get(o.rate) match {
      case Some((vol, treeMap)) => 
        (
          vol + o.vol, 
          treeMap + (o.id -> OrderDetails(o.vol, o.time, o.origVol, o.userID, o.feePercent, o.refUserID))
        )
      case None => 
        (
          o.vol, 
          TreeMap(o.id -> OrderDetails(o.vol, o.time, o.origVol, o.userID, o.feePercent, o.refUserID))
        )
    }
    val newRateMap = rateMap + (o.rate -> rateEntry)
    //    println("----------------------------------\nMAPS AFTER")
    //    printMaps(newOrderMap, newRateMap)
    //    println("MAPS AFTER END")
    (newOrderMap, newRateMap)
  }  
  
  def printMaps[Bought <: Cur](
    orderMap:OrderMap, rateMap:RateMap[Bought]
  ):Unit = {
    //println
    println(s" [A] RateMap")
    rateMap foreach {
      case (rate1, (vol1, tMap1)) =>
        println(s"    [A1] rate: $rate1, vol: $vol1")
        tMap1.foreach{
          case (oid2, detl2) =>
            println(s"        [A2] orderID: $oid2, detail: $detl2")
        }
    }
    println(" ----------------------------------------------- ")
    println(s" [B] OrderMap")
    orderMap foreach {
      case (ordID, rate) =>
        println(s"    [B1] ordID: $ordID, rate: $rate")
    }
    println(" ----------------------------------------------- ")
  }
  
  def getHighestOrLowestRate[Bought <: Cur](
    userID:UserID, rateMap:RateMap[Bought]
  ):Option[RATE] = {
    rateMap.find{
      case (rate, (vol, treeMap)) =>
        treeMap.exists{
          case (id, ordDetails) =>
            ordDetails.userID == userID
        }
    }.map{
      case (rate, (vol, treeMap)) => rate
    }
  }
  
  def getMapsForDeletedOrder[Bought <: Cur](
    id:OrderID, orderMap:OrderMap, rateMap:RateMap[Bought]
  ):(OrderMap, RateMap[Bought]) = {
    //    println("print maps start [BEFORE delete]")
    //    printMaps(orderMap, rateMap)
    //    println("print maps end [BEFORE delete]")
    //    println
    assert(orderMap.contains(id), "no such order in order book: "+id) // (removed assertion -- was for testing)        
  
    val (newOrderMap, newRateMap) = orderMap.get(id) match {
      case Some(rate) =>   
        (
          orderMap - id, 
          rateMap.get(rate) match {
            case Some((vol, treeMap)) if treeMap.size == 1 => 
              // assert(vol == treeMap.get(id).get.vol, "volume mismatch while deleting order: "+id) // sanity check, can be removed after testing  (removed assertion -- was for testing)        
              rateMap - rate
            case Some((vol, treeMap)) => 
              val orderAmt = treeMap.get(id) match {
                case Some(rateInfo) => rateInfo.vol
                case _ => throw OrderBookException("Order not found in rate map "+id)
              }
              rateMap + (rate -> (vol - orderAmt, treeMap - id))
            case None => throw OrderBookException("Rate not found in rate map "+id)
          }
        )
      case None => throw OrderBookException("Order not found in order map "+id)
    }
    //    println("print maps start [AFTER delete]")
    //    printMaps(newOrderMap, newRateMap)    
    //    println("print maps end [AFTER delete]")
    //    println
    (newOrderMap, newRateMap)
  }    
  
  def getMatchingBids(
    ask:MEM_OPEN[Fiat], orderMap:OrderMap, rateMap:RateMap[Coin]
  ):Option[MEM_TRADE[Coin]] = getMatchingOrders(ask, orderMap, rateMap, rate => rate >= ask.rate)
  
  def getMatchingAsks(
    bid:MEM_OPEN[Coin], orderMap:OrderMap, rateMap:RateMap[Fiat]
  ):Option[MEM_TRADE[Fiat]] = getMatchingOrders(bid, orderMap, rateMap, rate => rate <= bid.rate)
  
  def getMatchingOrders[Bought <: Cur, Sold <: Cur](
    o:MEM_OPEN[Bought], orderMap:OrderMap, rateMap:RateMap[Sold], rateFilter:RATE => Boolean
  ):Option[MEM_TRADE[Sold]] = {
    // nowFiat if defined implies it is a "now" order. In case of now order, it is mandatory to supply an upper bound on fiat transacted
    // Note: even the coin seller needs to put a bound. 
    val eligible = rateMap.filter{case (rate, rateDetails) => rateFilter(rate)}
    // valid contains all valid orders (ones that fall above/below desired rate - depending on if it is a bid/ask (or buy/sell))
    // currently for buy/sell ("now"), we put max rate to INFINITY. We need to filter to approx rate to avoid loading all rows
    val matched = eligible.size match {
      case i if i > 0 =>      
        val (volLeft, completeOrd, partOrd) = (o.vol - getTotalVolume(eligible)) match  {
          case i if i < 0 => // if available is more than needed (or difference is < 0)
            var accum:COIN = zero(coin) // new Amt(0, coin) // accumulated volume
            var valid:List[(COIN, COIN, List[(OrderID, OrderDetails[Sold])], RATE)] = Nil 
            // contains (cumulativeStart, cumulativeEnd, Complete, Rate)
            val ratelIterator = rateMap.toIterator 
            while(accum < o.vol && ratelIterator.hasNext) {
              val (rate, (vol, treeMap)) = ratelIterator.next
              valid :+= (accum, {accum += vol; accum}, treeMap.toList.sortBy(_._2), rate)
            }
            val (completeRates, partialRates) = valid.partition(o.vol >= _._2)

            val complete1:List[MEM_COMPLETE[Sold]] = completeRates.flatMap{
              case (cStartCoin, cEndCoin, complete, rate) => 
                complete.map{
                  case (id, info) =>
                    new MEM_COMPLETE[Sold](
                      id, info.userID, rate, info.vol, info.time, info.origVol, info.feePercent, info.refUserID
                    )
                }
            }
            // assert(partialRates.size <= 1)  (removed assertion -- was for testing)        
            accum = if (completeRates.size > 0) completeRates.last._2 else partialRates.head._1
            val cumulativeOrders:List[
              List[
                //       Start  End   Rate  Vol   OrigVol 
                (OrderID, COIN, COIN, RATE, COIN, COIN /* origVol */, UserID, Time, FeePercent[Sold], RefUserID)
              ]
            ] = partialRates map{
              case (cStartCoin, cEndCoin, complete, rate) => 
                complete.map{
                  case (id, info) =>
                    (id, accum, {accum += info.vol; accum}, rate, info.vol, info.origVol, info.userID, info.time, info.feePercent, info.refUserID)
                }
            }
            val matchedOrders = cumulativeOrders flatMap(_.filter(o.vol > _._2))
            val (completeOrders, partialOrders) = matchedOrders.partition(_._3 <= o.vol)
            assert(partialOrders.size <= 1) // (removed assertion -- was for testing)        
            
            val complete2:List[MEM_COMPLETE[Sold]] = completeOrders.map{
              case (id, cStartCoin, cEndCoin, rate, vol, origVol, userID, time, feePercent, refUserID) =>
                new MEM_COMPLETE[Sold](id, userID, rate, vol, time, origVol, feePercent, refUserID)
            }
            val complete:List[MEM_COMPLETE[Sold]] = complete1 ++ complete2 
            
            val partial:List[MEM_PARTIAL[Sold]] = partialOrders.map{
              case (id, cStartCoin, cEndCoin, rate, vol, origVol, userID, time, feePercent, refUserID) =>
                new MEM_PARTIAL[Sold](id, userID, rate, o.vol - cStartCoin, cEndCoin - o.vol, time, origVol, feePercent, refUserID)
            }
            (None, complete, if (partial.size > 0) Some(partial.head) else None)
          case i if i === 0 => 
            (
              None, 
              eligible.flatMap{
                case (rate, (vol, treeMap)) =>
                  treeMap.map{
                    case (id, info) =>
                      new MEM_COMPLETE[Sold](id, info.userID, rate, info.vol, info.time, info.origVol, info.feePercent, info.refUserID)
                  }
              }, 
              None
            ) 
          case i if i > 0 =>             
            (
              Some(i), 
              eligible.flatMap{
                  case (rate, (vol, treeMap)) =>
                    treeMap.map{
                      case (id, info) =>
                        new MEM_COMPLETE[Sold](id, info.userID, rate, info.vol, info.time, info.origVol, info.feePercent, info.refUserID)
                    }
              }, 
              None
            ) 
        }
        val fiatTraded = 
          completeOrd.foldLeft(zero(fiat))((x, y) => x + y.rate * y.vol)+ //m.getFiat(y.rate, y.vol)
          partOrd.foldLeft(zero(fiat))((x, y) => x+ y.rate * y.completedVol) //m.getFiat(y.rate, y.completedVol)

        val coinTraded = 
          completeOrd.foldLeft(zero(coin))((x, y) => x + y.vol) + 
          partOrd.foldLeft(zero(coin))((x, y) => x + y.completedVol)

        Some(new MEM_TRADE[Sold](volLeft, completeOrd, partOrd, fiatTraded, coinTraded))        
      case _ => None // no orders match. 
    }
    //println("\n MATCH => "+matched)
    //println
    matched
  }  
  
  def getHighestBid(rates:RateMap[Coin]):RATE = if (rates.size > 0) rates.head._1 else new Rate(zero(fiat).amt, fiat, coin) //Zero
  
  def getLowestAsk(rates:RateMap[Fiat]):RATE = if (rates.size > 0) rates.head._1 else new Rate(infinite(fiat).amt, fiat, coin)  //Infinite
  
  def getApproxCoin[Buying <: Cur](
    maxFiat:UAmt[Fiat], rateMap:RateMap[Buying] //[Fiat] for asks
  )(implicit ev1: ¬¬[Buying] <:< (Fiat ∨ Coin)):Approx[Fiat, Coin, Buying, Coin] = {
    
    var accum:FIAT = zero(fiat)
    var valid:List[(FIAT, FIAT, RATE, COIN)] = Nil
    val rateIterator = rateMap.toIterator
    while(accum < maxFiat && rateIterator.hasNext) {
      val (rate, (vol, _)) = rateIterator.next
      valid :+= (accum, {accum += rate * vol; accum}, rate, vol)
    }
    if (accum < maxFiat) throw new OrderBookException(s"Insufficient orders to cover $maxFiat. Maximum fiat spendable is $accum") // why is this there?
    val (complete, partial) = valid.partition(_._2 <= maxFiat)
    assert(partial.size <= 1) // (removed assertion -- was for testing)        
    val completeCoin = complete.foldLeft(zero(coin))((x, y) => x + y._4)
    val partialCoin = if (partial.isEmpty) zero(coin) else {
      /*
       * Various places where maxFiat can fall
       * 
       *                                    No     No   No Yes                    No
       *                                    |      |    |   |                     | 
       *                                    V      V    V   V                     V  
       * ------------------ COMPLETES ------------------|--Partial--|----------------------
       * |   |       |         |   |    |       |       |           |
       *                                              Before      After
       *                                              
       * 
       *                                    No     No  Yes                       Yes 
       *                                    |      |    |                         | 
       *                                    V      V    V                         V  
       * ------------------ COMPLETES ------------------|----------------------------------
       * |   |       |         |   |    |       |       |           
       * 
       */
      val (accumFiatBefore, accumFiatAfter, partialRate, thisVol) = partial.head
      assert(maxFiat < accumFiatAfter, s"MaxFiat $maxFiat >= AccumFiatAfter $accumFiatAfter")
      assert(maxFiat > accumFiatBefore, s"MaxFiat $maxFiat <= AccumFiatBefore $accumFiatBefore")
      val fiatLeft = maxFiat - accumFiatBefore
      fiatLeft / partialRate // can be zero if fiatLeft is too low for a complete satoshi
    }
    val rateToUse = valid.lastOption.map{case (_, _, rate, _) => rate}
    Approx(completeCoin + partialCoin, rateToUse)
  }
  
  def getApproxFiat[Buying <: Cur](
    maxCoin:UAmt[Coin], rateMap:RateMap[Buying] //[Coin] for bids
  )(implicit ev1: ¬¬[Buying] <:< (Fiat ∨ Coin)):Approx[Fiat, Coin, Buying, Fiat] = {
    
    var accum:COIN = zero(coin)
    var valid:List[(COIN, COIN, RATE,FIAT)] = Nil
    val rateIterator = rateMap.toIterator // rateMap.keysIterator
    while(accum < maxCoin && rateIterator.hasNext) {
      val (rate, (vol, _)) = rateIterator.next
      valid :+= (accum, {accum += vol;accum},rate, rate * vol)
    }
    if (accum < maxCoin) throw new OrderBookException(s"Insufficient orders to cover $maxCoin. Maximum coin spendable is $accum") // why is this needed? 
    val (complete, partial) = valid.partition(_._2 <= maxCoin)
    assert(partial.size <= 1)  // (removed assertion -- was for testing)        
    val completeFiat = complete.foldLeft(zero(fiat))((x, y) => x + y._4)
    val partialFiat = if (partial.isEmpty) zero(fiat) else {
      val (accumCoinBefore, accumCoinAfter, partialRate, thisFiat) = partial.head
      assert(maxCoin < accumCoinAfter, s"MaxCoin $maxCoin >= AccumCoinAfter $accumCoinAfter")
      assert(maxCoin > accumCoinBefore, s"MaxCoin $maxCoin <= AccumCoinBefore $accumCoinBefore")
      val coinLeft = maxCoin - accumCoinBefore
      partialRate * coinLeft
    }
    val rateToUse = valid.lastOption.map{case (_, _, rate, _) => rate}
    Approx(completeFiat + partialFiat, rateToUse)
  }
  
}


///*
//  private def processNowOrLaterOrd[This <: Cur](
//    volLeft:Option[COIN], 
//    complete:Iterable[MEM_COMPLETE[This]], 
//    partial:Option[MEM_PARTIAL[This]], 
//    nowFiat:Option[FIAT]
//  ):(Option[COIN], Iterable[MEM_COMPLETE[This]], Option[MEM_PARTIAL[This]]) = {
//    nowFiat match {
//      case None => (volLeft, complete, partial)
//        // No MaxFiat, its not a "Now" order. Return above
//      case Some(maxFiat) => 
//        ///////////////////////////////////////////////////
//        ///////////////////////////////////////////////////
//        ///////////////////////////////////////////////////
//        // Debug below. Behaves weird in certain cases
//        ///////////////////////////////////////////////////
//        ///////////////////////////////////////////////////
//        ///////////////////////////////////////////////////
//         
//        // need to recompute everything (volLeft, complete, partial).. Original ones are "old"
//        var accum:FIAT = zero(fiat) // accumulated from complete (initially zero)
//        
//        //             START  END   MemComplete 
//        var valid:List[(FIAT, FIAT, MEM_COMPLETE[This])] = Nil // contains (cumulativeStart, cumulativeEnd, Complete)
//        val complIterator = complete.toIterator 
//        while(accum < maxFiat && complIterator.hasNext) {
//          val compl = complIterator.next
//          valid :+= (accum, {accum += compl.rate * compl.vol; accum}, compl)
//        }
//        val (tmpComplete, tmpPartial) = valid.partition{
//          case (startFiat, endFiat, _) => endFiat <= maxFiat
//        }
//        assert(tmpPartial.size <= 1) // sanity check.. Should only have at most one element (removed assertion -- was for testing)        
//        
//        println("[DEBUG NOW ORDER] Accum Fiat: "+accum)
//        println("[DEBUG NOW ORDER] Max Fiat: "+maxFiat)
//        
//        val optPartialTuple:Option[(FIAT, FIAT, MEM_PARTIAL[This])] = if (accum < maxFiat) { 
//          assert(tmpPartial.size == 0) // sanity check.. Should have exactly zero elements
//          /* 
//           * 
//           Only then look at partial 
//           
//            this means that total orders are less than what was desired
//            (i.e., not enough vol to cover desired amount
//            Example
//             currently 2 Asks
//               0.5 BTC @ 1000 INR/BTC
//               0.5 BTC @ 1005 INR/BTC
//
//            Someone puts a BuyNow orderof 2000 INR
//            This will cover 1 BTC above for 1002.5 INR 
//
//            so accum should be 1002.5 INR while maxFiat is 2000
//           
//          */
//          partial.map{p =>
//            val pTotalVol = p.completedVol+p.remainingVol
//            val endFiat:FIAT = accum+ p.rate * pTotalVol
//            (accum, endFiat, p)
//          }
//        } else tmpPartial.headOption.map{
//          case (cStartFiat, cEndFiat, compl) =>
//            (cStartFiat, cEndFiat, new MEM_PARTIAL[This](
//                compl.id, compl.userID, compl.rate, 
//                zero(coin),  // completeVol
//                compl.vol,   // remainingVol
//                compl.time, compl.origVol, compl.feePercent, compl.refUserID
//              )
//            )
//        }
//        // Note: if optPartialTuple is None, then exact match. (No partials anywhere)
//        val newPartial:Option[MEM_PARTIAL[This]] = optPartialTuple.flatMap{
//          case (beforeFiat:FIAT, afterFiat:FIAT, thisPart:MEM_PARTIAL[This]) => 
//            val (partOrd, fiatTillNow) = (thisPart, beforeFiat)
//            val fiatAvbl = maxFiat - fiatTillNow
//            // assert(fiatAvbl > 0) // sanity check (removed assertion -- was for testing)        
//            lazy val partOrdTotalVolume = partOrd.remainingVol+partOrd.completedVol
//            // getVol seems to behave as follows: gives 0 vol if fiat is too low
//            val newPartVolCompleted = (fiatAvbl / partOrd.rate).min(partOrd.completedVol) // fortunately scala always rounds down.. So we never cross fiatAvbl
//            if (newPartVolCompleted > 0) 
//              Some(
//                new MEM_PARTIAL[This](
//                  partOrd.id, 
//                  partOrd.userID, 
//                  partOrd.rate, 
//                  newPartVolCompleted,   // completeVol
//                  partOrdTotalVolume - newPartVolCompleted,   // remainingVol 
//                  partOrd.time, 
//                  partOrd.origVol, 
//                  partOrd.feePercent, 
//                  partOrd.refUserID
//                )
//              )
//            else None
//        } 
//        // below we set main Order volLeft to None. Since this is a "now" trade, we don't keep any volume in pending, even if there is no match
//        // so no need to compute it
//        (None, tmpComplete.map(_._3), newPartial)
//    }
//  }
//
//*/