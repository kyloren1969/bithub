
package cs.trade

import cs.datastructures.Numbers._
import amit.common.Util._
import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Users._
import cs.trade.util._
import cs.wallet.ExchangeWallet
import mux.db.core.DataStructures._
import scala.util.Failure
import scala.util.Success

// TO DO
//   Caching
//   BTC Deps
//   BTC Withdraws
//   INR Auto ??
//   Audits with multiple markets
//   CW or UW
//   
//   UserAudits (TEH)
//   AdminAudits (auditCoinBalance)
//   
//   ETH Deps
//   ETH Withdraws
//   ETH Wallet (CW/HW)
//   
//   Archive old canceled and closed orders 
//   Balance snapshots??
//   
//   Load testing (JMeter?)
//   
//   DB config
//   
//   add index to time col
//   
//   remove from and/or to in pagination??
//   
// Test
//  HighestBid, LowestAsk from MemOB
//  Partial, origOrd
//   
class TradeEngine[Fiat <: Cur, Coin <: Cur](
  $th:TradeHandlers[Fiat, Coin], 
  $fiatWallet:ExchangeWallet[Fiat], 
  $coinWallet:ExchangeWallet[Coin],
  $reqDB:TradeRequests[Fiat, Coin],
  $resDB:TradeResults[Fiat, Coin],
  val $tradeDB:TradeDB[Fiat, Coin], // only needed for loading orders when starting
  $memOB:MemOrderBook[Fiat, Coin] 
) extends TradeMethods($th, $fiatWallet, $coinWallet) {
  import $th._
  import $tradeDB._
  //type RATE = Rate[Fiat, Coin]
  //import $memOB.APPROX
  
  // auto load OB
  import scala.concurrent.ExecutionContext.Implicits.global
  
  bidsDB.getAllMemOpen.foreach{memBid =>
    $memOB.processBidInMem(memBid).map{outcome =>
      $resDB.addBidResultToDB(outcome, takerFeeBid)
    }
  }
  asksDB.getAllMemOpen.foreach{memAsk =>
    val outcome = $memOB.processAskInMem(memAsk).map{outcome =>
      $resDB.addAskResultToDB(outcome, takerFeeAsk)
    }
  }
  
  val takerFeeBid:FeePercent[Coin] = new FeePercent(0.5, $coin)
  val takerFeeAsk:FeePercent[Fiat] = new FeePercent(0.5, $fiat) 
  
  val makerFeeBid:FeePercent[Coin] = new FeePercent(0.1, $coin)
  val makerFeeAsk:FeePercent[Fiat] = new FeePercent(0.1, $fiat)
  
  def initializeForTests = {
    $fiatWallet.createWallet("alice")
    $fiatWallet.createWallet("bob")
    $coinWallet.createWallet("alice")
    $coinWallet.createWallet("bob")
    $fiatWallet.newDeposit("alice", 10000000000000000.00d, 0, "someID", "info", "sender")
    $coinWallet.newDeposit("bob", 100000000.000000001d, 0, "someID", "info", "sender")    
  }
  // following implements the logic for creating a bid. This is specific to the type of orderbook (Local, Remote or Merged)
  // This will be called by createBid (in TradeMethods -- an abstract class), which is a generic wrapper and does the tests for 
  //  1. if trading is disabled throw exception
  //  2. if user has existing ask lower than this bid, then throw exception (SelfBidException)
  //  3. feeds the bid to LiveFeed

  def $mem_getApproxBuyFiat(vol:COIN):Approx[Fiat, Coin, Coin, Fiat] = $memOB.getAvailableBuyOrdersFiat(vol:UAmt[Coin])
  
  def $mem_getApproxSellFiat(vol:COIN):Approx[Fiat, Coin, Fiat, Fiat] = $memOB.getAvailableSellOrdersFiat(vol:UAmt[Coin])
  
  def $mem_getApproxBuyCoin(fiat:FIAT):Approx[Fiat, Coin, Coin, Coin] = $memOB.getAvailableBuyOrdersVol(fiat:UAmt[Fiat])
  
  def $mem_getApproxSellCoin(fiat:FIAT):Approx[Fiat, Coin, Fiat, Coin] = $memOB.getAvailableSellOrdersVol(fiat:UAmt[Fiat])  
  
  def $buyNowInternal(userID:UserID, vol:COIN, rateToUse:RATE, refUserID:RefUserID):MemOpen[Fiat, Coin, Coin] = {
    val memOpenBid = $reqDB.addNewBidToDB(userID, vol, rateToUse, makerFeeBid, takerFeeBid, refUserID) // using maxRate, balance will be refunded
    $memOB.processNowBuyInMem(memOpenBid).map{outcome =>
      //assert(outcome.fiatTraded <= maxFiat, s"FiatTraded in Buy Now (${outcome.fiatTraded}) > maxFiat ($maxFiat)")
      assert(outcome.created.isEmpty, s"Created MUST be empty for a 'NOW' order. Currently: ${outcome.created.get}")
      $resDB.addBidResultToDB(outcome, takerFeeBid)
    }.onComplete{
      case Success(s) => println(" Success BUY NOW "+s)
      case Failure(s) => println(" Failure BUY NOW "+s)
        s.printStackTrace
    }
    memOpenBid
  }
  def $sellNowInternal(userID:UserID, vol:COIN, rateToUse:RATE, refUserID:RefUserID):MemOpen[Fiat, Coin, Fiat] = {
    val memOpenAsk = $reqDB.addNewAskToDB(userID, vol, rateToUse, makerFeeAsk, takerFeeAsk, refUserID)
    // def processNowSellInMem(sell:MEM_NOW[Fiat], maxFiat:FIAT)  
    $memOB.processNowSellInMem(memOpenAsk).map{outcome =>
      //assert(outcome.fiatTraded <= maxFiat, s"FiatTraded in Buy Now (${outcome.fiatTraded}) > maxFiat ($maxFiat)")
      assert(outcome.created.isEmpty, s"Created MUST be empty for a 'NOW' order. Currently: ${outcome.created.get}")
      $resDB.addAskResultToDB(outcome, takerFeeAsk)
    }.onComplete {
      case Success(s) => println(" Success SELL_NOW "+s)
      case Failure(s) => println(" Failure SELL_NOW "+s)
        s.printStackTrace
    }
    memOpenAsk
  }
  
  def $createBidInternal(
    userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID
  ) = {
    // following only uses orderbook to get result (does not touch DB) 
    // (newReq simply inserts the new bid in orderbook. without processing it. 
    //    Later on if it is fully processed (or partly), it will be deleted and db updated accordingly)
    // also balance is deducted in the below step
     
    val memOpenBid = $reqDB.addNewBidToDB(userID, vol, rate, makerFeeBid, takerFeeBid, refUserID)
    // put above in future too?? No!
    // if here then balance deducted
    // push to queue later on
    // can return above memBid to user immediately and process rest of the code async
    $memOB.processBidInMem(memOpenBid).map{outcome =>
      // processBidInMem does not affect DB. Affects only Mem OB. Returns future
      // upto now DB has not been updated, except that the orig bid was added.
      // below line will add result to db
      $resDB.addBidResultToDB(outcome, takerFeeBid)
    }.onComplete{
      case Success(s) => println(" Success BID "+s)
      case Failure(s) => println(" Failure BID "+s)
        s.printStackTrace
    }
    memOpenBid
  } 
   
  // following implements the logic for creating an ask. This is specific to the type of orderbook (Local, Remote or Merged)
  // This will be called by createAsk (in TradeMethods -- an abstract class), which is a generic wrapper and does the tests for 
  //  1. if trading is disabled throw exception
  //  2. if user has existing bid higher than this ask, then throw exception (SelfAskException)
  //  3. feeds the ask to LiveFeed
  def $createAskInternal(
    userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID
  ) = {
    // following only uses orderbook to get result (does not touch DB) (newReq simply inserts the new ask in orderbook. without processing it. Later on if it is fully processed (or partly), it will be deleted and db updated accordingly)
    val memOpenAsk = $reqDB.addNewAskToDB(userID, vol, rate, makerFeeAsk, takerFeeAsk, refUserID)
    // it returns a memAsk to be used for memOB in next step
    // 
    // if here then balance deducted
    // potential bug above.. what if rate used is higher than rate (i.e., if I put a lower ask than highest bid??)
    // push to queue later on
    $memOB.processAskInMem(memOpenAsk).map{ outcome => 
      // processAskInMem does not affect DB. Affects only Mem OB
      // upto now DB has not been updated, except that the orig ask was added.
      // below line updates db
      $resDB.addAskResultToDB(outcome, takerFeeAsk)
    }.onComplete{
      case Success(s) => println(" Success ASK "+s)      
      case Failure(s) => println(" Failure ASK "+s)
        s.printStackTrace
    }
    memOpenAsk
  } 
  // FAILURE cs.datastructures.Exceptions$OrderBookException: Order book already has orderID 2
  
  // in following two methods, userID is not needed but given for additional security check (userID should own orderID)
  def $cancelBidInternal(userID:UserID, orderID:OrderID) = {
    $memOB.getMemBid(orderID) match {
      case Some(memBid) if memBid.userID == userID =>
        val ordID = $memOB.deleteBidFromMem(orderID) // this updates OB. Does not touch DB. Does not change bal
        // balance updated below
        $reqDB.deleteBidFromDB(ordID)
        memBid.toStatus(Unknown)
      case _ => throw OrderBookException(s"No such UserID/OrderID combination $userID/$orderID")
    }
  }
  def $cancelAskInternal(userID:UserID, orderID:OrderID) = {
    $memOB.getMemAsk(orderID) match {
      case Some(memAsk) if memAsk.userID == userID =>
        val ordID = $memOB.deleteAskFromMem(orderID)
        // balance updated below
        $reqDB.deleteAskFromDB(ordID)
        memAsk.toStatus(Unknown)
      case _ => throw OrderBookException(s"No such UserID/OrderID combination $userID/$orderID")
    }
  }

  // does not load from DB
  def $getTopBids_RateVol(max:Int):Array[RATE_VOL] = $memOB.getBidsRateVol(max)
  
  def $getTopAsks_RateVol(max:Int):Array[RATE_VOL] = $memOB.getAsksRateVol(max)

  //def db_getTradeFromIDs(tradeIDs:Array[TradeID]) = getTrades(tradeIDs)
  
  def $db_getClosedBid(userID:UserID, orderID:OrderID) = bidsDB.getClosedUserOrders(userID, orderID)

  def $db_getClosedAsk(userID:UserID, orderID:OrderID) = asksDB.getClosedUserOrders(userID, orderID)

  def db_getClosedBids(userID:UserID, to:Time, max:Int, offset:Long) = bidsDB.getClosedUserOrders(userID, to, max, offset)

  def db_getClosedAsks(userID:UserID, to:Time, max:Int, offset:Long) = asksDB.getClosedUserOrders(userID, to, max, offset)

  def $db_getCanceledBids(userID:UserID, to:Time, max:Int, offset:Long) = bidsDB.getCanceledUserOrders(userID, to, max, offset)
  
  def $db_getCanceledAsks(userID:UserID, to:Time, max:Int, offset:Long) = asksDB.getCanceledUserOrders(userID, to, max, offset)
  
  @deprecated("Does not have caching added yet.", "28 Nov 2017")
  def $db_getAllTrades(to: Time,max: Int,offset: Long) = getTrades(to, max, offset)

  // IMPORTANT: fromMillis is epoch time
  def db_getHistoryFrom(fromMillis:Time, intervalMillis:Time):List[HISTORY] = getTradeAggregateHistory(fromMillis, MaxTime, intervalMillis)
    
  def db_getRecentData(from:Time, to:Time) = getAllData(from, to)
  
  def db_getOrigBid(userID:UserID, orderID:OrderID):Option[ORIG_ORDER[Coin]] = bidsDB.getOrder(userID, orderID)

  def db_getOrigAsk(userID:UserID, orderID:OrderID):Option[ORIG_ORDER[Fiat]] = asksDB.getOrder(userID,orderID)
  
  def $db_getCreatedBids(userID:UserID, to:Time, max:Int, offset:Long) = bidsDB.getArchiveUserOrders(userID, to, max, offset)

  def $db_getCreatedAsks(userID:UserID, to:Time, max:Int, offset:Long) = asksDB.getArchiveUserOrders(userID, to, max, offset)

  def $db_getCreatedPartialBids(userID: UserID,to: Time,max: Int,offset: Long) = bidsDB.getArchivePartialOrders(userID, to, max, offset)

  def $db_getCreatedPartialAsks(userID: UserID,to: Time,max: Int,offset: Long) = asksDB.getArchivePartialOrders(userID, to, max, offset)

  def $getHighestBidRateFor(userID:UserID):Option[RATE] = $memOB.getHighestBidRate(userID)

  def $getLowestAskRateFor(userID:UserID):Option[RATE] = $memOB.getLowestAskRate(userID)
    
  // Below sorted by RATE ! (Not time!!)
  def $getAllOpenAsks(max: Int): List[ORDER[Fiat]] = $memOB.getTopAsks(max)

  def $getAllOpenBids(max: Int): List[ORDER[Coin]] = $memOB.getTopBids(max)
  
  def $getOpenAsks(userID:UserID, max: Int): List[ORDER[Fiat]] = $memOB.getTopUserAsks(userID, max)

  def $getOpenBids(userID:UserID, max: Int): List[ORDER[Coin]] = $memOB.getTopUserBids(userID, max)

  def getLockedAmtBids(userID:String):BD = $memOB.getLockedBidsFiat(userID)
  
  def getLockedAmtAsks(userID:String):BD = $memOB.getLockedAsksCoin(userID)

  //  @deprecated("Unused. Aggregates are bad because they don't support Max", "26 Nov 2017") 
  //  private def db_getClosedBidsAggr(userID:UserID, to:Time) = bidsDB.getClosedOrdersAggr(userID, to)

  //  @deprecated("Unused. Aggregates are bad because they don't support Max", "26 Nov 2017") 
  //  private def db_getClosedAsksAggr(userID:UserID, to:Time) = asksDB.getClosedOrdersAggr(userID, to)

  private def $db_getAllClosedBids(to:Time, max:Int, offset:Long) = bidsDB.getClosedOrders(to, max, offset)

  private def $db_getAllClosedAsks(to:Time, max:Int, offset:Long) = asksDB.getClosedOrders(to, max, offset)

  private def $db_getAllCanceledBids(to:Time, max:Int, offset:Long) = bidsDB.getAllCanceledOrders(to, max, offset)
  
  private def $db_getAllCanceledAsks(to:Time, max:Int, offset:Long) = asksDB.getAllCanceledOrders(to, max, offset)
  
  private def $db_getTradeByID(tradeID: TradeID) = getTrade(tradeID)
  
  @deprecated("To check if can pull from Mem", "20 Nov 2017")
  def $db_getAllOpenBids(max:Int):List[ORDER[Coin]] =
    bidsDB.getAllOpenOrders(max)

  @deprecated("To check if can pull from Mem", "20 Nov 2017")
  def $db_getAllOpenAsks(max:Int):List[ORDER[Fiat]] =
    asksDB.getAllOpenOrders(max)

}
