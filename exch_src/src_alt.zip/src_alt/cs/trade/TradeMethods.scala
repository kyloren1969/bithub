
package cs.trade

//import cs.trade.util.Fees.FeeUtil
import cs.wallet.ExchangeWallet
import java.util.concurrent.atomic.AtomicBoolean
import mux.db.core.DataStructures._
import amit.common.Util._
//import cs.datastructures.Trades.Priority
import cs.datastructures.Trades._
import cs.datastructures.Users._
import cs.util._
import cs.util.DBs._
//import cs.trade.util.Audits._
//import cs.util.OrderBooks._
//import cs.trade.datastructures.Trades._
//import cs.trade.datastructures.Exceptions._
import amit.common.cache.ItemCache
import amit.common.cache.ListCache
import cs.datastructures.Currencies.Rate
import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
//import cs.datastructures.Feeds.Last24HrData
import cs.datastructures.Numbers._

abstract class TradeMethods[Fiat <: Cur, Coin <: Cur](
  val $th:TradeHandlers[Fiat, Coin], 
  val $fiatWallet:ExchangeWallet[Fiat], 
  val $coinWallet:ExchangeWallet[Coin]
) {
  type RATE = Rate[Fiat, Coin]
  type COIN = Amt[Coin]
  type FIAT = Amt[Fiat]
  type RATE_VOL = RateVol[Fiat, Coin]
  type FIAT_VOL = FiatVol[Fiat, Coin]
  type HISTORY = History[Fiat, Coin]
  type CLOSED_ORDER[Bought <: Cur] = ClosedOrder[Fiat, Coin, Bought]
  type ORIG_ORDER[Bought <: Cur] = OrigOrder[Fiat, Coin, Bought]
  type ORDER[Bought <: Cur] = Order[Fiat, Coin, Bought]
  type MAX_OR_MIN = MaxOrMin[Fiat , Coin]
  type MEM_OPEN[Bought <: Cur] = MemOpen[Fiat , Coin, Bought]

  import $th._
  val $fiat = $fiatWallet.$cur
  val $coin = $coinWallet.$cur
  
  implicit private def $toRate(b:BD) = new Rate(b, $fiat, $coin)  
  implicit private def $BDToUFiat(b:BD) = new UAmt(b, $fiat)
  implicit private def $BDToUCoin(b:BD) = new UAmt(b, $coin)
    

  //abstract
  val takerFeeBid:FeePercent[Coin]  // later read from file or set from admin
  val takerFeeAsk:FeePercent[Fiat]
  val makerFeeBid:FeePercent[Coin]
  val makerFeeAsk:FeePercent[Fiat]
  ////////////////////////////////////////////
  ////////////////////////////////////////////
  // ABSTRACT METHOD START
  ////////////////////////////////////////////
  ////////////////////////////////////////////
  protected def $mem_getApproxBuyFiat(vol:COIN):Approx[Fiat, Coin, Coin, Fiat]
  protected def $mem_getApproxSellFiat(vol:COIN):Approx[Fiat, Coin, Fiat, Fiat]
  protected def $mem_getApproxBuyCoin(fiat:FIAT):Approx[Fiat, Coin, Coin, Coin]
  protected def $mem_getApproxSellCoin(fiat:FIAT):Approx[Fiat, Coin, Fiat, Coin]
  protected def $sellNowInternal(userID:UserID, vol:COIN, rateToUse:RATE, refUserID:RefUserID):MemOpen[Fiat, Coin, Fiat]
  protected def $buyNowInternal(userID:UserID, vol:COIN, rateToUse:RATE, refUserID:RefUserID):MemOpen[Fiat, Coin, Coin]
   
  // aggregate stuff, for live feed // should not read from DB
  def $getTopBids_RateVol(max:Int):Array[RATE_VOL] 
  def $getTopAsks_RateVol(max:Int):Array[RATE_VOL] 

  def getTopBids_RateVol(max:Int) = $getTopBids_RateVol(max).map(_.toSimpleRateVol)
  def getTopAsks_RateVol(max:Int) = $getTopBids_RateVol(max).map(_.toSimpleRateVol)

  def $getOpenAsks(userID:UserID, max: Int): List[ORDER[Fiat]]
  def $getOpenBids(userID:UserID, max: Int): List[ORDER[Coin]]

  def getOpenAsks(userID:UserID, max: Int): List[SimpleOrder] = $getOpenAsks(userID:UserID, max: Int).map(_.toSimpleOrder)
  def getOpenBids(userID:UserID, max: Int): List[SimpleOrder] = $getOpenBids(userID:UserID, max: Int).map(_.toSimpleOrder)

  def $getAllOpenBids(max:Int):List[ORDER[Coin]]
  def $getAllOpenAsks(max:Int):List[ORDER[Fiat]]

  def getAllOpenAsks(max: Int): List[SimpleOrder] = $getAllOpenAsks(max: Int).map(_.toSimpleOrder)
  def getAllOpenBids(max: Int): List[SimpleOrder] = $getAllOpenBids(max: Int).map(_.toSimpleOrder)
  
  def $getHighestBidRateFor(userID:UserID):Option[RATE]
  def $getLowestAskRateFor(userID:UserID):Option[RATE]
  
  def getHighestBidRateFor(userID:UserID) = $getHighestBidRateFor(userID).map(_.rate)
  def getLowestAskRateFor(userID:UserID)  = $getLowestAskRateFor(userID).map(_.rate)
  
  protected def $createBidInternal(
    userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID
  ):MemOpen[Fiat, Coin, Coin] 
  protected def $createAskInternal(
    userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID
  ):MemOpen[Fiat, Coin, Fiat]

  protected def $cancelBidInternal(userID:UserID, bidID:OrderID):ORDER[Coin]
  protected def $cancelAskInternal(userID:UserID, askID:OrderID):ORDER[Fiat]
  
  // To Cache Following
  protected [cs] def db_getOrigBid(userID:UserID, orderID:OrderID):Option[ORIG_ORDER[Coin]]

  // To Cache Following
  protected [cs] def db_getOrigAsk(userID:UserID, orderID:OrderID):Option[ORIG_ORDER[Fiat]]

  //  $th.addOnCloseAsk(-1234, ask => $closedAsksCache.putItem(ask.userID, ask))
  //  $th.addOnCloseBid(-1234, bid => $closedBidsCache.putItem(bid.userID, bid))

  // To Cache Following
  protected [cs] def $db_getAllTrades(to:Time, max:Int, offset:Long): List[TRADEDETAIL] 
  
  def db_getAllTrades(to: Time,max: Int,offset: Long) = $db_getAllTrades(to, max, offset).map(_.toSimpleTradeDetail)
  
  protected [cs] def db_getRecentData(from:Time, to:Time):AggrData[Fiat, Coin] // Sum(FiatVol), maxRate, minRate
  
  protected [cs] def db_getHistoryFrom(fromMillis:Time, intervalMillis:Time):List[HISTORY] // fromMillis is epochtime
  
  // for audit purposes
  protected [cs] def $db_getCreatedBids(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Coin]]
  protected [cs] def $db_getCreatedAsks(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Fiat]]

  protected [cs] def $db_getCreatedPartialBids(userID: UserID,to: Time,max: Int,offset: Long):List[ORDER[Coin]]
  protected [cs] def $db_getCreatedPartialAsks(userID: UserID,to: Time,max: Int,offset: Long):List[ORDER[Fiat]]

  
  protected [cs] def $db_getCanceledBids(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Coin]]
  
  protected [cs] def $db_getCanceledAsks(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Fiat]]

  // Shouls be sorted BY RATE (decreasing order), Not TIME!!
  protected [cs] def $db_getAllOpenBids(max:Int):List[ORDER[Coin]] 
  
  // Shouls be sorted BY RATE (increasing order), Not TIME!!
  protected [cs] def $db_getAllOpenAsks(max:Int):List[ORDER[Fiat]] 
  
  protected [cs] def $db_getClosedBid(userID:UserID, orderID:OrderID):List[CLOSED_ORDER[Coin]]
  protected [cs] def $db_getClosedAsk(userID:UserID, orderID:OrderID):List[CLOSED_ORDER[Fiat]]

  protected [cs] def db_getClosedBids(userID:UserID, to:Time, max:Int, offset:Long):List[CLOSED_ORDER[Coin]]
  protected [cs] def db_getClosedAsks(userID:UserID, to:Time, max:Int, offset:Long):List[CLOSED_ORDER[Fiat]]
  
  ////////////////////////////////////////////
  ////////////////////////////////////////////
  // ABSTRACT METHOD END
  ////////////////////////////////////////////
  ////////////////////////////////////////////

  //concrete 
  private val $tradesEnabled = new AtomicBoolean(true)
  
  def trades_disable:String = {
    val $info$ = "This disables trading, if the admin wants to disable them for whatever reason"
    $tradesEnabled.set(false)
    "trading disabled"
  }
  def trades_enable:String = {
    $tradesEnabled.set(true)
    "trades enabled"
  }
  def trades_isEnabled = $tradesEnabled.get
  
  //private final val $orderLock = new AtomicBoolean(false)

  def createBid(userID:UserID, vol:BD, rate:BD, refUserID:RefUserID) = {
    val $info$ = """Units of 'vol' are in BTC. Units of 'rate' are in INR/BTC. (NOT PAISE OR SATOSHIS!!)
So, for example, to buy 1.1 BTC at the rate of 1234.56 INR/BTC, use these values directly"""
    val $refUserID$ = "None"
    $createBid(userID, vol, rate, refUserID)
  }
  
  def createAsk(userID:UserID, vol:BD, rate:BD, refUserID:RefUserID) = {
    val $info$ = """Units of 'vol' are in BTC. Units of 'rate' are in INR/BTC. (NOT PAISE OR SATOSHIS!!)
So, for example, to sell 1.1 BTC at the rate of 1234.56 INR/BTC, use these values directly"""
    val $refUserID$ = "None"
    $createAsk(userID, vol, rate, refUserID)
  }

  
  private def $ensureWalletsExist(userID:UserID) = {
    $ensureFiatWalletExists(userID)
    $ensureCoinWalletExists(userID)
  }
  private def $ensureFiatWalletExists(userID:UserID) = {
    if (!$fiatWallet.existsWallet(userID)) $fiatWallet.createWallet(userID)
  }
  private def $ensureCoinWalletExists(userID:UserID) = {
    if (!$coinWallet.existsWallet(userID)) $coinWallet.createWallet(userID)
  }

  def buyNow(userID:UserID, maxFiat:BD, refUserID:RefUserID) = {
    val $info$ = """Units of 'fiat' are in INR. Units of 'rate' are in INR/BTC. (NOT PAISE OR SATOSHIS!!)
So, for example, to buy 1.1 BTC at the rate of 1234.56 INR/BTC, use these values directly"""
    $buyNow(userID, maxFiat, refUserID)
  }
    
  def sellNow(userID:UserID, maxFiat:BD, refUserID:RefUserID) = {
    val $info$ = """Units of 'fiat' are in INR. Units of 'rate' are in INR/BTC. (NOT PAISE OR SATOSHIS!!)
So, for example, to buy 1.1 BTC at the rate of 1234.56 INR/BTC, use these values directly"""
    $sellNow(userID, maxFiat, refUserID)
  }
 
  def getLockedAmtBids(userID:String):BD // fiat
  def getLockedAmtAsks(userID:String):BD // coin
  
  def $getApproxBuyFiat(vol:BD):Approx[Fiat, Coin, Coin, Fiat] = $mem_getApproxBuyFiat(vol:UAmt[Coin])
  def $getApproxSellFiat(vol:BD):Approx[Fiat, Coin, Fiat, Fiat] = $mem_getApproxSellFiat(vol:UAmt[Coin])
  def $getApproxBuyCoin(fiat:BD):Approx[Fiat, Coin, Coin, Coin] = $mem_getApproxBuyCoin(fiat:UAmt[Fiat])
  def $getApproxSellCoin(fiat:BD):Approx[Fiat, Coin, Fiat, Coin] = $mem_getApproxSellCoin(fiat:UAmt[Fiat])
  
  def getApproxBuyFiat(vol:BD):BD = $getApproxBuyFiat(vol).amt.amt
  def getApproxSellFiat(vol:BD):BD = $getApproxSellFiat(vol).amt.amt
  def getApproxBuyCoin(fiat:BD):BD = $getApproxBuyCoin(fiat).amt.amt
  def getApproxSellCoin(fiat:BD):BD = $getApproxSellCoin(fiat).amt.amt
  
  protected def $sellNow(userID:UserID, maxFiat:FIAT, refUserID:RefUserID):Option[ORDER[Fiat]] = if (trades_isEnabled) {
    $ensureWalletsExist(userID)
    val approx = $mem_getApproxBuyCoin(maxFiat)
    val vol = approx.amt   
    approx.optRateToUse.map{rateToUse =>
      getHighestBidRateFor(userID) match {
        case Some(max) if max >= rateToUse => throw new SelfAskException(rateToUse, userID, max)
        case _ => 
          val avgRate = maxFiat / vol
          assert(avgRate >= rateToUse, s"AvgRate ($avgRate) for sellNow < RateToUse ($rateToUse)")
          
          val memOpenAsk = $sellNowInternal(userID, vol, rateToUse, refUserID)
          val ord = memOpenAsk.toStatus(Queued)
          $th.createAskHandler.doOn(ord)
          ord
      }       
    }
  } else disabledException
  
  protected def $buyNow(userID:UserID, maxFiat:FIAT, refUserID:RefUserID):Option[ORDER[Coin]] = if (trades_isEnabled) {
    $ensureWalletsExist(userID)
    val approx = $mem_getApproxSellCoin(maxFiat)
    val vol = approx.amt   
    approx.optRateToUse.map{rateToUse =>
      getLowestAskRateFor(userID) match {
        case Some(min) if min <= rateToUse && min > 0 => throw new SelfBidException(rateToUse, userID, min)
        case _ => 
          val avgRate = maxFiat / vol
          assert(avgRate >= rateToUse, s"AvgRate ($avgRate) for sellNow < RateToUse ($rateToUse)")
          
          val memOpenBid = $buyNowInternal(userID, vol, rateToUse, refUserID)
          val ord = memOpenBid.toStatus(Queued)
          $th.createBidHandler.doOn(ord)
          ord
      }       
    }
  } else disabledException
  
  private final def $createBid(userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID):Order[Fiat, Coin, Coin] = {
    if (trades_isEnabled) {    
      val roundedVol = vol  // - vol % minSatoshiPerOrder
      getLowestAskRateFor(userID) match {
        case Some(min) if min <= rate && min > 0 => throw new SelfBidException(rate, userID, min)
        case _ => 
          $ensureWalletsExist(userID)
          refUserID.map($ensureCoinWalletExists)
          val memBid = $createBidInternal(userID, roundedVol, rate, refUserID).toStatus(Queued)
          $th.createBidHandler.doOn(memBid)
          memBid
      } 
    } else disabledException
  }
  
  private final def $createAsk(userID:UserID, vol:COIN, rate:RATE, refUserID:RefUserID):Order[Fiat, Coin, Fiat] = {
    if (trades_isEnabled) {      
      val roundedVol = vol // - vol % minSatoshiPerOrder // this is different from minSatoshiPerOrder, which is an abstract field. 
      getHighestBidRateFor(userID) match {
        case Some(max) if max >= rate => throw new SelfAskException(rate, userID, max)
        case _ => 
          $ensureWalletsExist(userID)
          if (refUserID.isDefined) {$ensureFiatWalletExists(refUserID.get)}
          val memAsk = $createAskInternal(userID, roundedVol, rate, refUserID).toStatus(Queued)
          $th.createAskHandler.doOn(memAsk)
          memAsk
      }
    } else disabledException
  }

  
  // in following two methods, userID is not needed but given for additional security check (userID should own orderID)
  final def cancelBid(userID:UserID, bidID:OrderID) = {
    if (trades_isEnabled) {
      val time = getTime
      val order = $cancelBidInternal(userID:UserID, bidID:OrderID)
      $th.cancelBidHandler.doOn(order)
      order
    }
    else disabledException
  }
  final def cancelAsk(userID:UserID, askID:OrderID) = {
    if (trades_isEnabled) {
      val time = getTime
      val order = $cancelAskInternal(userID:UserID, askID:OrderID)
      $th.cancelAskHandler.doOn(order)
      order
    }
    else disabledException
  }
  

  // aggregate stuff, for live feed

  def $getHighestBidRate:RATE = {
    val $info$ = "Gets highest bid from aggregated bids"
    $getTopBids_RateVol(1).headOption match{case Some(rv) => rv.rate; case _ => new Rate(zero($fiat).amt, $fiat, $coin)}
  }
  def $getLowestAskRate:RATE = {
    val $info$ = "Gets lowest ask from aggregated asks"
    $getTopAsks_RateVol(1).headOption match{case Some(rv) => rv.rate; case _ => new Rate(infinite($fiat).amt, $fiat, $coin)}
  }

  def getHighestBidRate = $getHighestBidRate.rate
  def getLowestAskRate = $getLowestAskRate.rate

  def $getTotalSellVol:COIN = {
    val $info$ = "Gets the total sum of coins in asks order book"
    $getTopAsks_RateVol(Int.MaxValue).map(_.vol).sum(num($coin))
  }
  def $getTotalBuyVol:COIN = {
    val $info$ = "Gets the total sum of coins in bids order book"
    $getTopBids_RateVol(Int.MaxValue).map(_.vol).sum(num($coin))  
  }
  
  def getTotalSellVol:BD = {
    val $info$ = "Gets the total sum of coins in asks order book"
    $getTotalSellVol.amt
  }
  def getTotalBuyVol:BD = {
    val $info$ = "Gets the total sum of coins in bids order book"
    $getTotalBuyVol.amt
  }
  
  private val $origBidsCache = new ItemCache[UserID, OrderID, ORIG_ORDER[Coin]](MaxLimit, true, db_getOrigBid, false)
  
  private val $origAsksCache = new ItemCache[UserID, OrderID, ORIG_ORDER[Fiat]](MaxLimit, true, db_getOrigAsk, false)
  
  def $getOrigBid(userID:UserID, id:OrderID):List[ORIG_ORDER[Coin]] = $origBidsCache.getItem(userID, id)
  
  def $getOrigAsk(userID:UserID, id:OrderID):List[ORIG_ORDER[Fiat]] = $origAsksCache.getItem(userID, id)

  def getOrigBid(userID:UserID, id:OrderID):List[SimpleOrigOrder] = $getOrigBid(userID:UserID, id:OrderID).map(_.toSimpleOrigOrder)
  
  def getOrigAsk(userID:UserID, id:OrderID):List[SimpleOrigOrder] = $getOrigAsk(userID:UserID, id:OrderID).map(_.toSimpleOrigOrder)
  
  private val $closedBidsCache = new ListCache[UserID, OrderID, CLOSED_ORDER[Coin]](MaxLimit, true, db_getClosedBids(_, MaxTime, MaxLimit, 0), false) // [OrderID, CLOSED_ORDER[Coin]]
  private val $closedAsksCache = new ListCache[UserID, OrderID, CLOSED_ORDER[Fiat]](MaxLimit, true, db_getClosedAsks(_, MaxTime, MaxLimit, 0), false) // [OrderID, CLOSED_ORDER[Fiat]]
  
  $th.closedAskHandler.addOn(-1234, order => {
      $closedAsksCache.putItem(order.userID, order)
      $origAsksCache.removeItems(order.userID, order.id)
    }
  )
  
  $th.closedBidHandler.addOn(-1234, order => {
      $closedBidsCache.putItem(order.userID, order)
      $origBidsCache.removeItems(order.userID, order.id)
    }
  )
  
  def $getClosedBids(userID:UserID, to:Time, max:Int, offset:Long):List[CLOSED_ORDER[Coin]] = $closedBidsCache.getItemsByDate(userID, to, max, offset)
  def $getClosedAsks(userID:UserID, to:Time, max:Int, offset:Long):List[CLOSED_ORDER[Fiat]] = $closedAsksCache.getItemsByDate(userID, to, max, offset)

  def getClosedBids(userID:UserID, to:Time, max:Int, offset:Long):List[SimpleClosedOrder] = $getClosedBids(userID:UserID, to:Time, max:Int, offset:Long).map(_.toSimpleClosedOrder)
  def getClosedAsks(userID:UserID, to:Time, max:Int, offset:Long):List[SimpleClosedOrder] = $getClosedAsks(userID:UserID, to:Time, max:Int, offset:Long).map(_.toSimpleClosedOrder)

  def $getClosedBid(userID:UserID, id:OrderID):List[CLOSED_ORDER[Coin]] = $closedBidsCache.getItems(userID, id)
  def $getClosedAsk(userID:UserID, id:OrderID):List[CLOSED_ORDER[Fiat]] = $closedAsksCache.getItems(userID, id)

  def getClosedBid(userID:UserID, id:OrderID):List[SimpleClosedOrder] = $getClosedBid(userID:UserID, id:OrderID).map(_.toSimpleClosedOrder)
  def getClosedAsk(userID:UserID, id:OrderID):List[SimpleClosedOrder] = $getClosedAsk(userID:UserID, id:OrderID).map(_.toSimpleClosedOrder)

  //////////////////////////////////////////
  //////////////////////////////////////////
  private val $canceledBidsCache = new ListCache[UserID, OrderID, ORDER[Coin]](MaxLimit, true, $db_getCanceledBids(_, MaxTime, MaxLimit, 0), true) // [OrderID, CLOSED_ORDER[Coin]]
  private val $canceledAsksCache = new ListCache[UserID, OrderID, ORDER[Fiat]](MaxLimit, true, $db_getCanceledAsks(_, MaxTime, MaxLimit, 0), true) // [OrderID, CLOSED_ORDER[Fiat]]

  $th.cancelAskHandler.addOn(-1234, order => {
      $canceledAsksCache.putItem(order.userID, order)
      $origAsksCache.removeItems(order.userID, order.id)
    }
  )
  $th.cancelBidHandler.addOn(-1234, order => {
      $canceledBidsCache.putItem(order.userID, order)
      $origBidsCache.removeItems(order.userID, order.id)
    }
  )
  
  def $getCanceledBids(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Coin]] = $canceledBidsCache.getItemsByDate(userID, to, max, offset)
  def $getCanceledAsks(userID:UserID, to:Time, max:Int, offset:Long):List[ORDER[Fiat]] = $canceledAsksCache.getItemsByDate(userID, to, max, offset)
  
  def getCanceledBids(userID:UserID, to:Time, max:Int, offset:Long):List[SimpleOrder] = $getCanceledBids(userID:UserID, to:Time, max:Int, offset:Long).map(_.toSimpleOrder)
  def getCanceledAsks(userID:UserID, to:Time, max:Int, offset:Long):List[SimpleOrder] = $getCanceledAsks(userID:UserID, to:Time, max:Int, offset:Long).map(_.toSimpleOrder)
  
  //val $tradesCache = new CSCache[TradeID, TradeID, TRADEDETAIL](MaxLimit, true, )
  // READS DB
  protected [cs] def db_getRecentTradesMillis(max:Int) = $db_getAllTrades(MaxTime, max, 0) // max = 0 implies all (kind of infinity) 
  //
  protected [cs] def $db_getHighestBidRate:RATE = {
    val $info$ = "Gets highest bid from aggregated bids"
    $db_getAllOpenBids(1).headOption match{case Some(rv) => rv.rate; case _ => new Rate(zero($fiat).amt, $fiat, $coin)}
  }
  protected [cs] def $db_getLowestAskRate:RATE = {
    val $info$ = "Gets lowest ask from aggregated asks"
    $db_getAllOpenAsks(1).headOption match{case Some(rv) => rv.rate; case _ => new Rate(infinite($fiat).amt, $fiat, $coin)}
  }

  // READS DB
  protected [cs] val $noTrade = new TRADEDETAIL("none", /* no tradeID */ zero($coin), zero($fiat), 0 /* time */, zeroRate($fiat, $coin), zeroRate($fiat, $coin), zeroRate($fiat, $coin), NoOrdType)

}
