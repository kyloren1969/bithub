package cs.util

import cs.datastructures.Users._
import cs.util.Common._
import cs.datastructures.Transfers._

object Transfers {
  // following defines an alias for a mutable set of type (Int, UserID => Boolean), where the second element of the pair is a method that takes in a userID and 
  // outputs true if withdraw must be blocked. 
  def addOnCheckBeforeWithdrawTo(id:Int, shouldBlockWithdraw:UserID => Boolean)(implicit withdrawBlockChecks:WithdrawBlockChecks) = 
    amit.common.Util.addUnique(id, withdrawBlockChecks, shouldBlockWithdraw)  

  def usingChecksBeforeWithdrawFor[T](userID:UserID)(doWithdraw: => T)(implicit withdrawBlockChecks:WithdrawBlockChecks) = {
    withdrawBlockChecks.find(_._2(userID)) match{ // find the first method that returns true (true implies withdraw needs to be blocked)
      case Some((id, _)) => throw new Exception(s"withdraw is blocked for $userID. Please contact support [blockCheckID: $id].")
      case _ => doWithdraw
    }      
  }
  def asTransferID(a:Any):TransferID = a.asInstanceOf[TransferID]
  def asExternalID(a:Any):ExternalID = a.asInstanceOf[String]
}
