
package cs.datastructures

import amit.common.json.JSONUtil.JsonFormatted

object Errors {
  case class CSError(thrower:String, thrown:Throwable, info:String, isCritical:Boolean) extends JsonFormatted {
    val keys = Array("Thrower", "Exception", "Message", "IsCritical", "Info")
    val vals = Array(thrower:String, thrown.getMessage, info:String, isCritical:Boolean)
  }
}
