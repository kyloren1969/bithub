
package cs.datastructures

import amit.common.json.JSONUtil.JsonFormatted
import cs.datastructures.Currencies._
import cs.datastructures.Trades.Order
import cs.datastructures.Users._
//import cs.trade.datastructures.Exceptions._
import cs.datastructures.Exceptions._
import cs.util.Common._
import amit.common.Util._

object OrderBook {
  //type Priority = Int // lower is first (low value gets precedence over high value)
  type Time = Long
  type TradeID = String
  type OrderID = String
  type PartialOrderID = String
  def asOrderID(a:Any) = a.asInstanceOf[OrderID]
  def asTradeID(a:Any) = a.asInstanceOf[TradeID]
  // copied from remote, for displaying anyorder details
  sealed trait OrderStatus {val s:String; override def toString = s}
  object Open extends OrderStatus {val s = "open"}
  object Canceled extends OrderStatus {val s = "cancelled"}
  object Closed extends OrderStatus {val s = "closed"}
  //  @deprecated("Avoid partial status", "20 Nov 2017")
  //  object Partial extends OrderStatus {val s = "partial"}
  object Queued extends OrderStatus {val s = "queued"}
  object Unknown extends OrderStatus {val s = "unknown"}
  //type OrigOrderID = OrderID
  
  def toOrderStatus(text:String):OrderStatus = Array(Open, Canceled, Closed, Queued).find(_.s == text).headOption.getOrElse(throw new OrderBookException("invalid order status: "+text))

  sealed abstract class OrdType(val ordTypeString:String) extends Serializable {
    override def toString = ordTypeString
    def reverse:OrdType
  }
  object Bid extends OrdType("bid") { def reverse = Ask }
  object Ask extends OrdType("ask") { def reverse = Bid }
  object NoOrdType extends OrdType("none") { def reverse = this }
  
  @deprecated("Not used anymore. We are using boolean true to indicate bid and false to indicate ask", "24 Nov 2017")
  def asOrdType(a:Any) = a match {
    case Bid.ordTypeString => Bid // s:String => OrdType(s)
    case Ask.ordTypeString => Ask
    case NoOrdType.ordTypeString => NoOrdType
    case any => throw new Exception(s"Unable to convert $any to OrdType")
  }  

  case class MemPartial[Fiat<: Cur, Coin<: Cur, Bought <:Cur](
    override val id:OrderID, 
    override val userID:UserID, 
    override val rate:Rate[Fiat, Coin], 
    completedVol:Amt[Coin], // complete vol in this partial order
    remainingVol:Amt[Coin], 
    override val time:Time, 
    override val origVol:Amt[Coin],     
    feePercent:FeePercent[Bought], 
    refUserID:RefUserID
  ) extends Order[Fiat, Coin, Bought](
    id, userID, rate, 
    completedVol+remainingVol, // total vol of this order, need not necessarily be origVol
    time, origVol, Open // earlier was Partial
  ) {
    // NOTE: completedVol + remainingVol = total vol of THIS partial order. 
    // BUT:  completedVol + remainingVol need not be always equal to origVol
    // 
    // EXAMPLE
    //    Step 1:   Bid 1 of 10 BTC @ 1000 INR/BTC
    //              completed 4 BTC and 6 BTC partial
    //    Step 2:   6 BTC partial 
    //              completed 5 BTC and 1 BTC partial
    // 
    // At the end of Step 2, completedVol + remainingVol = 6, while origVol = 10
    
    if (completedVol <= 0) throw new OrderBookException(s"Completed vol must be > 0 in a partial order. Currently $completedVol")
    lazy val keys = keysData ++ Array("completedVol", "remainingVol")
    lazy val vals = valsData ++ Array(completedVol,   remainingVol)
  }
  case class MemComplete[Fiat<: Cur, Coin<: Cur, Bought <:Cur](
    override val id:OrderID, 
    override val userID:UserID, 
    override val rate:Rate[Fiat, Coin], 
    override val vol:Amt[Coin], 
    override val time:Time, 
    override val origVol:Amt[Coin], 
    feePercent:FeePercent[Bought], refUserID:RefUserID
  ) extends Order[Fiat, Coin, Bought](id, userID, rate, vol, time, origVol, Closed) {
    lazy val keys = keysData
    lazy val vals = valsData
  }
  
  // represents the output of a trade matching for some given bid/ask/marker-order
  case class MemTrade[Fiat<: Cur, Coin<: Cur, Sold <: Cur](
    volLeft:Option[Amt[Coin]], thatCompletedOrders:Iterable[MemComplete[Fiat, Coin, Sold]], 
    thatPartialOrders:Option[MemPartial[Fiat, Coin, Sold]], fiatTraded:Amt[Fiat], coinTraded:Amt[Coin]
  )
  
  // def asPriority(a:Any) = a.asInstanceOf[Priority]
  
  case class RateVol[Fiat<: Cur, Coin<: Cur](rate:Rate[Fiat, Coin], vol:Amt[Coin]) extends JsonFormatted {
    val keys = Array("rate", "vol")
    val vals = Array[Any](rate, vol)
    def toSimpleRateVol = SimpleRateVol(rate.rate, vol.amt)
  }

  case class SimpleRateVol(rate:BD, vol:BD) extends JsonFormatted {
    val keys = Array("rate", "vol")
    val vals = Array[Any](rate, vol)
  }

  case class Approx[Fiat<: Cur, Coin<: Cur, Bought <: Cur, Which <:Cur](
    amt:Amt[Which], optRateToUse:Option[Rate[Fiat, Coin]]
  )(implicit ev1: ¬¬[Bought] <:< (Fiat ∨ Coin), ev2: ¬¬[Which] <:< (Fiat ∨ Coin), ev3: Fiat =!= Coin) extends JsonFormatted {
    val keys = Array("amt", "rateToUse")
    val vals = Array[Any](amt, optRateToUse)
  }
  case class TickerData(market:String, high: BD, low: BD, avg:BD, ask: BD, bid: BD, vol:BD, amt:BD)  // last 24 hours

  case class MemOpen[Fiat<: Cur, Coin<: Cur, Bought <:Cur](
    override val id:OrderID, 
    override val userID:UserID, 
    override val rate:Rate[Fiat, Coin], 
    override val vol:Amt[Coin], 
    override val time:Time, 
    override val origVol:Amt[Coin], 
    feePercent:FeePercent[Bought], 
    refUserID:RefUserID
  ) extends Order[Fiat, Coin, Bought](id, userID, rate, vol, time, origVol, Open) {
    val keys = keysData
    val vals = valsData
    //    def toNow = {
    //      new MemNow(
    //        id,
    //        userID,
    //        vol, 
    //        time,
    //        rate * vol,
    //        feePercent,
    //        refUserID
    //      )
    //    }
  }

  //  case class MemNow[Fiat<: Cur, Coin<: Cur, Bought <: Cur](
  //    override val id:OrderID, 
  //    override val userID:UserID, 
  //    override val vol:Amt[Coin], 
  //    override val time:Time, 
  //    maxFiat:Amt[Fiat], 
  //    feePercent:FeePercent[Bought], 
  //    refUserID:RefUserID
  //  ) extends Order[Fiat, Coin, Bought](id, userID, maxFiat/vol, vol, time, vol /* origVol */, Open) {
  //    val keys = keysData :+ "maxFiat"
  //    val vals = valsData :+ maxFiat
  //    
  //    def toBid = new MemOpen(id, userID, infiniteRate(maxFiat.cur, vol.cur), vol, time, vol, feePercent, refUserID)
  //    def toAsk = new MemOpen(id, userID, zeroRate(maxFiat.cur, vol.cur), vol, time, vol, feePercent, refUserID)
  //  }

  /* 
   order is original order ("this" order, the one being processed)
   created is new order (via Option) from "this" order
      it will be None if "this" order has fully completed
      and it will be Some(ord) if "this" is either partly completed or not completed at all
      When "this" is partly completed, the orderID in created will be different from "this" order id, otherwise it will be the same
      
   completed is a collection (with >= 0) elements of the complementary set of orders ("that") [complement of bid is ask and vice versa]
   partial is an option for partial orders from "that" list
   */
  case class MemOutcome[
    Fiat<: Cur, 
    Coin<: Cur, 
    Bought <: Cur, 
    Sold <: Cur
  ](
    order:MemOpen[Fiat, Coin, Bought], // original order with orig rate // Lets say this is an ASK
    created:Option[MemOpen[Fiat, Coin, Bought]], 
         // if any new order is to be created (i.e. if this ASK was not fully completed, and remainider needs to be added)
    completed:Iterable[MemComplete[Fiat, Coin, Sold]], // completed orders on the other side (i.e. BIDS)
    partial:Option[(MemPartial[Fiat, Coin, Sold], MemOpen[Fiat, Coin, Sold])], // partial order on the other side (i.e., BID). 
         // First is the orderID that was partially completed (and deleted from OB), 
         // 2nd is the new order created for the remaining partial
    fiatTraded:Amt[Fiat], coinTraded:Amt[Coin], tradeTime:Time
  )(
    implicit ev: Fiat =!= Coin,
    ev1: Bought =!= Sold
  ) {
    // partial above represents Partial: partial order details, and Order: the new order created from the partial.
    // some sanity checks can be made. For instance Partial.remainingVol == Order.vol and Partial.rate = Order.rate, etc
    
    @deprecated("Should not be used internally. Only for external notifs", "24 Nov 2017")
    val didTradeOccur = created match { // not used anywhere.. only for feeds (i.e., externally)
      case Some(ord) if order.vol === ord.origVol => 
        // trade should not have occured. Hence origVol is same as current vol
        false
      case _ => true
    }
  }
  

}
