
package cs.datastructures

import cs.datastructures.OrderBook._
import cs.datastructures.Users._
import cs.util.Common._
import amit.common.Util._
import amit.common.json.JSONUtil
import amit.common.json.JSONUtil.JsonFormatted
import Exceptions._
import amit.common.json.JSONUtil._
import cs.datastructures.Currencies._
import cs.util.Users._
import cs.util.Common._

object Trades {
  
  case class RateVolTime[Fiat<: Cur, Coin<: Cur](rate:Rate[Fiat, Coin], vol:Amt[Coin], time:Time) extends JsonFormatted {
    override def toString = createJSONString(Array("rate", "vol", "time"), Array(rate, vol, time))
    val keys = Array("rate", s"${vol.cur}", "time")
    val vals:Array[Any] = Array(rate, vol, amit.common.Util.toDateString(time))
  }
  
  case class TradeDetail[Fiat<: Cur, Coin<: Cur](
    id:TradeID, vol:Amt[Coin], 
    fiat:Amt[Fiat], 
    time:Time, avgRate:Rate[Fiat, Coin], 
    maxRate:Rate[Fiat, Coin], 
    minRate:Rate[Fiat, Coin], 
    ordType:OrdType
  )(implicit ev: Fiat =!= Coin) extends JsonFormatted {
    val keys = Array("tradeID", s"${vol.cur}", s"${fiat.cur}", "time", "avg", "min", "max", "type", "humanTime")
    val vals = Array(id, vol, fiat, time, avgRate, minRate, maxRate, ordType, toDateString(time))
    def toRVT = RateVolTime(avgRate, vol, time)
    def toRV = RateVol(avgRate, vol)
    def toSimpleTradeDetail = SimpleTradeDetail(
      id:TradeID, 
      vol.amt, // vol
      fiat.amt, // fiat
      time:Time, 
      avgRate.rate, 
      maxRate.rate, 
      minRate.rate, 
      ordType:OrdType
    )
  } 
  
  case class AggrData[Fiat <:Cur, Coin <:Cur](
    sumFiatVol:FiatVol[Fiat, Coin],
    //    avg:FiatVol[Fiat, Coin],
    //    max:FiatVol[Fiat, Coin],
    //    min:FiatVol[Fiat, Coin],
    avgRate:Rate[Fiat, Coin],
    maxRate:Rate[Fiat, Coin],
    minRate:Rate[Fiat, Coin]
  )
  case class FiatVol[Fiat <:Cur, Coin <:Cur](fiat:Amt[Fiat], vol:Amt[Coin]) extends JsonFormatted {
    if (fiat < 0) throw new Exception("fiat is < 0 : "+fiat)
    if (vol < 0) throw new Exception("vol is < 0 : "+vol)
    val keys = Array(s"${fiat.cur}", s"${vol.cur}")
    val vals:Array[Any] = Array(fiat, vol)
    def +(that:FiatVol[Fiat, Coin]) = FiatVol(fiat + that.fiat, vol+that.vol)
    @deprecated("Can cause division by zero exception", "21 Nov 2017")
    def getRate = fiat / vol
  }

  case class History[Fiat <:Cur, Coin <:Cur](
    min:Rate[Fiat, Coin], 
    max:Rate[Fiat, Coin], 
    avg:Rate[Fiat, Coin], 
    fiat:Amt[Fiat], 
    vol:Amt[Coin], 
    time:Time, 
    open:Rate[Fiat, Coin], 
    close:Rate[Fiat, Coin], 
    numTrades:Long
  ) extends JsonFormatted {
    val keys =            Array("min", "max", "avg", "amt", "vol", "endTime", "open", "close", "numTrades", "humanEndTime")
    val vals:Array[Any] = Array( min,   max,   avg,   fiat,  vol,   time,       open,   close,   numTrades,   toDateString(time))
  }
  
  case class MaxOrMin[Fiat <: Cur, Coin<: Cur](rate:Rate[Fiat, Coin], ids:List[OrderID]) {
    val keys = Array("rate", "ids")
    val vals = Array(rate, encodeJSONArray(ids.toArray))
    override def toString = createJSONString(keys, vals)
  }
  case class ClosedAggr[Fiat <: Cur, Coin<: Cur, Bought <:Cur](
    id:OrderID, closedVol:Amt[Coin], feeCollected:Amt[Bought], fiat:Amt[Fiat], avgRate:Rate[Fiat, Coin]
  ) extends JsonFormatted{
    val keys = Array("id", "closedVol", "feeCollected", "fiat", "avgRate")
    val vals = Array[Any](id, closedVol, feeCollected, fiat, avgRate)
  }
  case class SimpleTradeDetail(
    id:TradeID, 
    vol:BD, // vol
    amt:BD, // fiat
    time:Time, 
    avgRate:BD, 
    maxRate:BD, 
    minRate:BD, 
    ordType:OrdType
  ) extends JsonFormatted {
    val keys = Array("tradeID", "vol", "amt", "time", "avg", "min", "max", "type", "humanTime")
    val vals = Array(id, vol, amt, time, avgRate, minRate, maxRate, ordType.ordTypeString, toDateString(time))
  } 
  case class SimpleOrder( // no types (Cur, etc), used for feed, handlers
    id:OrderID, 
    userID:UserID, 
    rate:BD, 
    vol:BD, 
    time:Time, 
    origVol:BD, 
    status:OrderStatus
  ) extends JsonFormatted { 
    val keys = Array     (
      "id", "userID", "rateSpecified", "vol", "time", "humanTime",       "origVol", "status"       )
    val vals = Array[Any](
      id,    userID,   rate,            vol,   time,   toDateString(time), origVol,  status.toString)
  }
  
  abstract class Order[Fiat<: Cur, Coin<: Cur, Bought <:Cur](
    val id:OrderID, 
    val userID:UserID, 
    val rate:Rate[Fiat, Coin], 
    val vol:Amt[Coin], 
    val time:Time, 
    val origVol:Amt[Coin], 
    val status:OrderStatus
  ) extends JsonFormatted { 
    val keysData = Array     (
      "id", "userID", "rateSpecified", "vol", "time", "humanTime",       "origVol", "status")
    val valsData = Array[Any](
      id,    userID,   rate,            vol,   time,   toDateString(time), origVol,  status.toString)
    def toStatus(newStatus:OrderStatus) = {
      new Order[Fiat, Coin, Bought](id, userID, rate, vol, time, origVol, newStatus) {
        val keys = keysData
        val vals = valsData
      }      
    }
    def toSimpleOrder = SimpleOrder(id, userID, rate.rate, vol.amt, time, origVol.amt, status)    
  }
  
  case class OrigOrder[Fiat <: Cur, Coin <: Cur, Bought <: Cur](
    id:OrderID, 
    userID:UserID, 
    rateSpecified:Rate[Fiat, Coin],
    closedVol:Amt[Coin],
    openVol:Amt[Coin],
    canceledVol:Amt[Coin],
    time:Time,
    closedFiat:Amt[Fiat], // fiatTraded
    feeCollected:Amt[Bought],
    origVol:Amt[Coin],
    closedTradeIDs:Array[TradeID],
    status:OrderStatus
  ) extends JsonFormatted {
    val totalVol = closedVol + openVol + canceledVol
    assert(origVol === totalVol, s"OrigVol ($origVol) != TotalVol ($totalVol)")

    val keys = Array(
      "id", "userID", "rateSpecified", "closedVol", "openVol", s"origVol", "time", "humanTime",
      "closedAmt", "feeCollected", "closedTradeIDs", "status"
    )
    val vals = Array(
      id, userID, rateSpecified, closedVol, openVol, origVol, time, toDateString(time),
      closedFiat, feeCollected, closedTradeIDs, status.toString
    )
    def toSimpleOrigOrder = SimpleOrigOrder(
      id, userID, rateSpecified.rate, closedVol.amt, openVol.amt, canceledVol.amt, time, closedFiat.amt, feeCollected.amt,
      origVol.amt, closedTradeIDs, status, totalVol.amt
    )
  }

  case class SimpleOrigOrder(
    id:OrderID, 
    userID:UserID, 
    rateSpecified:BD,
    closedVol:BD,
    openVol:BD,
    canceledVol:BD,
    time:Time,
    closedFiat:BD, // fiatTraded
    feeCollected:BD,
    origVol:BD,
    closedTradeIDs:Array[TradeID],
    status:OrderStatus,
    totalVol:BD
  ) extends JsonFormatted {
    val keys = Array(
      "id", "userID", "rateSpecified", "closedVol", "openVol", s"origVol", "time", "humanTime",
      "closedAmt", "feeCollected", "closedTradeIDs", "status"
    )
    val vals = Array(
      id, userID, rateSpecified, closedVol, openVol, origVol, time, toDateString(time),
      closedFiat, feeCollected, closedTradeIDs, status.toString
    )
  }

  case class ClosedOrder[Fiat <: Cur, Coin <: Cur, Bought <: Cur](
    tradeID:TradeID, // extra id needed for composite primary key with orderID (since orderID is no longer unique for closed)
    override val id:OrderID, 
    override val userID:UserID,
    override val rate:Rate[Fiat, Coin], // rate specified, NOT the rate actually used for trade
    override val vol:Amt[Coin], 
    override val time:Time, 
    override val origVol:Amt[Coin],    
    feePercent:FeePercent[Bought], 
    feeCollected:Amt[Bought],
    fiat:Amt[Fiat],
    rateUsed:Rate[Fiat, Coin]
  ) extends Order[Fiat, Coin, Bought](id, userID, rate, vol, time, origVol, Closed) {
    //val rateUsed:Rate[Fiat, Coin] = fiat / vol 
    val keys = keysData ++ Array("tradeID", "amt", "rateUsed", "feePercent", "feeCollected")
    val vals = valsData ++ Array( tradeID,   fiat, rateUsed,  feePercent,   feeCollected)
    def toSimpleClosedOrder = SimpleClosedOrder(
      tradeID:TradeID, // extra id needed for composite primary key with orderID (since orderID is no longer unique for closed)
      id:OrderID, 
      userID:UserID,
      rate.rate:BD, // rate specified, NOT the rate actually used for trade
      vol.amt:BD, 
      time:Time, 
      origVol.amt:BD,    
      feePercent.percent:BD, 
      feeCollected.amt:BD,
      fiat.amt:BD,
      rateUsed.rate:BD
    ) 
  } 

  case class SimpleClosedOrder(
    tradeID:TradeID, // extra id needed for composite primary key with orderID (since orderID is no longer unique for closed)
    id:OrderID, 
    userID:UserID,
    rate:BD, // rate specified, NOT the rate actually used for trade
    vol:BD, 
    time:Time, 
    origVol:BD,    
    feePercent:BD, 
    feeCollected:BD,
    amt:BD, // fiat
    rateUsed:BD
  ) extends JsonFormatted {
    val keys = Array     (
      "id", "userID", "rateSpecified", "vol", "time", "humanTime",       "origVol", "status"
    )++ Array("tradeID", "amt", "rateUsed", "feePercent", "feeCollected")
    val vals = Array[Any](
      id,    userID,   rate,            vol,   time,   toDateString(time), origVol,   Closed.toString
    )++ Array( tradeID,   amt, rateUsed,  feePercent,   feeCollected)
  } 

  //  @deprecated("Unused. Aggregates are bad because they don't support Max", "26 Nov 2017") 
  //  case class ClosedOrderNew[Fiat <: Cur, Coin <: Cur, Bought <: Cur](
  //    override val id:OrderID, 
  //    override val userID:UserID,
  //    override val rate:Rate[Fiat, Coin], // rate specified, NOT the rate actually used for trade
  //    override val vol:Amt[Coin], 
  //    override val time:Time, 
  //    override val origVol:Amt[Coin],    
  //    feeCollected:Amt[Bought],
  //    fiat:Amt[Fiat],
  //    avgRateUsed:Rate[Fiat, Coin]
  //  ) extends Order[Fiat, Coin, Bought](id, userID, rate, vol, time, origVol, Closed) {
  //    //val rateUsed:Rate[Fiat, Coin] = fiat / vol 
  //    val keys = keysData ++ Array("amt", "avgRateUsed", "feeCollected")
  //    val vals = valsData ++ Array(fiat, avgRateUsed,  feeCollected)
  //  } 
  
  case class RefPaid[Bought <: Cur](
    userID:UserID,
    tradedUserID:UserID,
    tradeID:TradeID,
    orderID:OrderID,
    refPaid:Amt[Bought],
    refPercent:FeePercent[Bought],
    time:Time
  ) extends JsonFormatted {
    val keys = Array("userID", "tradedUserID", "tradeID", "orderID", "refPaid", "refPercent", "time", "humanTime")
    val vals = Array(userID, tradedUserID, tradeID, orderID, refPaid, refPercent, time, toDateString(time))
  }  
}

//object Test1 extends App {
//  
//  case class Foo(a:Array[String], b:String) extends JsonFormatted {
//    val keys = Array("a", "b")
//    //    JSONUtil.encodeJSONArray(a)
//    //    val vals = Array[Any](JSONUtil.encodeJSONArray(a), b)
//    val vals = Array[Any](a, b)
//  }
//  val x = Foo(Array("X", "Y", "Z"), "Hello")
//  println(" ----> "+x.toString)
//}