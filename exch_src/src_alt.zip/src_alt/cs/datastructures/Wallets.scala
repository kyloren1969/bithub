package cs.datastructures

import amit.common.json.JSONUtil
import amit.common.json.JSONUtil.JsonFormatted
import cs.datastructures.Currencies._
import cs.datastructures.Transfers._

object Wallets {
  type Market = String
  type CurrencySymbol = String
  
  case class LockedBal(locked:Map[Market, BD]) extends JsonFormatted {
    val amt = locked.values.sum
    def getLockedFor(market:String):BD = locked.get(market).getOrElse(0)
    private val lockedJson = locked.map{
      case (m, a) => JSONUtil.createJSONObject(Array("market", "amt"), Array(m, a))
    }.toArray
    val keys = Array("locked")
    val vals:Array[Any] = Array(lockedJson)
  }

  case class TotalBal(currency:String, walletBal:BD, lockedBal:LockedBal) extends JsonFormatted {
    val amt = walletBal + lockedBal.amt
    val keys = Array("currency", "walletBal", "lockedBal", "totalBal", "lockedDetails")
    val vals = Array(currency, walletBal, lockedBal.amt, amt)++lockedBal.vals
  }

  // below for cryptowallet
  case class Spendable(amt:BD, txID:String, vOut:Int, address:String)
  case class To(address:String, amt:BD)
  case class CSAddress(userID:String, addr:String, info:String, time:Long) {
    val id = addr
  }
  case class CSSent(to:Seq[To], internalID:InternalID, txID:ExternalID, inAmt:BD, outAmt:BD, changeAmt:BD, changeAddr:String, feePerByte:BD)


}

