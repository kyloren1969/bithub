
package cs.migration

import mux.db.DBManager
import exch.BTC
import exch.ExchangeMgr
import exch.INR
import mux.db.BetterDB._
import mux.db.config.DBConfigFromFile
import mux.db.core.DataStructures.Col
import mux.db.core.DataStructures._
import DBCols._
import DBMgrs._

object Import {
  // ref   
  // old
  implicit val refDBConfig = new DBConfigFromFile("referrer.properties")
  val refIDCol = Col("refID", STR)
  val feeToRefRatio = Col("refRatio", UINT) // ref is always 1. feeToRefRatio gives how much is fee compared to ref
  // example suppose we give 10% ref, then feeToRefRatio will be 10 (9 will be ours, 1 will be ref)
  
  val refCols = Array(refIDCol, userIDCol, feeToRefRatio, timeCol)
  val refDB = DBManager("ref", refCols, refIDCol)

  val newUserIDCol = Col("newUserID", STR)
  val succRefCols = Array(refIDCol, userIDCol, feeToRefRatio, newUserIDCol, timeCol)  // userID is OLD user (referrer user)
  val succRefDB = DBManager("succRef", succRefCols, newUserIDCol)
  /// 
  def importRefs = {
    import exch.Ref._
    if ($refDB.isEmpty) refDB.select(userIDCol, refIDCol, timeCol).into($refDB)
    if ($succRefDB.isEmpty) succRefDB.select(userIDCol, newUserIDCol, refIDCol, timeCol).into($succRefDB)
  }
  
  def importTrades = {
    val te = ExchangeMgr.getTE("INRBTC")
    val db = te.$tradeDB.tradeDB
    //  tradeIDCol, coinVolumeCol, fiatCol, timeCol, avgRateCol, maxRateCol, minRateCol, ordTypeCol // old trade
    //  tradeIDCol,        volCol, fiatCol, timeCol, avgRateCol, maxRateCol, minRateCol, isBidCol
    if (db.isEmpty) {
      val trades = tradeDBMgr.selectStar.as{a => 
        val i = a.toIterator
        val tradeID = i.next.as[String]        
        val vol = BTC.fromSmallestUnit(i.next.as[Long])
        val fiat = INR.fromSmallestUnit(i.next.as[Long])
        val time = i.next.as[Long]
        val avgRate = i.next.as[Long]
        val maxRate = i.next.as[Long]
        val minRate = i.next.as[Long]
        val isBid = i.next.as[String] == "bid"
        db.insert(tradeID, vol, fiat, time, avgRate, maxRate, minRate, isBid)
      }
    }
  }
  def importOrders = {
    // archive
    //  userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol // old
    //  orderIDCol, userIDCol, rateCol, volCol, timeCol, makerFeePercentCol, takerFeePercentCol, refUserIDCol, isBidCol 
    // active
    //  userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol // old
    //  orderIDCol, userIDCol, rateCol, volCol, timeCol, origVolCol, makerFeePercentCol, takerFeePercentCol, refUserIDCol (blank if none)
    // closed
    //  tradeIDCol, userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol, fiatCol // old
    //  tradeIDCol, orderIDCol, userIDCol, rateCol, volCol, timeCol, origVolCol, feePercentCol, feeCollectedCol, fiatCol, rateUsedCol
    //   (note that above, pri key is tradeIDCol, orderIDCol)
    // fee collected
    //  userIDCol, tradeIDCol, orderIDCol, amountCol, feeRatioCol, feeCollectedCol, (tradeIDCol, orderIDCol) // old
    //  
    // canceled
    //  userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol // old
    //  orderIDCol, userIDCol, rateCol, volCol, timeCol, origVolCol
    // partial record
    //  userIDCol, newOrderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol, orderIDCol, tradeIDCol // old
    //  tradeIDCol, orderIDCol, volCol, prevVolCol, timeCol
    // partial active 
    //  tradeIDCol, userIDCol, orderIDCol, newOrderIDCol // old
    //  (new is not used, record kept with same order id)  
  }
  def importWallet = {
    // TE addresses
    // UW addresses
    // TE conf deposits
    // UW conf deposits
    // TE completed withdraws 
    // UW completed withdraws 
    // 
  }
}
  
