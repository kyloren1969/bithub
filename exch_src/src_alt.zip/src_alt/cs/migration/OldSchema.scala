package cs.migration

import mux.db.{DBManager => DBMgr}
import mux.db.core.DataStructures._
import mux.db.core._

object DBCols {
  val STR = VARCHAR(255)
    
  // for user accounts (balance etc)
  val (userIDCol, coinBalanceCol, fiatBalanceCol) = (Col("userID", STR), Col("balanceCoin", ULONG), Col("balanceFiat", ULONG))
  val (fiatFeeCol, coinFeeCol) = (Col("fiatFee", UINT), Col("coinFee", UINT))
  
  // for transfers // note the typo TRANSFERMEGE
  // we cannot change it now because the columns are named. We must simply use it as it, until we figure out how to rename columns in db
  val (transferIDCol, amountCol, timeCol, transferMsgCol) = (Col("transferID", STR), Col("amount", ULONG), Col("time", ULONG), Col("transferMege", STR))
  
  val signedAmountCol = Col("signedAmount", LONG) // signed can be negative, as in decrement amount
  
  // for orders
  val (orderIDCol, 
       coinVolumeCol, 
       rateCol, 
       fiatCol, 
       priorityCol) = (Col("orderID", STR), 
                       Col("volume", ULONG), 
                       Col("rate", ULONG), 
                       Col("maxFiat", ULONG), // don't know why it is called maxFiat. Should be fiat or totalFiat or something. dig in (where the table is populated) if its "max" of something or just fiat 
                       Col("priority", INT))

  // for trades
  val (tradeIDCol, newOrderIDCol) = (Col("tradeID", STR), Col("newOrderID", STR))
  val (avgRateCol, maxRateCol, minRateCol, ordTypeCol) = (Col("avgRate", ULONG), Col("maxRate", ULONG), Col("minRate", ULONG), Col("ordType", STR))
  
  val (feeRatioCol, feeCollectedCol) = (Col("feeRatio", UINT), Col("feeCollected", ULONG))
  
  val stackTraceCol = Col("stackTrace", BLOB)
  val errorMessageCol = Col("errorMessage", BLOB)

  val hundredPercentFeeCol = Col("hundredPercentFee", ULONG)
  val expiresCol = Col("expires", ULONG)
  val infoCol = Col("info", STR)
  val voucherIDCol = Col("voucherID", STR)
}

object DBSchemas {
  import DBCols._
  // for balances
  val (accountCols, accountPriKeys) = (Array(userIDCol, coinBalanceCol, fiatBalanceCol, coinFeeCol, fiatFeeCol, timeCol), Array(userIDCol)) // timeCol is "joinedTime"
  
//  val 
  val accountBalUpdAuditCols = Array(userIDCol, signedAmountCol, infoCol, timeCol)
  //
  // for deposits, withdrawls
  val (transferCols, transferPriKeys) = (Array(userIDCol, transferIDCol, amountCol, timeCol, transferMsgCol), Array(userIDCol, transferIDCol))
  // for bids, asks
  val (orderCols, orderPriKeys) = (Array(userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol), Array(orderIDCol))
  
  // below: coinVolumeCol, rateCol, timeCol, priorityCol are for new (remaining) order and orderIDCol is for old order
  val partialArchiveOrderCols = Array(userIDCol, newOrderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol, orderIDCol, tradeIDCol) // orderIDCol is oldOrderID (completed)
  val partialArchiveOrderPriKeys = Array(newOrderIDCol)
   
  val completedOrderColsV0 = Array(tradeIDCol, userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol) // fully completed order
  val completedOrderColsV1 = Array(tradeIDCol, userIDCol, orderIDCol, coinVolumeCol, rateCol, timeCol, priorityCol, fiatCol) // fully completed order //fiatCol is total fiat involved in this order (without fee deducted)
                                                                                                                             //  this fiatCol value will be different from the fiat actually added to user table (for asks), which
                                                                                                                             //  contains fee deduced amount. 
                                                                                                                             // The same goes for vol.. This is the actoual coin traded, without fee deducted
                                                                                                                             // 
  val (partialOrderCols, partialOrderPriKeys) = (Array(tradeIDCol, userIDCol, orderIDCol, newOrderIDCol), Array(orderIDCol)) // partially completed order

  val (tradeCols, tradePriKeys) = (Array(tradeIDCol, coinVolumeCol, fiatCol, timeCol, avgRateCol, maxRateCol, minRateCol,ordTypeCol), Array(tradeIDCol))
  //  val (nowCols, nowPriKeys) = (Array(userIDCol, orderIDCol, coinVolumeCol, fiatCol), Array(orderIDCol))
  //  val (completedNowCols, completedNowPriKeys) = (Array(tradeIDCol, orderIDCol, coinVolumeCol, fiatCol), Array(orderIDCol)) // to check pri key ..

  val (feeCols, feePriKeys) = (Array(userIDCol, tradeIDCol, orderIDCol, amountCol, feeRatioCol, feeCollectedCol), Array(tradeIDCol, orderIDCol)) 
  
  val (errorCols, errorPriKeys) = (Array(timeCol, errorMessageCol, stackTraceCol), Array[Col]())
  
  val voucherCols = Array(userIDCol, feeRatioCol, timeCol, expiresCol, infoCol, voucherIDCol)
  val voucherPriKeys = Array(userIDCol, voucherIDCol)

  val globalVoucherCols = Array(feeRatioCol, timeCol, expiresCol, infoCol, voucherIDCol)
  val globalVoucherPriKeys = Array(voucherIDCol)
}

//private object DBTables {
object DBTables {
  import DBSchemas._
  import DBCols._
  // for balances
  val accountTable = Table("account", accountCols, accountPriKeys)
  val accountUpdCoinBalAuditTable = Table("accountUpdCoinBalAudit", accountBalUpdAuditCols, Array[Col]()) // table to see when bal was updated
  val accountUpdFiatBalAuditTable = Table("accountUpdFiatBalAudit", accountBalUpdAuditCols, Array[Col]()) // table to see when bal was updated

  // for deposits, withdrawls
  val (fiatDepositTable, coinDepositTable) = (Table("fiatDeposits", transferCols, transferPriKeys), Table("coinDeposits", transferCols, transferPriKeys))
  val (fiatWithdrawlTable, coinWithdrawlTbale) = (Table("fiatWithdrawls", transferCols, transferPriKeys), Table("coinWithdrawls", transferCols, transferPriKeys))

  // for bids, asks
  // tmp will be useful if we have userMgr and trade engine on different systems. Currently doesn't seem to have any purpose (to check how it is used)
  // archive simply archives all bids (never deletes)
  val (bidsTable, asksTable) = (Table("bids", orderCols, orderPriKeys), Table("asks", orderCols, orderPriKeys))
  val (archiveBidsTable, archiveAsksTable) = (Table("bidsArchive", orderCols, orderPriKeys), Table("asksArchive", orderCols, orderPriKeys))
  
  val (archivePartialNewBidsTable, archivePartialNewAsksTable) = (Table("partialNewBidsArchive", partialArchiveOrderCols, partialArchiveOrderPriKeys), Table("partialNewAsksArchive", partialArchiveOrderCols, partialArchiveOrderPriKeys))
  
  val (tmpBidsTable, tmpAsksTable) = (Table("tmpbids", orderIDCol, orderIDCol), Table("tmpasks", orderIDCol, orderIDCol))
  val (canceledBidsTable, canceledAsksTable) = (Table("canceledBids", orderCols, orderPriKeys), Table("canceledAsks", orderCols, orderPriKeys))
  
  val tradeTable = Table("trades", tradeCols, tradePriKeys)
  val (completedBidsTableV0, completedAsksTableV0) = (Table("completedBids", completedOrderColsV0, orderPriKeys), Table("completedAsks", completedOrderColsV0, orderPriKeys))
  val (completedBidsTableV0Archive, completedAsksTableV0Archive) = (Table("completedBidsV0Archive", completedOrderColsV1, orderPriKeys), 
                                                                    Table("completedAsksV0Archive", completedOrderColsV1, orderPriKeys))
  val (completedBidsTableV1, completedAsksTableV1) = (Table("completedBidsV1", completedOrderColsV1, orderPriKeys), Table("completedAsksV1", completedOrderColsV1, orderPriKeys))
  
  val (partialBidsTable, partialAsksTable) = (Table("partialBids", partialOrderCols, partialOrderPriKeys), Table("partialAsks", partialOrderCols, partialOrderPriKeys))

  val (coinFeeTable, fiatFeeTable) = (Table("coinFee", feeCols, feePriKeys), Table("fiatFee", feeCols, feePriKeys))

  val hundredPercentFeeTable = Table("hundredPercentFees", Array(hundredPercentFeeCol, timeCol), Array(timeCol))
  
  val errorTable = Table("errors", errorCols, errorPriKeys)  

  val coinFeeVoucherTable = Table("coinFeeVoucher", voucherCols, voucherPriKeys)
  val fiatFeeVoucherTable = Table("fiatFeeVoucher", voucherCols, voucherPriKeys)
  val coinFeeGlobalVoucherTable = Table("coinFeeGlobalVoucher", globalVoucherCols, globalVoucherPriKeys)
  val fiatFeeGlobalVoucherTable = Table("fiatFeeGlobalVoucher", globalVoucherCols, globalVoucherPriKeys)
  //  val (buyNowTable, sellNowTable) = (Table("buyNow", nowCols, nowPriKeys), Table("sellNow", nowCols, nowPriKeys))
  //  val (completedBuyNowTable, completedSellNowTable) = (Table("completedBuyNow", completedNowCols, completedNowPriKeys), Table("completedSellNow", completedNowCols, completedNowPriKeys))
  val tables = List(accountTable, 
                    fiatDepositTable, coinDepositTable, 
                    fiatWithdrawlTable, coinWithdrawlTbale, 
                    bidsTable, asksTable, 
                    canceledBidsTable, canceledAsksTable, 
                    tmpBidsTable, tmpAsksTable,
                    completedBidsTableV0, completedAsksTableV0, 
                    completedBidsTableV1, completedAsksTableV1, 
                    completedBidsTableV0Archive, completedAsksTableV0Archive,
                    partialBidsTable, partialAsksTable, archivePartialNewBidsTable, archivePartialNewAsksTable,
                    archiveBidsTable, archiveAsksTable, 
                    coinFeeTable, fiatFeeTable, 
                    tradeTable, 
                    errorTable, 
                    hundredPercentFeeTable, 
                    coinFeeVoucherTable, fiatFeeVoucherTable, 
                    coinFeeGlobalVoucherTable, fiatFeeGlobalVoucherTable)
  // tables foreach (table => println(table.createString))
  //val getTablesString = tables map(_.createSQLString)
}
//protected[users] object DBMgrs {
object DBMgrs {
  import DBTables._
  // db config will be used as DefaultDBConfigFromFile (db
  // with following details
  //    val dbname = read ("dbname", "mydb")
  //    val dbhost = read ("dbhost", "localhost")
  //    val dbms = read ("dbms", "h2")
  //    val dbuser = read ("dbuser", "cs")
      
   
  // for accounts
  val accountDBMgr = new DBMgr(accountTable)
  val accountFiatBalUpdAuditDBMgr = new DBMgr(accountUpdFiatBalAuditTable) // added to audit when balance wad updated
  val accountCoinBalUpdAuditDBMgr = new DBMgr(accountUpdCoinBalAuditTable)
  // for transfers
  val (fiatDepositDBMgr, coinDepositDBMgr)  = (new DBMgr(fiatDepositTable), new DBMgr(coinDepositTable))
  val (fiatWithdrawlDBMgr, coinWithdrawlDBMgr) = (new DBMgr(fiatWithdrawlTable), new DBMgr(coinWithdrawlTbale))

  // for trading
  val (bidsDBMgr, asksDBMgr)  = (new DBMgr(bidsTable), new DBMgr(asksTable))
  val (archiveBidsDBMgr, archiveAsksDBMgr)  = (new DBMgr(archiveBidsTable), new DBMgr(archiveAsksTable))
  val (tmpBidsDBMgr, tmpAsksDBMgr)  = (new DBMgr(tmpBidsTable), new DBMgr(tmpAsksTable))
  val (canceledBidsDBMgr, canceledAsksDBMgr)  = (new DBMgr(canceledBidsTable), new DBMgr(canceledAsksTable))
  val (completedBidsDBMgrV0, completedAsksDBMgrV0) = (new DBMgr(completedBidsTableV0), new DBMgr(completedAsksTableV0))                       
  val (completedBidsDBMgrV1, completedAsksDBMgrV1) = (new DBMgr(completedBidsTableV1), new DBMgr(completedAsksTableV1))                       
  val (completedBidsDBMgrV0Archive, completedAsksDBMgrV0Archive) = (new DBMgr(completedBidsTableV0Archive), new DBMgr(completedAsksTableV0Archive))                       
    // when migrating tables:
    //  completedBidsTableV0 is inserted (after processing) into completedBidsTableV1 and finally
    //  completedBidsTableV0 is emptied 
    //  For reference purposes, the emptied table is backed up to completedBidsTableV0Archive
    //  
    //  the same goes for asks completedAsksTables
  
  val (completedBidsDBMgr, completedAsksDBMgr, tradeDBMgr) = (completedBidsDBMgrV1, completedAsksDBMgrV1, new DBMgr(tradeTable))
  val (partialBidsDBMgr, partialAsksDBMgr) = (new DBMgr(partialBidsTable), new DBMgr(partialAsksTable))
  val (archivePartialNewBidsDBMgr, archivePartialNewAsksDBMgr) = (new DBMgr(archivePartialNewBidsTable), new DBMgr(archivePartialNewAsksTable))
  
  
  val (coinFeeDBMgr, fiatFeeDBMgr) = (new DBMgr(coinFeeTable), new DBMgr(fiatFeeTable))

  val hundredPercentDBMgr = new DBMgr(hundredPercentFeeTable)
  val errorDBMgr = new DBMgr(errorTable)
  val (coinFeeVoucherDBMgr, fiatFeeVoucherDBMgr) = (new DBMgr(coinFeeVoucherTable), new DBMgr(fiatFeeVoucherTable))
  val (coinFeeGlobalVoucherDBMgr, fiatFeeGlobalVoucherDBMgr) = (new DBMgr(coinFeeGlobalVoucherTable), 
                                                                new DBMgr(fiatFeeGlobalVoucherTable))
  // for now trades
  //  val (buyNowDBMgr, sellNowDBMgr) = (new DBMgr(buyNowTable), new DBMgr(sellNowTable))  
  //  val (completedBuyNowDBMgr, completedSellNowDBMgr) = (new DBMgr(completedBuyNowTable), new DBMgr(completedSellNowTable))  
}

