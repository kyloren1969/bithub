
package cs.wallet

import amit.common.Util.tryIt
import cs.datastructures.Currencies.Cur
import mux.coin._
import mux.coin.notifier.AbstractUTXOInspector
import mux.coin.notifier.AbstractUTXONotifier
import mux.coin.notifier.TrustedNode
import mux.coin.notifier.UTXONotifierListeners
import sh.btc.BitcoindAPI
import sh.btc.DataStructures._
import sh.btc.DataStructures.{Tx => BitSTx}
import sh.btc.DataStructures.{Blk => BitSBlk}
import sh.net.Node
import sh.util.BytesUtil._

class RPCNode(val $node:Node) extends TrustedNode with TraitCoinWriter {
  var $optRPC:Option[BitcoindAPI] = None

  def doConnectDrill(
    host:String,
    rpcuser:String, 
    rpcpass:String,
    rpcport:Int
  ) = {
    val $host$ = "54.169.160.38"
    val $rpcport$ = "33565"
    val $rpcuser$ = ""
    val $rpcpass$ = ""
    connectRPC(rpcuser, rpcpass, host, rpcport)
  }
  def connectRPC(userName:String, password:String, host:String, port:Int) = {
    val $host$ = "54.169.160.38"
    val $port$ = "33565"
    val d = new BitcoindAPI(userName, password, s"http://$host:$port")
    val version = d.getSoftwareVersion
    $optRPC = Some(d)
    version
  }
  def disconnectRPC = $optRPC = None
  
  def getConfirmations(txHash: String): Int = {
    val $txHash$ = "b7abcfe328afaf75eae479e205a7122424cc8073e93d13ae227dfd7110775b6f"
    $optRPC.map(_.getConfirmations(txHash)).getOrElse(0)
  }
  
  def getHexTx(txHash: String): String = {
    val $txHash$ = "b7abcfe328afaf75eae479e205a7122424cc8073e93d13ae227dfd7110775b6f"
    $optRPC.map(
      rpc => rpc.getTransaction(txHash).serialize.encodeHex
    ).getOrElse("Not connected to RPC")
  }
  
  def pushTx(hex:String):String = {
    tryIt($node.pushTx(hex))
    tryIt($optRPC.map(_.pushTx(hex)))
    "Ok"
  }
  
  def bitcoinS_connectToPeer(hostName:String, relay:Boolean) = {
    val $hostName$ = "54.169.160.38"
    $node.connectTo(hostName, relay)    
    $node.getPeers
  }
  def bitcoinS_connectToSeeds(relay:Boolean) = {
    $node.connectToAllSeeds(relay)   
    $node.getPeers
  }
  def bitcoinS_disconnectFromPeer(hostName:String) = {
    val $hostName$ = "54.169.160.38"
    $node.disconnectFrom(hostName)
    $node.getPeers
  }
  def bitcoinS_disconnectAll = $node.disconnectFromAll
  def bitcoinS_getPeers = $node.getPeers
}

abstract class CoinNotifier[C <: Cur](c:C, rpcNode:RPCNode) extends AbstractUTXONotifier(c.symbol, rpcNode) { 
  // Second param above is a TrustedReader type (one that contains a def getConfirmations(txHash):Int method)
  lazy val id = "BitcoinS"  
  def toCoinBlock(b:BitSBlk):CoinBlock
  def toCoinTx(t:BitSTx):CoinTx
  println ("STARTING COIN NOTIFIER FOR "+c)
  def downloadBlock(hash:String) = toCoinBlock(rpcNode.$node.getBlock(hash))      
  rpcNode.$node.addOnTxHandler(
    s"bitcoinSNotifier_${c.symbol}", tx => onTx(toCoinTx(tx))  
  )
  rpcNode.$node.addOnBlkHandler(
    s"bitcoinSNotifier_${c.symbol}", blk => onBlk(toCoinBlock(blk), 0)
  )
}

class CoinInspector[C <: Cur](n:CoinNotifier[C]) extends AbstractUTXOInspector(n) 

class CoinListener[C <: Cur](n:CoinNotifier[C]) extends UTXONotifierListeners(n)  


