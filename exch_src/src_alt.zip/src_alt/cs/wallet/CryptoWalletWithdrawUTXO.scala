
package cs.wallet

import cs.datastructures.Currencies.Cur
import mux.coin._
import cs.datastructures.Wallets.CSSent
import cs.datastructures.Wallets.Spendable
import amit.common.Util._
import cs.datastructures.Wallets.To
import cs.util.ErrorLog
import cs.util.Handler
import java.util.concurrent.atomic.AtomicBoolean
import mux.coin.Util._
import mux.db.BetterDB._
import mux.db.core.DataStructures._
import cs.datastructures.CommonDBCols._
import cs.util.DBs._
import cs.datastructures.Transfers._
import cs.datastructures.Currencies._
import CryptoWalletUtil._

trait CryptoWalletWithdrawUTXO[C <: Cur] extends CryptoWalletWithdraw[C] with CryptoWalletDepositUTXO[C]{
  import $exchangeWallet._
  
  protected val $spentDB = Tab.withName(s"spent_${$cur.symbol}").withConfig($dbconfig).withCols(
    txidCol, vOutCol, $internalTxIDCol
  ).withPriKey(txidCol, vOutCol) 

  protected val $sweptDB = Tab.withName(s"swept_${$cur.symbol}").withConfig($dbconfig).withCols(
    addrCol, $amountCol, $internalTxIDCol, infoCol
  ).withPriKey($internalTxIDCol) 

  val $txCol = Col("tx", BLOB)
  val $numInputsCol = Col("numInputs", UINT) 
  val $numOutputsCol = Col("numOutputs", UINT) 
  val $inAmtCol = Col("inAmt", $curType) 
  val $outAmtCol = Col("outAmt", $curType) 
  val $changeAmtCol = Col("changeAmt", $curType) 
  val $changeAddrCol = Col("changeAddr", STR) 
  val $isSweepCol = Col("isSweep", BOOL)
  protected val $internalTxBlobDB = Tab.withName(s"internalTxBlob_${$cur.symbol}").withConfig($dbconfig).withCols(
    $internalTxIDCol, $txCol
  ).withPriKey($internalTxIDCol) 
  protected val $internalTxDB = Tab.withName(s"internalTx_${$cur.symbol}").withConfig($dbconfig).withCols(
    $internalTxIDCol, txidCol,  // sent txID
    $inAmtCol, // sum of inputs
    $outAmtCol, // sum of outputs INCLUDING change
    $changeAmtCol, 
    $changeAddrCol, // "none" if no change
    $isSweepCol,
    timeCol    
  ).withPriKey($internalTxIDCol) 

  //  var $reuseSameChangeAddress = true // implementation should respect this    
  def getAvailableFunds_NoSeed(maxRows:Int) = {
    $confDepDB.select($amountCol).where(
      txidCol === txidCol.of($unspentDB),
      vOutCol === vOutCol.of($unspentDB)
    ).orderBy($amountCol.decreasing).max(maxRows).firstAsT[BD].sum
  }
  
  def getAvailableFunds(maxRows:Int) = {
    $confDepDB.select($amountCol).where(
      txidCol === txidCol.of($unspentDB),
      vOutCol === vOutCol.of($unspentDB),
      addrCol === addrCol.of($addressGenDB),
      seedHashCol.of($addressGenDB) in $seeds.keys.toArray
    ).orderBy($amountCol.decreasing).max(maxRows).firstAsT[BD].sum
  }
  
  def $getAvailableInputs(maxRows:Int) = {
    $confDepDB.select($amountCol, txidCol, vOutCol, addrCol).where(
      txidCol === txidCol.of($unspentDB),
      vOutCol === vOutCol.of($unspentDB),
      addrCol === addrCol.of($addressGenDB),
      seedHashCol.of($addressGenDB) in $seeds.keys.toArray
    ).orderBy($amountCol.decreasing).max(maxRows).as{a =>
      val i = a.toIterator
      val amt = i.next.as[BD]
      val txID = i.next.as[String]
      val vOut = i.next.as[Int]
      val addr = i.next.as[Address]
      new Spendable(amt, txID, vOut, addr)
    }.toArray
  }
  
  val $maxNoOfInputs:Int
  val $maxNoOfOutputs:Int
  val $maxFeePerWithdraw:BD
  val $minChangeAmount:BD
  val $maxFeePerByte:BD
  val $minFeePerByte:BD
  val $defaultFeePerByte:BD
  def $estimateFeePerByte:Option[BD]  
  def $computeApproxSize(inAddrs:Seq[Spendable], outAddress:Seq[To]):Int
  type PrivKeyInt = BigInt
  def $createSignedTx(inAddrs:Seq[(Spendable, PrivKeyInt)], outAddress:Seq[To]):CoinTx
  def $pushTxAndMonitor(tx:CoinTx):TxHash
  val $sendTxHandler = new Handler[CSSent]
  private def $feePerByte = $estimateFeePerByte.map(_.max($minFeePerByte).min($maxFeePerByte)).getOrElse($defaultFeePerByte)
  
  // add password below
  def sweep(address:Address, amt:BD, info:String) = usingWithdrawLock{ 
    val (internalID, txID) = $send(Array(To(address, amt)), $feePerByte, true, (internalID, txID) => {
        usingCount($sweptDB.insert(address, amt, internalID, info), s"Unable to update sweep DB for internalID $internalID and txID $txID")
      }
    )
    txID
  }
  
  private val $sendLock = new AtomicBoolean(false)
  private def usingSendLock[T](f: => T) = if ($sendLock.compareAndSet(false, true)) {
    try f
    finally $sendLock.set(false)
  } else throw new Exception("Send() is already locked by another process")
  private def $send(
    to:Array[To], 
    feePerByte:BD, 
    isSweep:Boolean,
    doBeforeSend:(InternalID, ExternalID) => Unit
  ):(InternalID, ExternalID) = usingSendLock{
    // make sure dests are EXTERNAL withdraws and don't include change. We need to add that below
    if (to.size > 0) { // if more than 0 withdraws
      if (to.size > $maxNoOfOutputs) throw new Exception(s"Max number of outputs allowed is ${$maxNoOfOutputs}. Currently: ${to.size}")
      if (feePerByte < 0) throw new Exception("Fee (PerKB) must be >= 0. Currently: "+feePerByte)
      val toSend = to.map(_.amt).sum
      val approxTotalToSend = toSend + $maxFeePerWithdraw // assume max fee needed since we don't know how big tx will be
      val (ourCoins, inAmt) = $getSpendableCoinsFor(approxTotalToSend)
      val inputs = ourCoins.map{case (amt, sc) => sc}
      val signedSize = $computeApproxSize(inputs, to)
      val feeNeeded = signedSize * feePerByte
      if (feeNeeded <= feePerByte) throw new Exception(s"feeNeeded ($feeNeeded) is <= feePerByte ($feePerByte)") // sanity check?
      /// bad fix below .. check border cases
      val actualFee = if (feeNeeded < $maxFeePerWithdraw) feeNeeded else $maxFeePerWithdraw
      val actualTotalToSend = toSend + actualFee // now that we know how big approx tx is, lets add real fee
      
      val changeAmt = {
        val backToUs = inAmt - actualTotalToSend // total includes fee
        if (backToUs <= $minChangeAmount) BigDecimal(0) else backToUs       
        // do checks with change
        // if (change <= 5300) .. etc
      }
      if (changeAmt < 0) throw new Exception("Oops: 'in' < 'change' + 'fee' + 'required'. This should not have happened.")
      val (optChangeAddr, outputs) = if (changeAmt == 0) (None, to) else {
        val addr = getChangeAddress // should save as well // need to implement
        (Some(addr), to :+ To(addr, changeAmt))
      }
      val keyMap = $addressGenDB.select(addrCol, seedHashCol, seedIndexCol).where(addrCol in inputs.map(_.address)).as{a =>
        a(0).as[String] -> (a(1).as[String], a(2).as[Int])
      }.toMap
      val inputsKeys = inputs.map{i =>
        val (seedHash, index) = keyMap.get(i.address).getOrElse(throw new Exception(s"No private key details found for address ${i.address}"))
        val seed = $seeds.get(seedHash).getOrElse(throw new Exception(s"No seed found for seedHash $seedHash"))
        (i, getPrvKey(seed, index))
      }
      val tx = $createSignedTx(inputsKeys, outputs)
      val time = getTime
      val internalID = randomAlphanumericString(35)
      val txID = tx.getHashAsString
      val outAmt = outputs.map(_.amt).sum
      // everything done for send.. Now do what has to be done before pushing (such as masking withdraws as complete
      //////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////
      doBeforeSend(internalID, txID)
      // any exception also to be thrown above, else next few lines will send the coins!
      //////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////
      val changeAddr = optChangeAddr.getOrElse("none")
      val err = s"Unable to insert internalID $internalID in sent DB. TxID: $txID."
      usingCount($internalTxDB.insert(internalID, txID, inAmt, outAmt, changeAmt, changeAddr, isSweep, time), err)
      usingCount($internalTxBlobDB.insert(txID, tx.coinSerialize), err)
      inputs.map(i => usingCount($spentDB.insert(i.txID, i.vOut, internalID), s"Error inserting spent ${i.txID}, ${i.vOut}"))
      inputs.map(i => usingCount($unspentDB.deleteWhere(txidCol === i.txID, vOutCol === i.vOut), s"Error deleting unspent ${i.txID}, ${i.vOut}"))
      // now pushing tx        
      try $pushTxAndMonitor(tx) catch {
        case e:Any => ErrorLog.logException("CryptoWalletWithdrawUTXO.$send", e, s"Error pushing $txID with internalID $internalID. Error was: ${e.getMessage}", true)
      }
      //and notify
      $sendTxHandler.doOn(CSSent(to, internalID, txID, inAmt, outAmt, changeAmt, changeAddr, feePerByte))
      (internalID, txID)
    } else throw new Exception("No 'to' address specified in send")
  }
  protected def $getSpendableCoinsFor(total:BD) = { 
    // addrCol, txHashCol, vOutCol, satoshisCol, timeCol, indexCol, keyHashCol
    if ($seeds.isEmpty) throw new Exception("No seeds loaded.")
    
    val avbl = $getAvailableInputs($maxNoOfInputs)
    val sortedAvbl = avbl.sortWith((x, y) => x.amt > y.amt)
    var sum = BigDecimal(0)
    
    val allSum = sortedAvbl.map{
      case s@Spendable(amt, txID, vOut, addr) => 
        val low = sum
        sum = sum + amt
        (amt, low, sum, s)
    }
    
    if (sum < total) throw new Exception("Not enough unspent outputs. Available: "+sum+", required: "+total)
    val (select, reject) = allSum.partition{
      case (amt, low, high, s) => low < total
    }
    (
      select.map{case (amt, low, high, s) => (amt, s)}, 
      select.last._3
    ) // returns total amount in the coins as last param
  }  
  
  // Do not make public, else we will have to implement locking
  protected def $processOnChainWithdraws(
    withdraws:Array[SimpleTransfer], 
    doBeforeSend:(Array[TransferID], InternalID, ExternalID) => Unit
  ):Option[(Array[TransferID], ExternalID)] = {
    val selected = withdraws.sortBy(-_.amt).take($maxNoOfOutputs)
    if (selected.size > 0) {
      val inputs = $getAvailableInputs($maxNoOfInputs)
      val avbl = inputs.map(_.amt).sum - $maxFeePerWithdraw
      if (avbl > 0) {
        var sum = BigDecimal(0)
        val toSend = selected.map {w => 
          sum += w.amt
          (w, sum) // eventually sum will have sum of all open withdrawls because the map completes first then the collect is applied
        }.collect{ 
          case (w, total) if total <= avbl => (w, total)
        }
        val toSendSum = if (toSend.size == 0) BigDecimal(0) else toSend.last._2
        // give warning if hotwallet balance is less
        if (toSendSum < sum) { // note that sum contains the total needed // see above comment
          val shortBy = sum - toSendSum
          ErrorLog.logException("$processOnChainWithdraws", new Exception(s"Insufficient HW balance [1] (short by: $shortBy satoshis)"), "Insufficient balance [1] during withdraw", false)
        }
        if (toSend.size > 0) { //usingAtomicWithdrawLock { // if any open withdraws, process them
          val to = toSend.map{case (w, _total) => To(w.address, w.amt)}            
          val toSendIDs = toSend.map{case (w, _total) => w.id}            
          try {            
            //lastWithdrawTime = getTime
            val (internalID, txID) = $send(to, $feePerByte, false, (internalTxID, txHash) => doBeforeSend(toSendIDs, internalTxID, txHash))            
            Some((toSendIDs, txID))
          } catch {
            case e:Throwable => ErrorLog.logException("CryptoWalletWithdrawUTXO.$processOnChainWithdraws", e, "Error while trying to call $send", true)
              None
          } 
        } else None
      } else { // error
        val shortBy = selected.map(_.amt).sum + $maxFeePerWithdraw
        ErrorLog.logException("$processOnChainWithdraws", new Exception(s"Insufficient HW balance [2] (short by: $shortBy satoshis)"), "Insufficient balance [2] during withdraw", false)        
        None
      }
    } else None
  }
  // implement locking in above
}
