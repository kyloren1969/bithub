
package cs.wallet

import cs.datastructures.Currencies.Cur

abstract class FiatWallet[C <: Cur](val $exchangeWallet:ExchangeWallet[C]) {
  import $exchangeWallet._
  // for fiat deposits
  
}
