
package cs.wallet

import CryptoWalletUtil._
import amit.common.cache.ListCache
import amit.common.file.TraitFilePropertyReader
import amit.common.Util._
import mux.coin._
import mux.coin.Util._
import mux.db.BetterDB._
import mux.db.config.TraitDBConfig
import mux.db.core.DataStructures._
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.Numbers._
import cs.datastructures.Wallets._
import cs.datastructures.Currencies._
import cs.datastructures.CommonDBCols._
import cs.util._
import cs.util.Common._
import cs.util.Transfers._
import cs.util.Users._
import cs.util.DBs._ // also for conversions between Rate and Amt to BigDecimal
import cs.datastructures.Exceptions._
import mux.db.core.FKDataStructures._

trait CryptoWalletAddress[C <: Cur] {
  val $exchangeWallet:ExchangeWallet[C]
  import $exchangeWallet._
  type SeedHash = String
  type Seed = String

  protected implicit val $dbconfig = new TraitDBConfig with TraitFilePropertyReader{
    val propertyFile = s"crypto_wallet_${$cur.symbol}.properties"
    val dbname = read ("dbname", s"crypto_wallet_${$cur.symbol}")
    val dbuser = read ("dbuser", "cs")
    val dbpass = read ("dbpass", "eipoxj4i4xm4lmw")
    val dbhost = read ("dbhost", "localhost")
    //val dbms = read ("dbms", "postgresql")
    val dbms = read ("dbms", "h2")
    val connTimeOut = read("dbConnTimeOut", 2000)
    val usePool = read("usePool", true)
    val configSource = "file:"+propertyFile
    
    val seedPassword = read ("seedPassword", "jecnemcjemk4jcm3oedmk3lkmk3m3lx3k32o2k")
  }

  ////////////////////////////////////////////////////////////////////
  ////// Abstract method
  ////////////////////////////////////////////////////////////////////
  def getWatchedAddresses:Array[String]
  
  ////////////////////////////////////////////////////////////////////
  ////// Abstract method
  ////////////////////////////////////////////////////////////////////
  def isValidAddress(address:String):Boolean
  
  ////////////////////////////////////////////////////////////////////
  ////// Abstract method
  ////////////////////////////////////////////////////////////////////
  protected def $getAddress(prvKey:BigInt):String
  
  ////////////////////////////////////////////////////////////////////
  ////// Abstract method
  ////////////////////////////////////////////////////////////////////
  protected def $addAddressToWatch(address:String):Unit

  // WARNING: Never delete from this DB
  protected val $addressGenDB = Tab.withName(s"addrssGenenerated_${$cur.symbol}").withConfig($dbconfig).withCols(
    addrCol, seedHashCol, seedIndexCol, isAddrAssignedCol, timeCol
  ).withPriKey(addrCol) 
  
  // WARNING: Never delete from this DB
  protected val $assignedDB = Tab.withName(s"assignedAddress_${$cur.symbol}").withConfig($dbconfig).withCols(
    addrCol, userIDCol, infoCol, isAddrUsedCol, timeCol
  ).withPriKey(addrCol)
      
  $assignedDB.addForeignKey(new Link(addrCol, $addressGenDB.getTable, FkRule(Restrict, Restrict)))
    
  /////////////
  def assignTopUpAddress(label:String) = assignAddress(topUpID, label)

  def getUserID(address:String):Option[String] = {
    $assignedDB.select(userIDCol).where(addrCol === address).firstAsT[String].headOption
  }
  //private val $depositCache = new ListCache[UserID, TransferID, Transfer[C]](MaxLimit, true, $db_getDeposits(_, MaxTime, MaxLimit, 0), true)
  val $maxNumAddresses = 100
  val $addrCache = new ListCache[UserID, Address, CSAddress]($maxNumAddresses, true, userID => $getAddresses_fromDB(userID, $maxNumAddresses), true)
  
  def getAddresses(userID:UserID) = $addrCache.getItems(userID)
  
  def $getAddresses_fromDB(userID:String, max:Int) = {
    $assignedDB.select(addrCol, infoCol, timeCol).where(userIDCol === userID).max(max).orderBy(timeCol.decreasing).as{a =>
      val i = a.toIterator
      val addr = i.next.as[Address]
      val info = i.next.as[String]
      val time = i.next.as[Long]
      CSAddress(userID, addr, info, time)
    }
  }
  def getChangeAddress = {
    $getAddresses_fromDB(topUpID, 1).headOption.map(_.addr).getOrElse{
      assignTopUpAddress("New address")
    }
  }
  def assignAddress(userID:String, label:String) = {
    if ($assignedDB.countWhere(userIDCol === userID, isAddrUsedCol === false) > 0) throw new Exception("Unused address exists")
    val addr = $addressGenDB.select(addrCol).where(isAddrAssignedCol === false).orderBy(seedIndexCol).max(1).firstAsT[Address].headOption.getOrElse{
      val error = new Exception("No addresses available")
      ErrorLog.logException("CryptoWalletAddress.assignAddress", error, s"No addresses available (userID: $userID)", false)
      throw error
    }
    val time = getTime
    $addressGenDB.update(isAddrAssignedCol <-- true).where(addrCol === addr)
    if (!$addressGenDB.select(isAddrAssignedCol).where(addrCol === addr).firstAsT[Boolean].headOption.get) throw new Exception("Unable up assign address")
    $assignedDB.insert(addr, userID, label, false, time)
    if ($assignedDB.select(userIDCol).where(addrCol === addr).firstAsT[String].headOption.get != userID) throw new Exception("Unable up validate assigned address")
    $addAddressToWatch(addr)
    $addrCache.removePriKey(userID)
    addr
  }
  def generateOfflineAddresses(max:Int, seed:SeedHash, password:String) = if (password == $dbconfig.seedPassword){
    val hash = getSeedHash(seed)
    val time = getTime
    val start = $addressGenDB.aggregate(seedIndexCol.max).where(seedHashCol === hash).firstAsInt + 1
    (start to (max + start - 1)).map {i =>
      val addr = $getAddress(getPrvKey(seed:String, i:Int))
      $addressGenDB.insert(addr, hash, i, false, time)
    }.sum
  } else throw new Exception("Invalid password")
}

