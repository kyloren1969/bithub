
package exch

import cs.datastructures.Transfers._
import cs.datastructures.Wallets._
import cs.wallet.CryptoWallet
import mux.coin.CoinTx
import mux.coin.Dest
import mux.coin.SpendableCoins
import mux.coin.Util._
import mux.coin.btc.BitcoinSUtil
import sh.btc.BitcoinS
import sh.btc.BitcoinS._
import sh.btc.PrvKey_P2SH_P2WPKH
import cs.datastructures.Currencies._

object BTC_CryptoWallet extends CryptoWallet(BTC_ExchangeWallet) {
  import $exchangeWallet._
  lazy val $minConf = 1
  BTC_Notifier.defaultMinConfs = $minConf
  def $addAddressToWatch(address: String) = BTC_Listener.addAddressToWatch(address, "exchwallet")
  def isValidAddress(address: String) = BitcoinS.isValidAddress(address)
  protected def $addOnCoinReceive(f: OnCoinReceive): Unit = BTC_Listener.addOnCoinsReceive("exchwallet", f)
  def $getAddress(prvKey: BigInt) = new PrvKey_P2SH_P2WPKH(prvKey, isMainNet).pubKey.address
  def getWatchedAddresses = BTC_Notifier.watchAddrMap.keys.toArray
  /////////////////////////////////
  val $maxNoOfInputs = 250
  val $maxNoOfOutputs = 100  
  val $maxFeePerWithdraw = BigDecimal(0.01)  
  val $minChangeAmount:BD = BigDecimal(0.0001)
  
  def $pushTxAndMonitor(tx:CoinTx):TxHash = BTC_RPCNode.pushTx(tx.coinSerializeHex)

  val $maxFeePerByte = BigDecimal(0.00000050)
  val $minFeePerByte = BigDecimal(0.00000001)
  val $defaultFeePerByte = BigDecimal(0.00000010)
  
  // is it 1000 or 1024 below?
  def $estimateFeePerByte:Option[BD] = BTC_RPCNode.$optRPC.map(_.estimateSmartFee(6, false)/1000)

  def $computeApproxSize(ins:Seq[Spendable], outs:Seq[To]):Int = {
     /*
      * New formula for calculation:
      * 
      * Before signing, the tx has empty scriptSigs
      * 
      * For uncompressed keys (before SegWit), each scriptSig contains following data (taking from signing code):
      * 
      *       tx.ins(i).setScriptSig((sigBytes.size.toByte +: sigBytes) ++ (pubKey.bytes.size.toByte +: pubKey.bytes))
      *       
      * i.e., 1 byte representing signature sizes 
      * signature bytes (one r and one s value, DER encoded: average 71 bytes https://bitcoin.stackexchange.com/a/12556/2075) 
      * 1 byte representing pub key size
      * pub key bytes (pub key always 64 bytes+1 sign byte 0x04) total of 65 bytes
      * https://bitcoin.org/en/glossary/compressed-public-key
      * 
      * gives total of 65+1+71+1 = 138 bytes for scriptSig
      * 
      * For Segwit, the scriptSig is redeemScript.size + redeemScript bytes
      * 
      * From https://bitcoincore.org/en/segwit_wallet_dev/
      * redeemScript is always 22 bytes
      * 
      * so scriptSig is 23 bytes
      * 
      * der sig is on average 71 bytes.
      * 
      * witness size: 
      * 1 byte 0x02 to represnt 2 stack items
      * 71 + 1 byte to represent signature
      * 33 + 1 byte to represent public key
      * gives total of 107 bytes per witness on average
      * 
      * this formula for ACTUAL signed signature is 
      * 
      *   size of unsigned tx
      * + number of non-segwit inputs * 138 (scriptSig)
      * + number of segwit inputs * 23 (scriptSig)
      * + number of segwit inputs * 107 (witness data)
      * 
      * this is size, NOT vSize
      * 
      * vSize calculation below
      * 
      *   
      */
    val numOuts = outs.size + 1 // always assume change
    val numNonSegWitIns = ins.count(x => BitcoinS.isP2PKH_Address(x.address))
    val numSegWitIns = ins.size - numNonSegWitIns
    val extraSignedSize = numNonSegWitIns*138 + numSegWitIns * (23 + 107)        
    val dummySCs = ins.map{in => SpendableCoins(0, in.txID, in.vOut)}
    val dummyDests = outs.map(out => Dest(out.address, 0)).toArray // dummy value because we dont care about data, just size
    val txUnsignedSize = BitcoinSUtil.createGenericTxSegWit(dummySCs.toArray, dummyDests :+ dummyDests(0)).tx.size // dummy change
    val segWitSignedSize = txUnsignedSize + extraSignedSize

    val witnessSize = numSegWitIns * 107
    val classicSize = segWitSignedSize - witnessSize - 2 // marker and flag are 2 byte total (1 byte each)
    val vSize = math.ceil((3 * classicSize + segWitSignedSize)/4d).toInt
    // sanity check
    if (vSize > segWitSignedSize) throw new Exception(s"VSize ($vSize) > SegWitSigned size ($segWitSignedSize)")
    vSize
  }
  def $createSignedTx(insKeys:Seq[(Spendable, PrivKeyInt)], outs:Seq[To]):CoinTx = {
    val (ins, keys) = insKeys.unzip
    val sc = ins.map(in => SpendableCoins($cur.toSmallestUnit(in.amt), in.txID, in.vOut)).toArray
    val dests = outs.map(out => Dest(out.address, $cur.toSmallestUnit(out.amt))).toArray
    val gTx = BitcoinSUtil.createGenericTxSegWit(sc, dests)
    val signingDetails = insKeys.map{
      case (in, key) =>
        (BitcoinSUtil.getSegWitKeyFromInt(key.bigInteger).forAddress(in.address), $cur.toSmallestUnit(in.amt))
    }
    BitcoinSUtil.signGenericTxSegWit(gTx, signingDetails.toArray) 
  }
}
