
package cs.util

import cs.datastructures.Errors.CSError

object ErrorLog {
  val errorHandler = new Handler[CSError]
  var debug = false
  errorHandler.addOn(-1, csError => { // basic println logger
      println(" [CSErrorLog] "+csError)
      if (debug) csError.thrown.printStackTrace
    }
  )
  def logException(thrower:String, e:Throwable, info:String, isCritical:Boolean) = {
    errorHandler.doOn(CSError(thrower, e, info, isCritical))
    // info should be Blob mostly?
    // example msg below "AddOrderResult error for (tradeID:$tradeID,fiat:$fiatTraded,coin:$coinTraded,orig:$origOrd,outcome:$outcome,cur:$cur)"
  }
}
