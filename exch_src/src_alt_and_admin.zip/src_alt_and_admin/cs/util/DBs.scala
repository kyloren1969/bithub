
package cs.util

import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook.OrdType
import cs.datastructures.Users._
import mux.db.DBManager
import mux.db.core.DataStructures.DBException
import amit.common.Util._ 

object DBs {
  import java.util.concurrent._
  
  val MaxLimit = 100 // for max in (from, to, max, offset)
  
  def usingAtomicLock[T](lock:atomic.AtomicBoolean)(f: => T):T = {
    while (!lock.compareAndSet(false, true)) {TimeUnit.MILLISECONDS.sleep(10)}
    try f
    finally lock.set(false)
  }
  def usingCount(func: => Long, str:String) = {
    func match {
      case 1 => 1
      case 0 => throw new DBException(str+": No rows updated") 
      case any => throw new DBException(str+s": Multiple rows updated ($any)") 
    }
  }
  // below converts Amt and Rate to BigDecimal for storing in db
  mux.db.core.Util.addType{
    _ match {
      case a:Amt[_] => a.amt
      case r:Rate[_, _] => r.rate
      case f:FeePercent[_] => f.percent
      case o:OrdType => o.ordTypeString
      case Some(s:String) => s
      case None => ""
      case any => any
    }
  }
  
  def getPriKeyID(db:DBManager, size:Int = 34) = {
    if (db.table.priKey.size != 1) throw new Exception("Method getPriKeyID is valid only for single primary key column")
    var id = randomAlphanumericString(size)
    while(db.exists(db.table.priKey.head === id)) {
      id = randomAlphanumericString(size)
    }
    id
  }
}
