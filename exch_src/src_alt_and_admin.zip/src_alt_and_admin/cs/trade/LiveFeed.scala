package cs.trade

import amit.common.file._
//import cs.exchange.trade._
//import cs.exchange.util.Feeds._
import scala.collection.mutable.{Queue => MQ}
import scala.collection.mutable.{Set => S}
import amit.common.Util._
import cs.datastructures.Users._
import cs.datastructures.Feeds._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Currencies._
//import cs.exchange.datastructures.Markets._
import cs.util.Feeds._
import cs.datastructures.Numbers._
import cs.trade._

abstract class LiveFeed[Fiat <:Cur, Coin <:Cur] (
  val tm:TradeMethods[Fiat, Coin], h:TradeHandlers[Fiat, Coin]
) {
  import FeedUtil._
  val qSize: Int
  val startTime = getTime
  
  type RVT = RateVolTime[Fiat, Coin]
  type Q = MQ[RVT] // mutable queue of RateVolTime 
  type TQ = MQ[(RVT, OrdType)] // mutable queue of RateVolTime 
  type FN = RVT => Unit // Function mapping RateVolTime to Unit
  type FNU = () => Unit // Function mapping Unit to Unit
  type ON = S[FN] // onEvent handler (containing set of FNs)
  type ONU = S[FNU] // onEvent handler (containing set of FNUs)

  type RATE_VOL = RateVol[Fiat, Coin]
  type RATE = Rate[Fiat, Coin]
  type COIN = Amt[Coin]
  type FIAT_VOL = FiatVol[Fiat, Coin]
  type TRADE_DETAIL = TradeDetail[Fiat, Coin]
  type ORDER[Bought <: Cur] = Order[Fiat, Coin, Bought]
  type HISTORY = History[Fiat, Coin]
  type HISTORIES = List[HISTORY]
  
  def addToON(on:ON, fn:Array[FN]) { on ++= fn }
  def addToONU(onu:ONU, fn:Array[FNU]) { onu ++= fn }
  
  def uptimeMillis = getTime - startTime
  // following are defined as vars so that can be changed dynamically at runtime
  // qSize defines the size of live feed queue. Currently this contains following:
  //   1. Recent bids created by users. (bidQ)
  //      These are just the bid created and do not represent "live" (or active bids)
  //      since they could have got canceled later on. This just streams the bids made.
  //   2. Recent asks (askQ) -- similar to above
  //   3. Recent buys (buyTradeQ) -- these are recent trades that happened when a user clicked "buy"
  //   4. Recent sells (sellTradeQ) -- similar to above but with "sell"
  //   
  //   The queues are kept to a size defined by qSize. Initially when the application starts, these queues 
  //   are filled using the database. Later on as the application runs, these queues are kept updated by live data
  //   (i.e., database is used only during initial start for populating the above queues)
    
  //  /////////////////////////////////////////////////////////////////////
  //  //// live feed data start ///////////////////////////////////////////
  //  /////////////////////////////////////////////////////////////////////
  /**
   * public methods, used for accessing the live feed data
   * contains last 15 trades, bids, asks, last rate, last vol, current bid, current ask
   */
  
  private def db_getFullChart   = tm.db_getHistoryFrom(0, OneMonth)
  private def db_getYearChart   = tm.db_getHistoryFrom(getTime - OneYear, OneMonth)
  private def db_getMonthChart  = tm.db_getHistoryFrom(getTime - OneMonth, OneDay)
  private def db_getWeekChart   = tm.db_getHistoryFrom(getTime - OneWeek, OneHour)
  private def db_getDayChart    = tm.db_getHistoryFrom(getTime - OneDay, OneHour)
  private def db_getHourChart   = tm.db_getHistoryFrom(getTime - OneHour, OneMin)
  private def db_getMinuteChart = tm.db_getHistoryFrom(getTime - OneMin, OneSec)

  private def db_get24HrData:AggrData[Fiat, Coin] = { 
    val now = getTime
    tm.db_getRecentData(now - OneDay, now)
  }

  
  // following gives top live bids/asks (from orderbook) [Collection]
  var (aggrBids, aggrAsks):(Array[RATE_VOL], Array[RATE_VOL]) = (
    tm.$getTopBids_RateVol(qSize), 
    tm.$getTopAsks_RateVol(qSize)
  ) // aggregate stuff 
    // private functions for initially populating queues
    // these read from db. 
  private val trades = tm.db_getRecentTradesMillis(qSize)
  private val (buyTrades, sellTrades):(List[TRADE_DETAIL], List[TRADE_DETAIL]) = trades.partition(_.ordType == Bid)  
  
  private def toRVT[Bought <: Cur](o:ORDER[Bought]) = new RVT(o.rate, o.vol, o.time)
  //private val (bids,asks) = (tm.getAllOpenBids(qSize).map(toRVT), tm.getAllOpenAsks(qSize).map(toRVT))
  private val (bids,asks) = (tm.$db_getAllOpenBids(qSize).map(toRVT), tm.$db_getAllOpenAsks(qSize).map(toRVT))
  
  // following queues gives feed of recent trades,bids,asks (from orders created) [Collection]
  
  val (buyTradeQ, sellTradeQ, bidQ,askQ):(Q,Q,Q,Q)=(
    MQ(buyTrades.map(_.toRVT).sortBy(- _.time): _*),
    MQ(sellTrades.map(_.toRVT).sortBy(- _.time): _*),
    MQ(bids.sortBy(- _.time):_*),
    MQ(asks.sortBy(- _.time):_*)
  ) // mutable queue so val // individual bids, user specific (not consolidated)
  
  val tradeQ:TQ = MQ(trades.sortBy(- _.time).map(td => (td.toRVT, td.ordType)): _*)
  
  // the following keep details of the last trade information. Initially on program start, this is populated from db
  // later on this information is kept updated using live data as the program runs
   
  //tm.$db_getAllOpenBids(1).headOption
  
  var (lastTrade:TRADE_DETAIL,highestBidRate:RATE,lowestAskRate:RATE)=(
    tm.db_getAllTrades(MaxTime, 1, 0).headOption.getOrElse(tm.$noTrade), 
    tm.$db_getHighestBidRate,
    tm.$db_getLowestAskRate
  )
  // following are aggregate functions. Initially these are 
  val last24HrData = db_get24HrData
  var sum24HrFiatVol:FIAT_VOL = last24HrData.sumFiatVol // FiatVol(0, 0)
  var avg24HrRate:RATE = last24HrData.avgRate
  var (max24HrRate, min24HrRate):(RATE,RATE)=(last24HrData.maxRate, last24HrData.minRate) // initially set to zero.. will be update below immediately
  
  val zeroR = zeroRate(tm.$fiat, tm.$coin) 
  
  var (
    sum24HrFiatVolDiff:FiatVolDiff[Fiat, Coin], 
    avg24HrRateDiff:BD, // using BigDecimal because Rate does not allow negative values (for safety
    max24HrRateDiff:BD, // using BigDecimal because Rate does not allow negative values (for safety 
    min24HrRateDiff:BD // using BigDecimal because Rate does not allow negative values (for safety
  ) = 
    (zeroDiff(tm.$fiat, tm.$coin), zeroR.rate, zeroR.rate, zeroR.rate)  
  var (highestBidDiff, lowestAskDiff) = (zeroR.rate, zeroR.rate)
  
  // following are for charts anhd graphs
  var (minutely:HISTORIES, hourly:HISTORIES, daily:HISTORIES, weekly:HISTORIES, monthly:HISTORIES, yearly:HISTORIES, full:HISTORIES) = 
      (db_getMinuteChart, db_getHourChart, db_getDayChart,  db_getWeekChart, db_getMonthChart,  db_getYearChart, db_getFullChart)
  /////////////////////////////////////////////////////////////////////
  //// live feed data end /////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////
  val (onBuyTrade, onSellTrade, onAsk, onBid, onCancelAsk, onCancelBid, onOBChange):
  (ON,ON,ON,ON,ON,ON,ONU)=(S(),S(),S(),S(),S(),S(),S())

  
  /*
   * for adding handlers
   */
  def addOnBid(fn:FN*) = addToON(onBid, fn.toArray)
  def addOnAsk(fn:FN*) = addToON(onAsk, fn.toArray)
  def addOnBuyTrade(fn:FN*) = addToON(onBuyTrade, fn.toArray)
  def addOnSellTrade(fn:FN*) = addToON(onSellTrade, fn.toArray)
  def addOnCancelAsk(fn:FN*) = addToON(onCancelAsk, fn.toArray)
  def addOnCancelBid(fn:FN*) = addToON(onCancelBid, fn.toArray)
  def addOnOBChange(fnu:FNU*) = addToONU(onOBChange, fnu.toArray)
  
  addOnBid(rv => enqueue(bidQ,rv.rate, rv.vol))  // on new bid, add to queue of latest bids, automatically removes oldest bid
  addOnAsk(rv => enqueue(askQ,rv.rate, rv.vol)) // on new ask, add to queue of latest asks, automatically removes oldest ssk
  addOnBuyTrade(rv => enqueue(buyTradeQ,rv.rate, rv.vol)) // on new trade, add to queue of latest trades, automatically removes oldest trade
  addOnSellTrade(rv => enqueue(sellTradeQ,rv.rate, rv.vol)) // on new trade, add to queue of latest trades, automatically removes oldest trade
  addOnBuyTrade(rv => enqueue(tradeQ,rv.rate, rv.vol, Bid)) // on new trade, add to queue of latest trades, automatically removes oldest trade
  addOnSellTrade(rv => enqueue(tradeQ, rv.rate, rv.vol, Ask)) // on new trade, add to queue of latest trades, automatically removes oldest trade

  h.createAskHandler.addOn(299093, ask => feedNewAsk(ask.rate, ask.vol))
  h.createBidHandler.addOn(299093, bid => feedNewBid(bid.rate, bid.vol))
  h.tradeHandler.addOn(299093, feedNewTrade)
  h.cancelAskHandler.addOn(299093, ask => feedNewCancelAsk(ask.rate, ask.vol))
  h.cancelBidHandler.addOn(299093, bid => feedNewCancelBid(bid.rate, bid.vol))
  h.obChangeHandler.addOn(299093, Unit => feedNewOBChange)
  //  doRegularly({
  //      if (debug) println(" [DEBUG] updating minuteChart")
  //      minutely = db_getMinuteChart
  //    }, OneMin) // do every minute // may remove
  doRegularly({
      if (debug) println(" [DEBUG] updating hourChart")
      hourly = db_getHourChart
      update24HrData
    }, TenMins)  // do every 10 minutes
  doRegularly({
      if (debug) println(" [DEBUG] updating dailyChart")
      daily = db_getDayChart
    }, OneHour) 
  doRegularly({
      if (debug) println(" [DEBUG] updating weeklyChart")
      weekly = db_getWeekChart
      monthly = db_getMonthChart
    }, OneDay)
  doRegularly({
      if (debug) println(" [DEBUG] updating monthlyChart")
      yearly = db_getYearChart
      full = db_getFullChart
    }, OneWeek)
    
  // following are for internal use only (i.e. within the TradingEngine project), 
  // for example when the TradeMgr internally feeds a new trade to livefeed
  protected[cs] def feedNewBid(r:RATE, v:COIN) = {
    updateHighestBidRate
    updateLiveBidQ  
    newEvent(r, v, onBid)
  }
  protected[cs] def feedNewAsk(r:RATE, v:COIN) = {
    updateLowestAskRate
    updateLiveAskQ
    newEvent(r, v, onAsk)
  }
  protected[cs] def feedNewCancelAsk(r:RATE, v:COIN) = {
    updateLowestAskRate
    updateLiveAskQ
    newEvent(r, v, onCancelAsk)
  }
  protected[cs] def feedNewCancelBid(r:RATE, v:COIN) = {
    updateHighestBidRate
    updateLiveBidQ
    newEvent(r, v, onCancelBid) 
  }
  protected[cs] def feedNewOBChange = {
    updateBidsAsks
    newEventU(onOBChange) 
  }
  protected[cs] def feedNewTrade(td:TRADE_DETAIL) = {
    if (debug) println (" [DEBUG] (Feed new trade): "+td)
    // assert(td.minRate > 0, "trade happened and min rate is zero. Something is wrong.")  (removed assertion -- was for testing)        
    lastTrade = td
    if (td.maxRate > max24HrRate) {
      if (td.maxRate != max24HrRate) max24HrRateDiff = td.maxRate.rate - max24HrRate.rate
      max24HrRate = td.maxRate
    }
    if (td.minRate < min24HrRate || min24HrRate === 0) {
      if (td.minRate != min24HrRate) min24HrRateDiff = td.minRate.rate - min24HrRate.rate
      min24HrRate = td.minRate
    }
    updateBidsAsks
    update24HrData    
    newEvent(
      td.avgRate, 
      td.vol, 
      td.ordType match { 
        case Bid => onBuyTrade
        case Ask => onSellTrade 
        case NoOrdType => ??? // should not happen
      }
    )
  }
  object FeedUtil {
    def update24HrData = {
      val tmpSum24HrFiatVol = sum24HrFiatVol
      val new24HrData = db_get24HrData
      sum24HrFiatVol = new24HrData.sumFiatVol 
      
      val fiatDiff = sum24HrFiatVol.fiat - tmpSum24HrFiatVol.fiat
      val coinDiff = sum24HrFiatVol.vol - tmpSum24HrFiatVol.vol
      
      if (tmpSum24HrFiatVol != sum24HrFiatVol) 
        sum24HrFiatVolDiff = FiatVolDiff(fiatDiff, coinDiff)
      
      val tmpAvg24HrRate = avg24HrRate
      avg24HrRate = new24HrData.avgRate
      if (avg24HrRate != tmpAvg24HrRate) avg24HrRateDiff = avg24HrRate.rate - tmpAvg24HrRate.rate
      val (tmpMax24HrRate,tmpMin24HrRate)  = (max24HrRate,min24HrRate)
      max24HrRate = new24HrData.maxRate
      min24HrRate = new24HrData.minRate
      if (max24HrRate != tmpMax24HrRate) max24HrRateDiff = max24HrRate.rate - tmpMax24HrRate.rate
      if (min24HrRate != tmpMin24HrRate) min24HrRateDiff = min24HrRate.rate - tmpMin24HrRate.rate
      
    }
    def updateLowestAskRate = {
      val tmpLowestAskRate = lowestAskRate
      lowestAskRate = tm.$getLowestAskRate
      if (tmpLowestAskRate != lowestAskRate) {
        lowestAskDiff = lowestAskRate.rate - tmpLowestAskRate.rate
      }
    }
    def updateHighestBidRate = {
      val tmpHighestBidrate = highestBidRate      
      highestBidRate = tm.$getHighestBidRate
      if (tmpHighestBidrate != highestBidRate) highestBidDiff = highestBidRate.rate - tmpHighestBidrate.rate
    }
    def addToON(on:ON, fn:Array[FN]) { on ++= fn }
    def addToONU(onu:ONU, fn:Array[FNU]) { onu ++= fn }
    def arrToQ[T](q:MQ[T], a:Array[T]) = a.foreach(q.enqueue(_))
    def updateBidsAsks = {
      updateLiveBidQ
      updateLiveAskQ 
      updateLowestAskRate
      updateHighestBidRate
    }
    def updateLiveBidQ = aggrBids = tm.$getTopBids_RateVol(qSize)
    def updateLiveAskQ = aggrAsks = tm.$getTopAsks_RateVol(qSize)

    // changing to futures
    import scala.concurrent.ExecutionContext.Implicits.global
    import scala.concurrent.Future
	
    // def newEvent(rate:Rate, vol:Vol, on:ON) = doOnceNow { // using doOnce as the methods may be blocking, for instance websocket feed...
    def newEvent(rate:RATE, vol:COIN, on:ON) = Future { // using Future as the methods may be blocking, for instance websocket feed...
      val time = getTime
      on.map(f => tryIt(f(new RVT(rate, vol, time))))
    }
    // use futures below??
      // def newEventU(onu:ONU) = doOnceNow(onu.map(f => tryIt(f()))) // using doOnce as the methods may be blocking, for instance websocket feed...
    def newEventU(onu:ONU) = Future(onu.map(f => tryIt(f()))) // using Future as the methods may be blocking, for instance websocket feed...
    //    def onEvent(on:ON, r:Rate, v:Vol) = on.map(f => f(RVT(r, v, getTime)))
    /**
     * for adding live data (bid, ask, trade)
     */
    def enqueue(q:Q, r:RATE, v:COIN) = q.enqueueFinite(new RVT(r, v, getTime))(qSize)
    def enqueue(q:TQ, r:RATE, v:COIN, o:OrdType) = q.enqueueFinite((new RVT(r, v, getTime), o))(qSize)

  }  
}
