
package cs.trade.util

import cs.datastructures.CommonDBCols._
import cs.datastructures.Trades._
import cs.datastructures.Users._
import cs.datastructures.OrderBook._
import cs.util.ErrorLog
import cs.trade.TradeHandlers
//import cs.trade.datastructures.Exceptions._
import cs.util.Common._
import cs.util.Users._
import cs.util.DBs._
import mux.db.core.DataStructures._
import mux.db.BetterDB._
import amit.common.Util._
import cs.datastructures.Currencies._
import cs.datastructures.Exceptions._
import cs.datastructures.OrderBook._
import cs.wallet.ExchangeWallet
import cs.trade._

class TradeResults[Fiat <: Cur, Coin <: Cur](
  fiatWallet:ExchangeWallet[Fiat], coinWallet:ExchangeWallet[Coin],
  tradeDB:TradeDB[Fiat, Coin], handlers:TradeHandlers[Fiat, Coin],
  refFiatFeePercent:FeePercent[Fiat], refCoinFeePercent:FeePercent[Coin]
)(implicit ev: Fiat =!= Coin) {
  def this(
    fiatWallet:ExchangeWallet[Fiat], coinWallet:ExchangeWallet[Coin],
    tradeDB:TradeDB[Fiat, Coin], handlers:TradeHandlers[Fiat, Coin],
    refFiatFeePercent:BD, refCoinFeePercent:BD
  ) = this(
    fiatWallet, coinWallet, tradeDB, handlers, new FeePercent(refFiatFeePercent, fiatWallet.$cur), new FeePercent(refCoinFeePercent, coinWallet.$cur)
  )
  import tradeDB._
  type COIN = Amt[Coin]
  type FIAT = Amt[Fiat]
  type RATE = Rate[Fiat, Coin]
  type MEM_OPEN[Bought <: Cur] = MemOpen[Fiat, Coin, Bought]
  type MEM_COMPLETE[Bought <: Cur] = MemComplete[Fiat, Coin, Bought]
  type MEM_PARTIAL[Bought <: Cur] = MemPartial[Fiat, Coin, Bought]
  type FIAT_WALLET = ExchangeWallet[Fiat] 
  // type COINWALLET = ExchangeWallet[Coin] // asymmetric.. Dont need coin wallet!! 
  type MEM_OUTCOME[Bought <: Cur, Sold <: Cur] = MemOutcome[Fiat, Coin, Bought, Sold]
  val fiatCur = fiatWallet.$cur
  val coinCur = coinWallet.$cur
  implicit val numericRate = num(fiatCur, coinCur) // for doing max and min on rates (for max, min, avg)
  //implicit val numericFiat = num(fiatCur) // for doing sum on fiat amount // already in tradesDB._
      
  private val updBidResult = new UpdateResultDB[Coin, Fiat](bidsDB, (fiat, coin) => coin, coinWallet, refCoinFeePercent)
  private val updAskResult = new UpdateResultDB[Fiat, Coin](asksDB, (fiat, coin) => fiat, fiatWallet, refFiatFeePercent)
  val bidResultUtil = new OrderResultUtil[Coin, Fiat](fiatWallet, updBidResult, updAskResult)
  val askResultUtil = new OrderResultUtil[Fiat, Coin](coinWallet, updAskResult, updBidResult)
      
  def addBidResultToDB(
    outcome:MEM_OUTCOME[Coin, Fiat], 
    takerFee:FeePercent[Coin]
  ) = bidResultUtil.addResultToDB(outcome, takerFee)
  
  def addAskResultToDB(
    outcome:MEM_OUTCOME[Fiat, Coin], 
    takerFee:FeePercent[Fiat]
  ) = askResultUtil.addResultToDB(outcome, takerFee)
  
  // INT/BTC (default):  Fiat = INR, Coin = BTC
  // 
  //    Ord     Bought  Sold    
  //    -----------------------------
  //    BID     Coin    Fiat    
  //    ASK     Fiat    Coin
  class OrderResultUtil[Bought <:Cur, Sold <:Cur](
    soldWallet:ExchangeWallet[Sold], // for refunding excess fiat in Buy
    thisUpdateDB:UpdateResultDB[Bought, Sold], // for updating balance of firing side (successful bid/ask)
    thatUpdateDB:UpdateResultDB[Sold, Bought]  // for updating balance of non-firing side 
  )(
    implicit ev: ¬¬[Bought] <:< (Fiat ∨ Coin), // Bought must be either Fiat or Coin
    ev1: Bought =!= Sold // Bought and Sold should be different
  ) {
    // val ordType = thisOrdDB.ordType
    val ordType = thisUpdateDB.ordType
    def addResultToDB(outcome:MEM_OUTCOME[Bought, Sold], takerFee:FeePercent[Bought]) = {
      // this method treats order as generic type (i.e. does not care if it is a bid or ask. 
      // However, in livefeed, they need the type as well, so adding the orderType parameter as this is the easiest way. 
      val MemOutcome(
        orig:MEM_OPEN[Bought], 
        created:Option[MEM_OPEN[Bought]],
        thatCompl:Iterable[MEM_COMPLETE[Sold]], 
        thatPart:Option[(MEM_PARTIAL[Sold], MEM_OPEN[Sold])], 
        fiatTraded:FIAT, 
        coinTraded:COIN,
        time:Time
      ) = outcome
      /* 
        extraFiat is the (possibly miniscule) difference between the order amount (which user put in)
        and the amount of Fiat actually traded. This could happen if the user made a higher bid than what was asked
        We will initially deduct the full amount. However, if the trade happens at lesser amount, we will give the difference back to the user 
       */

      /* 
       * CASE 1: NEW BID HIGHER THAN EXISTING LOWEST ASK
       * assume there is a ask order of 400 for 1 BTC, and Alice puts a bid of 450 for 1 BTC. Alice will get 1 BTC for 400, but
       * (compl, part) below, containing the complete and partial orders respectively, will use the rates in the original order (450), 
       * not the actual rate of trade (400)
       * In this example, compl below corresponds to Alice's bid order of 1 BTC @ 450, while part is None
       * This amount of Fiat (450) was deducted originally from Alice, while she spent only 400. The difference amount of 50 (extraFiat)
       * will be refunded back to Alice in the call to updateFiatBalance below
       * 
       * CASE 2: NEW ASK LOWER THAN EXISTING HIGHEST BID
       * Now assume there is a bid of 1 BTC @ 400, and Bob puts an ask of 1 BTC @ 350. The trade will happen at 400, 
       * but compl or part (below) will have Bob's order of 1 BTC @ 350. 
       * Consequently, the amount of Fiat added to Bob (via thisUpdBal below) will be 350 only. 
       * The difference of 50 is added in the line below when calling updateFiatBalance
       * 
       * Thus the difference works for both bids and asks.
       * 
       * However we take only bids into account.. Why? See below (essentially due to fees)
       */
      //assert((coinTraded === 0) == (fiatTraded === 0), s"Fiat and Coin must be both zero or non-zero. Coin: $coinTraded, fiat: $fiatTraded")  //   (removed assertion -- was for testing)
      try {
        val (thisCompl, thisPart, extraFiat):(
          Option[MEM_COMPLETE[Bought]], 
          Option[(MEM_PARTIAL[Bought], MEM_OPEN[Bought])], 
          FIAT
        ) = created match {
          case Some(ord) if ord.vol === orig.vol => 
            // old order added to book, and no new order created; implies no trade as well, do nothing
            assert(coinTraded === 0, s"No trade requires zero coin traded. Currently $coinTraded")//     (removed assertion -- was for testing)
            assert(fiatTraded === 0, s"No trade requires zero fiat traded. Currently $fiatTraded")//     (removed assertion -- was for testing)
            (None, None, zero(fiatCur))
          case None => // also can be a Now order!!!
            // assume not a "Now" order; implies order completely satisfied.
            (
              Some(
                MemComplete(
                  orig.id, 
                  orig.userID, 
                  orig.rate, 
                  orig.vol, 
                  orig.time, 
                  orig.origVol, 
                  takerFee, // orig.feePercent, 
                  orig.refUserID
                )
              ), 
              None, 
              (orig.rate * orig.vol) - fiatTraded 
            ) 
          case Some(newOrd) => // this order party satisfied
            val complVol = orig.vol - newOrd.vol
            assert(orig.rate === newOrd.rate, s"Rate mismatch in orders: $orig and $newOrd") //    (removed assertion -- was for testing)
            (
              None, 
              Some(
                (
                  MemPartial(
                    orig.id, 
                    orig.userID, 
                    orig.rate, 
                    complVol, 
                    newOrd.vol, 
                    orig.time, 
                    orig.origVol, 
                    takerFee, //orig.feePercent, 
                    orig.refUserID
                  ), 
                  newOrd
                )
              ), 
              (orig.rate * complVol) - fiatTraded 
            )
        }
        if (extraFiat > 0 && ordType == Bid) { // should happen only for bids. We don't take asks into account. For asks, we will use the fiatTraded value to add the balance
          // for bids we have already deducted so we will add now. This can be directly added because it does not need fee to be taken into account
          // while for asks, the difference needs fee to be deducted and hence we don't process it here but later via updateResult
          //if (debug) 
            println(s" [DEBUG] ORIG RATE: ${orig.rate}")
            println(s" [DEBUG] FIAT DIFFERENCE IN COMPLETE BID $extraFiat")
          if (!soldWallet.isInstanceOf[FIAT_WALLET]) throw new Exception(
            s"Incorrect Wallet. Excpected ${fiatCur.symbol}. Found ${soldWallet.$cur.symbol}"
          )
          usingCount(
            soldWallet.asInstanceOf[FIAT_WALLET].$incrementBalance(
              orig.userID, 
              extraFiat, s"Extra ${fiatCur.symbol} after complete Bid"
            ), 
            s"Could not update ${fiatCur.symbol} balance for user ${orig.userID}. Amount pending: $extraFiat"
          )
        }
        if (coinTraded > 0) { // insert into tradeDB and notify only if coin > 0 
          val tradedRates = thatCompl.map(_.rate) ++ (if (thatPart.isDefined) Iterable(thatPart.get._1.rate) else Iterable())
          val (avgRateComputed, maxRate, minRate) = (fiatTraded / coinTraded, tradedRates.max, tradedRates.min)

          val actualAvgRate = avgRateComputed.min(maxRate).max(minRate)
          
          val tradeID = tradeDB.putTrade(
            coinTraded, fiatTraded, time, 
            actualAvgRate, maxRate, minRate, ordType
          )
          // below should only be needed if actual trade happened. 
          val fiatSumFiringSide = thisUpdateDB.update[Bought](tradeID, thisCompl, thisPart, time, Some(fiatTraded), Some(actualAvgRate))

          val fiatSumOrderBookSide = thatUpdateDB.update[Sold](tradeID, thatCompl, thatPart, time, None, None)

          // check that both are same! (May not be the same! because they have fee deducted)
          handlers.tradeHandler.doOn(
            TradeDetail(tradeID, coinTraded, fiatTraded, time, actualAvgRate, maxRate, minRate, ordType)
          )
        }
        orig.id
      } catch {
        case e:Throwable => 
          // can we get tradeID in below exception?
          ErrorLog.logException(
            "TradeResults.OrderResultUtil.addResultToDB", e, 
            s"AddOrderResult [fiat:$fiatTraded,coin:$coinTraded,origID:${orig.id}]", true)
          throw e
      }
    }
  }
  
  private class UpdateResultDB[Bought <: Cur, Sold <:Cur](
    orderDB:OrderDB[Sold, Bought],
    getBought:(FIAT, COIN) => Amt[Bought],
    boughtWallet:ExchangeWallet[Bought],
    refFeePercent:FeePercent[Bought]
  )(implicit ev: Bought =!= Sold) {
    
    val ordType = orderDB.ordType
    
    def update[B <: Bought]( // Note: the type constraint [B <: Bought] not needed but given for type safety during development
      tradeID:TradeID,
      completeOrds:Iterable[MEM_COMPLETE[Bought]],
      partialOrds:Option[(MEM_PARTIAL[Bought], MEM_OPEN[Bought])], 
      time:Time,
      fiatTraded:Option[FIAT],
      rateToUse:Option[RATE]
    ):FIAT = {
      /*
       this update can be either for the initiating side (i.e. the order that initiated the trade (say an ASK)) [INITIATOR]
       or for an order for the fulfiling side (the ones that completed the initiating order from the order book) [FULFILLER]

       There are some differences between updates of INITIATOR and FULFILER

        For INITIATOR update:
            completeOrds is actually an Option (a superclass of Iterable). It can have at most one item but can also have none.
            partialOrds and completeOrds cannot be both defined. (both can be undefined if no trade happened)
            the actual rate can be different from the order rate (for example ASK placed lower than lowest bid)
              The vol (Coins) is same but the actual fiat amount will be different because the actual rate is diff. This needs to be accounted for. 
              Since vol is same, we will use vol directly
              but we will not use the rate. Rather we have extra param fiatUsed to consider fiat for these type of orders
        For FULFILER update
            completeOrds is actually an Iterable. It can have at zero or more elements (can be more than one as well).
            partialOrds and completeOrds can be both defined. (both can be undefined if no trade happened (to check))
            the actual rate is exactly equal to the one in the order
              Both the vol (coins) and the actual fiat are same because the actual rate is same. 
              Both will be used directly. Fiat will be computed from rate and vol
       if this is an INITIATOR update, then fiatTraded is defined and the fiat we need to use (in updating completed orders and balances)
       otherwise it is not defined
       */
      // can this be called when fiat trade is zero? (or coin traded). I think not!
      // INITIATOR UPDATE // what does this comment mean? (18 Aug 2017)

      if (fiatTraded.isDefined && completeOrds.nonEmpty && partialOrds.isDefined) 
        throw new OrderBookException(s"Both completedOrds and partialOrds are non-empty for INITIATOR side in tradeID $tradeID")
      def getModifiedFiat(rate:RATE, vol:COIN) = if (fiatTraded.isDefined) fiatTraded.get else rate * vol

      val complFiatSum:FIAT = completeOrds.map {compl => 
        orderDB.deleteOpen(compl.id)
        val fiat = getModifiedFiat(compl.rate, compl.vol)
        if (fiat === 0) println("[ZERO FIAT!!!] "+fiat)
        closeWithFee(tradeID, compl.id, compl.userID, compl.rate, compl.vol, time, compl.origVol, compl.feePercent, compl.refUserID, fiat, rateToUse.getOrElse(compl.rate))
        fiat
      }.sum
      
      val partialFiatSum:FIAT = partialOrds match {
        case Some((partCompl, partOpen)) => 
          val (prevOrderID, orderID, origVol, userID) = (partCompl.id, partOpen.id, partCompl.origVol, partCompl.userID) // can be o.origID too
          // assert(p.origVol === o.origVol, s"Partial origID ${p.origID} =/= ${o.origID}")
          // assert(p.userID === o.userID, s"Partial origID ${p.userID} =/= ${o.userID}")
          orderDB.updateOpen(orderID, partOpen.vol)
          orderDB.putPartialRecord(tradeID, orderID, partOpen.vol, partCompl.vol, time)
          val fiat = getModifiedFiat(partCompl.rate, partCompl.completedVol)
          closeWithFee(tradeID, prevOrderID, userID, partCompl.rate, partCompl.completedVol, time, origVol, partCompl.feePercent, partCompl.refUserID, fiat, rateToUse.getOrElse(partCompl.rate))
          fiat
        case _ => zero(fiatCur) 
      }    
      complFiatSum + partialFiatSum
    }  
    private def closeWithFee(
      tradeID:TradeID, ordID:OrderID, userID:UserID, 
      rateSpecified:RATE, vol:COIN, time:Time, origVol:COIN, 
      feePercent:FeePercent[Bought], refUserID:RefUserID, fiat:FIAT, rateUsed:RATE
    )(implicit ev: Bought =!= Sold):Amt[Bought] = { 
      
      val (theirs, fees) = feePercent.split(getBought(fiat, vol))
      
      orderDB.putClosed(tradeID, ordID, userID, rateSpecified, vol, time, origVol, feePercent, fees, fiat, rateUsed)
      
      if (theirs > 0) boughtWallet.$incrementBalance(userID, theirs, s"Complete $ordType with id $ordID")      
      
      refUserID.map{otherUserID => // use feeCollected, refUserID to give referral bonus. Need refPercentFee for this
        val (ours, refShare) = refFeePercent.split(fees)        
        if (refShare > 0) {
          // put in refPaidDB for records
          orderDB.putRefPaid(otherUserID, userID, tradeID, ordID, refFeePercent, refShare, time)
          // privacy loss due to deposit. Best to do direct increment, and not a deposit
          boughtWallet.$incrementBalance(otherUserID, refShare, s"Referral bonus for orderID $ordID, tradeID $tradeID")
        }
      }
      
      handlers.doOnCompleteOrder(
        ClosedOrder(
          tradeID, ordID, userID, rateSpecified, vol, time, origVol, feePercent, fees, fiat, rateUsed
        ), 
        boughtWallet.$cur
      ) // should return future
      theirs // return how much fiat given
    }
  }
}
