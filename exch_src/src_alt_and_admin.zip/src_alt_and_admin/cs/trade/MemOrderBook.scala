package cs.trade

//import TradeDataStructures._
//import cs.util.NumberDataStructures._
//import OrderBookUtil._
//import cs.users.db.util.TradeResultDBUtil
import amit.common.Util._
import cs.datastructures.Currencies._
import cs.datastructures.OrderBook._
//import cs.trade.db.ErrorDB
import cs.util.ErrorLog
import cs.datastructures.Trades._
import cs.datastructures.Users._
import cs.trade.util._
import cs.util.Common._
//import scala.actors.threadpool.Executors
import java.util.concurrent.Executors
import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class MemOrderBook[Fiat <: Cur, Coin <: Cur](fiat:Fiat, coin:Coin)(implicit ev: Fiat =!= Coin) {  
  val u = new MemOrderBookUtil(fiat, coin)
  import u._
  type MEM_OPEN[Buying <: Cur] = MemOpen[Fiat, Coin, Buying]
  type MEM_TRADE[Selling <: Cur] = MemTrade[Fiat, Coin, Selling]
  type FIAT = Amt[Fiat]
  type COIN = Amt[Coin]
  type RATE_VOL = RateVol[Fiat, Coin]
  type MEM_OUTCOME[Buying <: Cur, Selling <:Cur] = MemOutcome[Fiat, Coin, Buying, Selling]
  type ORDER[Buying <: Cur] = Order[Fiat, Coin, Buying]

  //type MEM_NOW[Buying <: Cur] = MemNow[Fiat, Coin, Buying]
  
  type APPROX[Buying <: Cur, Which <: Cur] = Approx[Fiat, Coin, Buying, Which]
  
  val lock = new Object
  
  // add code for min satoshis, min rate, min fee, max satoshis, max rate, etc
  // add code to synchronize mem ob
  // 
  var bidOrderMap = new OrderMap                         
  var askOrderMap = new OrderMap                         
  var bidRateMap = new RateMap[Coin]()(DecreasingOrder)   
  var askRateMap = new RateMap[Fiat]()(IncreasingOrder)                      
  
  // READ ONLY METHODS START (do not modify the Mem OB)
  private def getOrderBookRateVol[Buying <: Cur](rMap:RateMap[Buying], max:Int=0) = {
    // rMap foreach println
    (if (max == 0) rMap else rMap.dropRight(rMap.size-max)).map(x => RateVol(x._1, x._2._1)).toArray
  }
  
  private def getMatchingBidsForAsk(ask:MEM_OPEN[Fiat]):Option[MEM_TRADE[Coin]] = 
    u.getMatchingBids(
      ask, 
      bidOrderMap, 
      bidRateMap
    )
  private def getMatchingAsksForBid(bid:MEM_OPEN[Coin]):Option[MEM_TRADE[Fiat]] = 
    u.getMatchingAsks(
      bid, 
      askOrderMap, 
      askRateMap
    )
  // end private READ methods
  
  def getMemBid(orderID:OrderID):Option[MEM_OPEN[Coin]] = u.getOrder(orderID, bidOrderMap, bidRateMap)
  def getMemAsk(orderID:OrderID):Option[MEM_OPEN[Fiat]] = u.getOrder(orderID, askOrderMap, askRateMap)

  def getBidsRateVol(implicit max:Int=0):Array[RATE_VOL] = getOrderBookRateVol(bidRateMap, max)
  def getAsksRateVol(implicit max:Int=0):Array[RATE_VOL] = getOrderBookRateVol(askRateMap, max)
  
  @deprecated("Seems to be unused", "21 Nov 2017")
  def highestBidRate:RATE = u.getHighestBid(bidRateMap) 
  
  @deprecated("Seems to be unused", "21 Nov 2017")
  def lowestAskRate:RATE = u.getLowestAsk(askRateMap)   
    
  def getTopBids(max:Int):List[ORDER[Coin]] = getTopOrders(max, bidOrderMap, bidRateMap)
  
  def getTopAsks(max:Int):List[ORDER[Fiat]] = getTopOrders(max, askOrderMap, askRateMap)
  
  def getTopUserBids(userID:UserID, max:Int):List[ORDER[Coin]] = getTopUserOrders(userID, max, bidOrderMap, bidRateMap)
  
  def getTopUserAsks(userID:UserID, max:Int):List[ORDER[Fiat]] = getTopUserOrders(userID, max, askOrderMap, askRateMap)
  
  private def getTopOrders[Buying <: Cur](
    max:Int, orderMap:OrderMap, rateMap:RateMap[Buying]
  ):List[MEM_OPEN[Buying]] = {
    var collected = 0
    rateMap.collect{
      case (rate, (coinVol, treeMap)) if collected < max => 
        treeMap.collect{
          case (id, d:OrderDetails[Buying]) if collected < max =>
            collected += 1
            new MemOpen(id, d.userID, rate, d.vol, d.time, d.origVol, d.feePercent, d.refUserID)
        }        
    }.flatten.toList
  }
  
  private def getTopUserOrders[Buying <: Cur](
    userID:UserID, max:Int, orderMap:OrderMap, rateMap:RateMap[Buying]
  ):List[MEM_OPEN[Buying]] = {
    var collected = 0
    rateMap.collect{
      case (rate, (coinVol, treeMap)) if 
        collected < max && 
        treeMap.values.map(_.userID).toSet.contains(userID) 
        => 
        treeMap.collect{
          case (id, d:OrderDetails[Buying]) if collected < max && d.userID == userID =>
            collected += 1
            new MemOpen(id, d.userID, rate, d.vol, d.time, d.origVol, d.feePercent, d.refUserID)
        }        
    }.flatten.toList
  }
  
  def getLockedBidsFiat(userID:UserID) = getLockedOrdersSum(userID, bidOrderMap, bidRateMap, false)
  def getLockedAsksCoin(userID:UserID) = getLockedOrdersSum(userID, askOrderMap, askRateMap, true) // coin
    
  @deprecated("Make this more efficient", "13 Mar 2017")
  private def getLockedOrdersSum[Buying <: Cur](
    userID:UserID, orderMap:OrderMap, rateMap:RateMap[Buying], sumVol:Boolean // else fiat
  ):BD = {
    rateMap.collect{
      case (rate, (_coinVol, treeMap)) if treeMap.values.map(_.userID).toSet.contains(userID) => 
        treeMap.collect{
          case (id, d:OrderDetails[Buying]) if d.userID == userID =>
            if (sumVol) d.vol else rate * d.vol // fiat
        }        
    }.flatten.map{_.amt}.sum
  }
  
  def getHighestBidRate(userID:String):Option[RATE] = u.getHighestOrLowestRate(userID, bidRateMap)
  
  def getLowestAskRate(userID:String):Option[RATE] = u.getHighestOrLowestRate(userID, askRateMap)

  // READ ONLY METHODS END (do not modify the Mem OB)

  // WRITE METHODS START (modify the Mem OB)
  
  private def updateBidsMap(update:(OrderMap, RateMap[Coin])) = { 
    bidOrderMap = update._1
    bidRateMap = update._2 
  } 
  private def updateAsksMap(update:(OrderMap, RateMap[Fiat])) = { 
    askOrderMap = update._1
    askRateMap = update._2 
  } 
  
  // following two method should be made private after testing. They are not supposed to be accessed from outside
  private def addUnmatchedBidToMemOB(ord:MEM_OPEN[Coin]) = 
    updateBidsMap(
      u.getMapsForUnmatchedOrder(
        ord, 
        bidOrderMap, 
        bidRateMap
      )
    )
  private def addUnmatchedAskToMemOB(ord:MEM_OPEN[Fiat]) = 
    updateAsksMap(
      u.getMapsForUnmatchedOrder(
        ord, 
        askOrderMap, 
        askRateMap
      )
    )
  // following updates orderbook (does not touch DB)
  // it uses trade:Trade that contains a list of matches from the order book)
  // it updates the orderbook based on matches
  private def processTrade[Buying <: Cur, Selling <: Cur](
    memOpen:MEM_OPEN[Buying], 
    optTrd:Option[MEM_TRADE[Selling]], 
    addThisToMemOB:MEM_OPEN[Buying] => Unit,
    addThatToMemOB:MEM_OPEN[Selling] => Unit, 
    delThatFromMemOB:OrderID => Unit, 
    isLater:Boolean
  )(implicit 
    ev: ¬¬[Buying] <:< (Fiat ∨ Coin), // Buying must be either Fiat or Coin
    ev1: ¬¬[Selling] <:< (Fiat ∨ Coin), // Selling must be either Fiat or Coin
    ev2: Buying =!= Selling  // Buying and Selling must be different
  ):MEM_OUTCOME[Buying, Selling] = {
    val time = getTime
    optTrd match { // "isLater" is opposite of "now"
    // note that only "isLater" trades needs to be added to order book. Specifically "now" trades are not added
      case Some(trade) => 
        try {
          val newThisOrder:Option[MEM_OPEN[Buying]] =
            if (isLater && trade.volLeft.isDefined) 
              // // create new order only if this is "later" trade
              // below using memOpen.id as origID
              Some(new MEM_OPEN[Buying](memOpen.id, memOpen.userID, memOpen.rate, trade.volLeft.get, time, memOpen.origVol, memOpen.feePercent, memOpen.refUserID)) 
            else 
              None

          newThisOrder.map(addThisToMemOB)

          // below are "that" orders (i.e., other side; so if "this" is bid than "that" is ask)

          trade.thatCompletedOrders.foreach(x => delThatFromMemOB(x.id))

          trade.thatPartialOrders.foreach(p => delThatFromMemOB(p.id))

          val newThatPartialOrders:Option[(MEM_PARTIAL[Selling], MEM_OPEN[Selling])] = 
            trade.thatPartialOrders map{thatPartial => 
              // below using same order id (o.id) for new order)
              // also keeping same time for new partial order, to ensure priority
              (thatPartial, new MEM_OPEN[Selling](thatPartial.id, thatPartial.userID, thatPartial.rate, thatPartial.remainingVol, thatPartial.time, thatPartial.origVol, thatPartial.feePercent, thatPartial.refUserID))
            }

          newThatPartialOrders.foreach {
            case (oldPartial, newPartial) => 
              addThatToMemOB(newPartial)
          }
          new MEM_OUTCOME[Buying, Selling](
            memOpen, 
            newThisOrder,
            trade.thatCompletedOrders, 
            newThatPartialOrders, 
            trade.fiatTraded, 
            trade.coinTraded,
            time
          )
        } catch {
          case e:Throwable => 
            val errorMsg = s"Error in processing trade for order: $memOpen [isLater:$isLater]"
            ////////
            //  ADDED LOGGER
            ////////
            ErrorLog.logException("MemOrderBook.processTrade", e, errorMsg, true)
            throw e
        }
      case None => addThisToMemOB(memOpen)
        new MEM_OUTCOME[Buying, Selling](
          memOpen, 
          if (isLater) Some(memOpen) else None, 
          None, 
          None, 
          zero(fiat), 
          zero(coin), 
          time
        )
    }
  } 
  // end private WRITE methods
  
  //////////////////////////////////////////////////
  //// TO CHECK USE OF synchronized and Future
  //////////////////////////////////////////////////
  //import scala.concurrent.ExecutionContext.Implicits.global
  implicit val ec = ExecutionContext.fromExecutor(Executors.newFixedThreadPool(50))
  import scala.concurrent._
  // following is for "Now" orders (unused)
  @deprecated("Not fully tested", "24 Nov 2017")
  def processNowBuyInMem(buy:MEM_OPEN[Coin]):Future[MEM_OUTCOME[Coin, Fiat]] = Future{
    blocking {
      lock.synchronized{
        //val bid = buy.toBid
        processTrade(
          buy, 
          getMatchingAsksForBid(buy), 
          addUnmatchedBidToMemOB, 
          addUnmatchedAskToMemOB, 
          deleteAskFromMem, 
          false // false implies "isNow" (opposite of "isLater", i.e., remaining SHOULD NOT be added to mem ob or open db)
        )
      }
    }
  }
 
  def getAvailableSellOrdersVol(maxFiat:FIAT):APPROX[Fiat, Coin] = { // :COIN :APPROX[Fiat
  /**
   * If I want to spend maxFiat FIAT to BUY COIN, then how much COIN will expect to I get?
   */
    getApproxCoin[Fiat](maxFiat, askRateMap)
  }
 
  def getAvailableBuyOrdersVol(maxFiat:FIAT):APPROX[Coin, Coin] = { // :COIN
  /**
   * If I want to obtain maxFiat FIAT via SELLING COINs, then how much COIN should expect to I sell?
   */
    getApproxCoin[Coin](maxFiat, bidRateMap)
  }
  
  def getAvailableBuyOrdersFiat(vol:COIN):APPROX[Coin, Fiat] = { // :FIAT
  /**
   * If I SELL vol COIN then how much FIAT will I expect to get?    
   */
    getApproxFiat[Coin](vol, bidRateMap)
  }
  
  def getAvailableSellOrdersFiat(vol:COIN):APPROX[Fiat, Fiat] = { // :FIAT
  /**
   * If I want to BUY vol COIN then how much fiat can I expect to spend?
   */
    getApproxFiat[Fiat](vol, askRateMap)
  }
  
  @deprecated("Not fully tested", "24 Nov 2017")
  def processNowSellInMem(sell:MEM_OPEN[Fiat]):Future[MEM_OUTCOME[Fiat, Coin]] = Future{
    blocking {
      lock.synchronized{
        //val ask = sell.toAsk 
        processTrade(
          sell, 
          getMatchingBidsForAsk(sell),  // processNowOrLaterOrd was called here 
          addUnmatchedAskToMemOB, 
          addUnmatchedBidToMemOB, 
          deleteBidFromMem, 
          false // false implies "isNow" (opposite of "isLater", i.e., remaining SHOULD NOT be added to mem ob or open db)
        )
      }
    }
  }

  //                              bought                    bought, sold               
  def processBidInMem(bid:MEM_OPEN[Coin]):Future[MEM_OUTCOME[Coin, Fiat]] = Future{
    blocking {
      lock.synchronized{
        processTrade(
          bid, 
          getMatchingAsksForBid(bid), 
          addUnmatchedBidToMemOB, 
          addUnmatchedAskToMemOB, 
          deleteAskFromMem, // should not return a Future!
          true // true implies "isLater" (opposite of "isNow", i.e., remaining needs to be added to mem ob and open db)
        )
      }
    }
  }
  //                              bought                    bought, sold               
  def processAskInMem(ask:MEM_OPEN[Fiat]):Future[MEM_OUTCOME[Fiat, Coin]] = Future{
    blocking {
      lock.synchronized{
        processTrade(
          ask, 
          getMatchingBidsForAsk(ask), 
          addUnmatchedAskToMemOB, 
          addUnmatchedBidToMemOB, 
          deleteBidFromMem, // delete also uses lock but since Scala supports reentrant locks, should be fine
          true // true implies "isLater" (opposite of "isNow", i.e., remaining needs to be added to mem ob and open db)
        )
      }
    }
  }
  // deleteBidFromMem uses lock.synchronized, which is also used by processAskInMem
  // Furthermore, processAskInMem calls deleteBidFromMem.
  // Since Scala/Java supports reentrant locks, this should be fine
  // (when called from within processAskInMem, lock would already be held by that method)
  // the lock below won't cause problems because of reentrancy
  // See https://stackoverflow.com/questions/249867/synchronising-twice-on-the-same-object
  def deleteBidFromMem(orderID:OrderID) = {
    blocking {    
      lock.synchronized{
        updateBidsMap(u.getMapsForDeletedOrder(orderID, bidOrderMap, bidRateMap))
        orderID
      }
    }
  }
  def deleteAskFromMem(orderID:OrderID) = {
    blocking {
      lock.synchronized{
        updateAsksMap(
          u.getMapsForDeletedOrder(
            orderID, 
            askOrderMap, 
            askRateMap
          )
        )
        orderID
      }
    }
  }
}


