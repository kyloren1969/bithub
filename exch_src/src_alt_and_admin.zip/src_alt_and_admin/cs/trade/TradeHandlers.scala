package cs.trade

import amit.common.Util._
import cs.datastructures.Users._
import cs.util.Common._
import cs.datastructures.OrderBook._
import cs.datastructures.Currencies._
import cs.datastructures.Numbers._
import cs.datastructures.Trades._
import cs.util.Handler

class TradeHandlers[Fiat <: Cur, Coin <: Cur]($fiat:Fiat, $coin:Coin)(implicit ev: Fiat =!= Coin) {
  require($fiat.symbol != $coin.symbol, s"PRI (${$fiat.symbol}) and SEC (${$coin.symbol}) symbols cannot be same.")  
  type TRADEDETAIL = TradeDetail[Fiat, Coin]
  type ORDER[Bought <: Cur] = Order[Fiat, Coin, Bought]
  type CLOSED_ORDER[Bought <: Cur] = ClosedOrder[Fiat, Coin, Bought]

  def addOnTrade(i:Int, f: SimpleTradeDetail => Unit) = tradeHandler.addOn(i, t => f(t.toSimpleTradeDetail))
  def addOnCreateBid(i:Int, f: SimpleOrder => Unit) = createBidHandler.addOn(i, o => f(o.toSimpleOrder))
  def addOnCreateAsk(i:Int, f: SimpleOrder => Unit) = createAskHandler.addOn(i, o => f(o.toSimpleOrder))
  def addOnCancelBid(i:Int, f: SimpleOrder => Unit) = cancelBidHandler.addOn(i, o => f(o.toSimpleOrder))
  def addOnCancelAsk(i:Int, f: SimpleOrder => Unit) = cancelAskHandler.addOn(i, o => f(o.toSimpleOrder))
  
  def addOnCloseBid(i:Int, f:SimpleClosedOrder => Unit) = closedBidHandler.addOn(i, o => f(o.toSimpleClosedOrder))
  def addOnCloseAsk(i:Int, f:SimpleClosedOrder => Unit) = closedAskHandler.addOn(i, o => f(o.toSimpleClosedOrder))

  val createBidHandler = new Handler[ORDER[Coin]]
  val createAskHandler = new Handler[ORDER[Fiat]]
  
  val cancelBidHandler = new Handler[ORDER[Coin]]
  val cancelAskHandler = new Handler[ORDER[Fiat]]
  
  val closedBidHandler = new Handler[CLOSED_ORDER[Coin]]
  val closedAskHandler = new Handler[CLOSED_ORDER[Fiat]]
  
  // following for all users (not-logged in state)
  val tradeHandler = new Handler[TRADEDETAIL]
  
  val obChangeHandler = new Handler[Unit]

  // INVOKING HANDLERS BELOW
  protected [cs] def doOnCompleteOrder[Bought <: Cur](order:CLOSED_ORDER[Bought], c:Bought) = {
    if (c == $coin) {
      closedBidHandler.doOn(order.asInstanceOf[CLOSED_ORDER[Coin]])
    } else if (c == $fiat) {
      closedAskHandler.doOn(order.asInstanceOf[CLOSED_ORDER[Fiat]])
    } else throw new Exception(s"Expected ${$fiat.symbol} or ${$coin.symbol}. Found ${c.symbol}.")
  }
  
  // addOnTrade(1234, t => doOnOBChange) // addOnTrade not needed because following two are invoked whenever trade happens
  createBidHandler.addOn(1234, t => obChangeHandler.doOn(Unit)) // addOnTrade not needed because this is invoked whenever trade happens
  createAskHandler.addOn(1234, t => obChangeHandler.doOn(Unit)) // addOnTrade not needed because this is invoked whenever trade happens
  cancelBidHandler.addOn(1234, t => obChangeHandler.doOn(Unit))
  cancelAskHandler.addOn(1234, t => obChangeHandler.doOn(Unit))
  
}
