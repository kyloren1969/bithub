
package cs.datastructures

import cs.datastructures.Currencies._
import cs.datastructures.Numbers._
import amit.common.json.JSONUtil.JsonFormatted
import cs.datastructures.Trades._

object Feeds {
  //  case class Last24HrData[
  //    Fiat <: Cur, Coin <: Cur
  //  ](sumFiatVol:FiatVol[Fiat, Coin], maxRate:Rate[Fiat, Coin], minRate:Rate[Fiat, Coin], avgRate:Rate[Fiat, Coin])
  case class FiatVolDiff[
    Fiat <: Cur, Coin <: Cur
  ](fiat:Amt[Fiat], vol:Amt[Coin]) extends JsonFormatted {
    val keys = Array("fiat", "vol")
    val vals = Array[Any](fiat, vol)
  }
  def zeroDiff[
    Fiat <: Cur, Coin <: Cur
  ](fiat:Fiat, coin:Coin) = FiatVolDiff[Fiat, Coin](zero(fiat), zero(coin))
}
