
package cs.datastructures

import Numbers._
object Users {
  type UserID = String
  type RefUserID = Option[UserID] // userID to whom referal is paid (old userID)
  object User {
    def apply(a:Array[Any]) = new User(a(0).asInstanceOf[UserID], a(1).asInstanceOf[Time])
  }
  case class User(userID:UserID, joinDate:Time)
  
}
