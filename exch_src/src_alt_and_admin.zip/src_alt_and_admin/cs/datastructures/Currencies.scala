package cs.datastructures

import amit.common.json.JSONUtil.JsonFormatted
import cs.datastructures.Exceptions._
import cs.util.Common._
import BigDecimal.RoundingMode._
import amit.common.Util._ 

object Currencies {
  def zero[C <: Cur](cur:C) = new Amt(0, cur)
  def infinite[C <: Cur](cur:C) = new Amt(BigDecimal("9"*(cur.nonDecimals)+"."+("9"*cur.decimals)), cur)
  def minOrdAmt[C <: Cur](cur:C) = new Amt(cur.minOrdAmt, cur)

  
  case class Cur(symbol:String, decimals:Int, nonDecimals:Int, minOrdAmt:BigDecimal) extends JsonFormatted { 
    val scale = nonDecimals + decimals
    val oneUnit = BigDecimal(10).pow(decimals)
    if (minOrdAmt <= 0) throw new Exception(s"Min order amount must be > 0. Currently $minOrdAmt")
    def toSmallestUnit(amt:BD):BigInt = (amt * oneUnit).toBigInt
    def fromSmallestUnit(int:BigInt) = new Amt(BigDecimal(int)/oneUnit, this)
    //def this(amt:BD, cur:This) = this(cur)(amt.setScale(cur.decimals, mode).underlying.stripTrailingZeros)
    //def minOrdAmt = new Amt(minOrdAmtBD, this)
    val keys = Array("symbol", "decimals", "nonDecimals", "minOrdAmt")
    val vals = Array(symbol, decimals, nonDecimals, minOrdAmt)
  } 
  val mode = HALF_UP // most efficient, one taught in schools, used for trading
  // https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero
  // HALF_UP is same as half_away_from_zero
   
  type BD = BigDecimal
  def asBD(a:Any) = a.asInstanceOf[BigDecimal]
  //  def asBD(a:Any) = a match { 
  //    case d:BigInt => BigDecimal(d) 
  //    case d:Double => BigDecimal(d)
  //    case d:Long => BigDecimal(d)
  //    case d:BigDecimal => d
  //    case d => throw new ConversionException(d+s"({d.getClass})")
  //  }
    
  // In below, for a rate of 1000 INR/BTC, Fiat will be INR and Coin will be BTC
  // Fiat is always on the numerator
  def zeroRate[Fiat <: Cur, Coin <: Cur](fiat:Fiat, coin:Coin) = new Rate(zero(fiat).amt, fiat, coin)
  def infiniteRate[Fiat <: Cur, Coin <: Cur](fiat:Fiat, coin:Coin) = new Rate(infinite(fiat).amt, fiat, coin)
  

  val feePercentMaxDecimals = 5
  class FeePercent[C <: Cur] private (val cur:C)(val percent:BigDecimal) extends Serializable {
    def this(percent:BigDecimal, cur:C) = this(cur)(percent)
    if (percent < 0) throw new Exception(s"Fee cannot be less than 0. Currently $this")
    def split(amt:Amt[C]) = {
      val fee = amt * this
      val remaining = amt - fee
      (remaining, fee)
    }
    override def toString = percent.bigDecimal.toPlainString + s" % $cur"
    def *(amt:Amt[C]):Amt[C] = new Amt(amt.amt * percent / 100, cur)
  }
  class Rate[Fiat <: Cur, Coin <: Cur] private (val fiat:Fiat, val coin:Coin)(val rate:BD) extends Serializable {//(implicit ev: Fiat =!= Coin)
    if (rate < 0) throw new Exception(s"Rate cannot be < 0. Currently $this")
    // if (rate <= 0) throw new Exception(s"Rate cannot be <= 0. Currently $this")
    
    // primary constructor is private
    // below coinondary constructor is used to 'clean' the value before passing to primary constructor
    // by clean, we mean set the scale correctly
    // println
    // println( " -------------> [ RATE INIT WITH ] "+rate)
    // println
    def this(rate:BD, fiat:Fiat, coin:Coin)(implicit ev: Fiat =!= Coin) = this(fiat, coin)(      
      rate.setScale(fiat.decimals, mode).underlying.stripTrailingZeros
    )
    
    
    // If rate is 1000 INR/BTC then below method will multiply with some BTC amount to get INR
    // 1000 INR/BTC * 10 BTC = 10000 INR (i.e., 10 BTC @ rate of 1000 INR/BTC amounts 10000 INR)
    def *(r:Amt[Coin]):Amt[Fiat] = r * this
    // If rate is 1000 INR/BTC then below method will divide with some INR and take reciprocal amount to get BTC
    // 10000 INR / 1000 INR/BTC = 10 BTC (i.e., 10000 INR @ rate of 1000 INR/BTC amounts to 10 BTC) 
    // since dividing and taking reciprocal is kind of the opposite of /, we use \
    def \(r:Amt[Fiat]):Amt[Coin] = r / this
    def <(that:Rate[Fiat, Coin]) = rate < that.rate
    def <(that:BigDecimal) = rate < that
    def >(that:Rate[Fiat, Coin]) = rate > that.rate
    def >(that:BigDecimal) = rate > that
    def >=(that:Rate[Fiat, Coin]) = rate >= that.rate
    def >=(that:BigDecimal) = rate >= that
    def <=(that:Rate[Fiat, Coin]) = rate <= that.rate
    def <=(that:BigDecimal) = rate <= that
    def ===(that:Rate[Fiat, Coin]) = rate == that.rate
    def ===(that:BigDecimal) = rate == that
    def compare(that:Rate[Fiat, Coin]) = rate.compare(that.rate)
    override def toString = rate.bigDecimal.toPlainString + " "+fiat+"/"+coin
    def min(that:Rate[Fiat, Coin]):Rate[Fiat, Coin] = if (that < this) that else this    
    def max(that:Rate[Fiat, Coin]):Rate[Fiat, Coin] = if (that > this) that else this    
    
  }
  def num[This <:Cur](cur:This) = new Numeric[Amt[This]] {// extends Numeric[This] //(implicit num:Numeric[BD]) { //(implicit num:Numeric[BD]) extends Numeric[BD]
    def fromInt(x: Int): Amt[This] = new Amt(x, cur)
    def minus(x: Amt[This],y: Amt[This]): Amt[This] = x - y
    def negate(x: Amt[This]): Amt[This] = -x
    def plus(x: Amt[This],y: Amt[This]): Amt[This] = x + y
    def times(x: Amt[This],y: Amt[This]): Amt[This] = ???
    def toDouble(x: Amt[This]): Double = x.amt.toDouble
    def toFloat(x: Amt[This]): Float = x.amt.toFloat
    def toInt(x: Amt[This]): Int = x.amt.toInt
    def toLong(x: Amt[This]): Long = x.amt.toLong
    // Members declared in scala.math.Ordering
    def compare(x: Amt[This],y: Amt[This]): Int = x.amt.compare(y.amt)
  }
  def num[Fiat <:Cur, Coin <: Cur](fiat:Fiat, coin:Coin) = new Numeric[Rate[Fiat, Coin]] {// extends Numeric[This] //(implicit num:Numeric[BD]) { //(implicit num:Numeric[BD]) extends Numeric[BD]
    // Members declared in scala.math.Ordering
    def fromInt(x: Int): Rate[Fiat,Coin] = new Rate(x, fiat, coin)
    def minus(x: Rate[Fiat,Coin],y: Rate[Fiat,Coin]): Rate[Fiat,Coin] = x - y
    def negate(x: Rate[Fiat,Coin]): Rate[Fiat,Coin] = ??? // negative rate not allowed!
    def plus(x: Rate[Fiat,Coin],y: Rate[Fiat,Coin]): Rate[Fiat,Coin] = x + y
    def times(x: Rate[Fiat,Coin],y: Rate[Fiat,Coin]): Rate[Fiat,Coin] = ??? 
    def toDouble(x: Rate[Fiat,Coin]): Double = x.rate.toDouble
    def toFloat(x: Rate[Fiat,Coin]): Float = x.rate.toFloat
    def toInt(x: Rate[Fiat,Coin]): Int = x.rate.toInt
    def toLong(x: Rate[Fiat,Coin]): Long = x.rate.toLong
    def compare(x: Rate[Fiat, Coin], y: Rate[Fiat, Coin]): Int = x.rate.compare(y.rate)
  }
  def unsigned(b:BD) = {
    if (b < 0) throw new Exception(s"Negative value not permitted for unsigned Amt: $b") else b
  }
  class UAmt[This <:Cur] private (cur:This)(amt:BD) extends Amt[This](amt, cur) {
    def this(amt:BD, cur:This) = this(cur)(unsigned(amt).setScale(cur.decimals, mode))
  }
  implicit def AmtToUAmt[C <: Cur](a:Amt[C]) = new UAmt(a.amt, a.cur)
  implicit def UAmtToAmt[C <: Cur](a:UAmt[C]) = new Amt(a.amt, a.cur)
  
  class Amt[This <:Cur] private (val cur:This)(val amt:BD) extends Serializable {
    // primary constructor is private
    // below secondary constructor is used to 'clean' the value before passing to primary constructor
    // by clean, we mean set the scale correctly
    def this(amt:BD, cur:This) = this(cur)(amt.setScale(cur.decimals, mode).underlying.stripTrailingZeros)
    def asUnsigned = new UAmt(amt, cur)
    // If amount is 10 BTC and rate is 1000 INR/BTC then below method will multiply the two to get INR
    // 1000 INR/BTC * 10 BTC = 10000 INR (i.e., 10 BTC @ rate of 1000 INR/BTC amounts 10000 INR)
    def *[Fiat <: Cur](r:Rate[Fiat, This]):Amt[Fiat] = new Amt((r.rate * amt).setScale(r.fiat.decimals, mode), r.fiat)
    // If amount is 10000 INR and rate is 1000 INR/BTC then below method will divide INR with rate to get BTC
    // 10000 INR / 1000 INR/BTC = 10 BTC (i.e., 10000 INR @ rate of 1000 INR/BTC amounts to 10 BTC) 
    def /[Coin <: Cur](r:Rate[This, Coin]):Amt[Coin] = new Amt((amt / r.rate).setScale(r.coin.decimals, mode), r.coin)
    // If primary (this) amount is 10000 INR and secondary (that) amount is 10 BTC, 
    // below method will output rate of 1000 INR/BTC
    def /[Coin <: Cur](that:Amt[Coin])(implicit ev: This =!= Coin):Rate[This, Coin] = new Rate(amt / that.amt, cur, that.cur)      

    def +(that:Amt[This]) = new Amt(amt + that.amt,cur)
    def *(fee:FeePercent[This]) = fee * this
    
    def unary_- = new Amt(-amt, cur)
    
    def -(that:Amt[This]) = new Amt(amt - that.amt, cur)
    def -(that:BigDecimal) = new Amt(amt - that, cur)
    def <(that:Amt[This]) = amt < that.amt
    def <(that:BigDecimal) = amt < that
    def >(that:Amt[This]) = amt > that.amt
    def >(that:BigDecimal) = amt > that
    def >= (that:Amt[This]) = amt >= that.amt
    def >= (that:BigDecimal) = amt >= that
    def <= (that:Amt[This]) = amt <= that.amt
    def <= (that:BigDecimal) = amt <= that
    def ===(that:Amt[This]) = amt == that.amt
    def ===(that:BigDecimal) = amt == that
    override def toString = amt.bigDecimal.toPlainString + " " +cur
    def toCurrency[That <: Cur](c:That)(implicit ev: This =!= That):Amt[That] = new Amt(amt, c)
    //def min(that:Amt[This]) = if (that < this) that else this    
    def min(that:Amt[This]):Amt[This] = if (that < this) that else this    
    @deprecated("Below is not used", "25 Nov 2017")
    def max(that:Amt[This]):Amt[This] = if (that > this) that else this    
    def compare(that:Amt[This]) = amt.compare(that.amt)        
  }
}