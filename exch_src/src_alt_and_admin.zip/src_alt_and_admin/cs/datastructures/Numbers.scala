
package cs.datastructures

import amit.common.Util._
import Exceptions._
import amit.common.json.JSONUtil._

object Numbers {
  type Time = Long // milli-seconds since some fixed date
  val MaxTime = Long.MaxValue
}