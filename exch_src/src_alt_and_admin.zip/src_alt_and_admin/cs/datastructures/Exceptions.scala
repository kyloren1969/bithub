
package cs.datastructures

import cs.datastructures.Currencies._
import cs.datastructures.Numbers._
//import cs.exchange.datastructures.Trades._
import cs.datastructures.OrderBook._
import cs.datastructures.Users._

object Exceptions {
  // users related
  case class WalletNotFoundException(usr:String, currency:Cur) extends Exception(s"UserID $usr not found in $currency wallet")
  case class UserNotFoundException(usr:String) extends Exception("UserID not found: "+usr)
  case class UserExistsException(usr:String) extends Exception("UserID already exists: "+usr)
  object EmptyUserException extends Exception("UserID cannot be empty")
  case class RefNotFoundException(r:String) extends Exception("Ref not found: "+r)
  case class UserMismatchException(u:String) extends Exception("UserID mismatch: "+u)  

  // general
  //case class ConversionException(d:Any) extends Exception("unable to convert to BigNum: "+d)
  case class InsufficientBalanceException[C <: Cur](userID:String,avbl:Amt[C],reqd:Amt[C]) 
    extends Exception(s"Insufficient balance for $userID. Required $reqd, available $avbl")
  //case class InternalException(m:String) extends Exception(m)
  case class MinimumAmountException[C <: Cur](variable:String, min:Amt[C], curr:Amt[C]) extends 
    Exception(s"Variable $variable must be >= $min. Currently $curr")
  case class MaximumAmountException[C <: Cur](variable:String, max:Amt[C], curr:Amt[C]) extends 
    Exception(s"Variable $variable must be <= $max. Currently $curr")
  case class InvalidAmountException[C <: Cur](variable:String, amt:Amt[C]) extends 
    Exception(s"Invalid amount: $amt for variable: $variable")
  case class InvalidMultipleException[C <: Cur](variable:String, multiple:Amt[C], amt:Amt[C]) extends 
    Exception(s"Variable $variable must be a multiple of $multiple. Currently $amt")
  
  // trade related
  object EmptyOrderException extends Exception("OrderID cannot be empty")
  object EmptyOrderBookException extends Exception("Orderbook is empty")
  def disabledException = throw OrderBookException("Trading is currently disabled. Please try again after some time.")
  case class OrderBookException(m:String) extends Exception(m)
  case class OrderNotFoundException(orderID:OrderID) extends Exception("Order not found: "+orderID)
  case class SelfBidException[C<: Cur, F<: Cur](rate:Rate[C, F], userID:UserID, other:Rate[C, F]) extends 
    Exception ("Cannot create bid for rate "+rate+". UserID already has lower or same rate ask of "+other)
  case class SelfAskException[C<: Cur, F<: Cur](rate:Rate[C, F], userID:UserID, other:Rate[C, F]) extends 
    Exception ("Cannot create ask for rate "+rate+". UserID already has higher or same rate bid of "+other)


}
