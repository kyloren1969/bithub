
package cs.wallet

import amit.common.Util._
import cs.datastructures.Currencies._
import mux.coin._
import mux.coin.Util._
import mux.db.BetterDB._
import mux.db.core.DataStructures._
import cs.datastructures.Transfers._
import cs.datastructures.Users._
import cs.datastructures.Numbers._
import cs.datastructures.Currencies._
import cs.datastructures.CommonDBCols._
import cs.util._
import cs.util.Common._
import cs.util.Transfers._
import cs.util.Users._
import cs.util.DBs._ // also for conversions between Rate and Amt to BigDecimal
import cs.datastructures.Exceptions._
import mux.db.core.FKDataStructures._
//import scala.collection.mutable.{Set => MSet}

object CryptoWalletUtil {
  // move below to CommonDBCols ?
  val seedHashCol = Col("seedHash", STR)  
  val seedIndexCol = Col("seedIndex", UINT)
  val isAddrAssignedCol = Col("isAddrAssigned", BOOL) // assigned to user?
  val isAddrUsedCol = Col("isAddrUsed", BOOL) // used in deposit?
  val salt = "^o(D2/Gql1qej0(6)TW),niAvA/0uF:EE#BR<3dsw)3j{F.<1hBB$kn5m6#^TOTIxlen2YBB;5OWtL`fW+CdY'71>KGu}1|Zz"  
  val topUpID = sha256Small("topUp")
  
  def getSeedHash(seed:String) = {    
    var v = sha256Bytes2Bytes(salt.getBytes)
    val s = seed.getBytes
    1 to 256 foreach {i =>
      v = sha256Bytes2Bytes(v ++ sha256Bytes2Bytes(s))
    }
    sha256Small(new String(v))
  }  
  @deprecated("This is insecure. To rewrite", "26 Feb 2018")
  def getPrvKey(seed:String, index:Int):BigInt = { 
    // to do: make it more secure. Check RFC
    BigInt(sha256Bytes2Bytes(seed.getBytes))+index
  }  
}

abstract class CryptoWallet[C <: Cur](val $exchangeWallet:ExchangeWallet[C]) extends CryptoWalletWithdrawUTXO[C]
