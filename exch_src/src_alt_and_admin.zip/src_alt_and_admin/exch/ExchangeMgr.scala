
package exch

import cs.datastructures.Users._
import cs.datastructures.Currencies._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Transfers._
import cs.datastructures.Wallets._
import cs.trade._
import cs.trade.util._
import cs.wallet.CoinInspector
import cs.wallet.CoinListener
import cs.wallet.CoinNotifier
import cs.wallet.CryptoWallet
import cs.wallet.ExchangeWallet
import sh.btc.BitcoinSNode
import cs.wallet.RPCNode
import mux.coin.Util._
import mux.coin.CoinTx
import mux.coin.Util
import mux.coin.bch.BitcoinCashSBlock
import mux.coin.bch.BitcoinCashSTx
import mux.coin.btc.BitcoinSBlock
import mux.coin.btc.BitcoinSTx
import sh.bch.BitcoinCashSNode
import sh.btc.BitcoinS
import sh.btc.BitcoinS._
import sh.ecc.Util._
import sh.net.Peer

object BTC_RPCNode extends RPCNode(new BitcoinSNode(BitcoinS.isMainNet))
object BCH_RPCNode extends RPCNode(new BitcoinCashSNode(BitcoinS.isMainNet))

object BTC extends Cur("BTC", 8, 20, 0.00001)
object BCH extends Cur("BCH", 8, 20, 0.00001)
object INR extends Cur("INR", 2, 20, 100)
object ETH extends Cur("ETH", 18, 20, 0.00001) // 1 ETH = 10^18 Wei
//  object ZEC extends Cur("ZEC", 8, 20, 0.00001)

private object BTC_Notifier extends CoinNotifier(BTC, BTC_RPCNode) {
  def toCoinBlock(b: sh.btc.DataStructures.Blk): mux.coin.CoinBlock = BitcoinSBlock(b)
  def toCoinTx(t: sh.btc.DataStructures.Tx): mux.coin.CoinTx = BitcoinSTx(t)    
}
private object BCH_Notifier extends CoinNotifier(BCH, BCH_RPCNode) {
  def toCoinBlock(b: sh.btc.DataStructures.Blk): mux.coin.CoinBlock = BitcoinCashSBlock(b)
  def toCoinTx(t: sh.btc.DataStructures.Tx): mux.coin.CoinTx = BitcoinCashSTx(t)    
}

object BTC_Inspector extends CoinInspector(BTC_Notifier)
object BCH_Inspector extends CoinInspector(BCH_Notifier)

object BTC_Listener extends CoinListener(BTC_Notifier)
object BCH_Listener extends CoinListener(BCH_Notifier)

object BTC_ExchangeWallet extends ExchangeWallet(BTC)
object BCH_ExchangeWallet extends ExchangeWallet(BCH)
object INR_ExchangeWallet extends ExchangeWallet(INR)
//  object ZEC_ExchangeWallet extends ExchangeWallet(ZEC)
//  object ETH_ExchangeWallet extends ExchangeWallet(ETH)

object INR_CryptoWallet extends CryptoWallet(BCH_ExchangeWallet) {
  val $minConf = 1
  val $maxFeePerWithdraw: BD = 10
  val $maxNoOfInputs: Int = 1
  val $maxNoOfOutputs: Int = 1
  val $minChangeAmount:BD = 0.01
  val $defaultFeePerByte: BD = 0.01
  val $maxFeePerByte: BD = 1
  val $minFeePerByte: BD = 0.001

  def $addAddressToWatch(address: String) = ???
  def isValidAddress(address: String) = ???
  protected def $addOnCoinReceive(onCoinReceive: OnCoinReceive): Unit = {}
  def $getAddress(prvKey: BigInt): String = ???
  def getWatchedAddresses = ???
  def $feePerByte:BD = ??? //FeeCalculator.feeSatoshisPerBytePrivate
  def $computeApproxSize(inAddrs:Seq[Spendable], outAddress:Seq[To]):Int = ???
  def $createSignedTx(insKeys:Seq[(Spendable, PrivKeyInt)], outs:Seq[To]):CoinTx = ???
  def $pushTxAndMonitor(tx:CoinTx):TxHash = ???
  def $estimateFeePerByte: Option[BD] = ???
}

private object WalletsMgr {
  
  BitcoinS.isMainNet = Util.isProdNet
  
  Util.debug = true
  Peer.debug = true
  BTC_Notifier.listenMode = true
  BCH_Notifier.listenMode = true
  BTC_RPCNode.$node.addOnBlkHandler("test", blk => println("blk: "+blk.header.hash))
  BTC_RPCNode.$node.addOnTxHandler("test", tx => println("tx: "+tx.txid))
  val wallets = Map(
    BTC.symbol -> BTC_ExchangeWallet,
    BCH.symbol -> BCH_ExchangeWallet,
    INR.symbol -> INR_ExchangeWallet    
  )
  
  val cryptoWallets = Map(
    BTC.symbol -> BTC_CryptoWallet,
    BCH.symbol -> BCH_CryptoWallet,    
    INR.symbol -> INR_CryptoWallet    
  )
  println
  println("Loaded following wallets")
  wallets foreach (w => println(w._1))

  def getWallet(cur:String):ExchangeWallet[_] = wallets.get(cur).getOrElse(throw new Exception(s"No such wallet $cur"))
  def getCryptoWallet(cur:String):CryptoWallet[_] = cryptoWallets.get(cur).getOrElse(throw new Exception(s"No such wallet $cur"))
}
import amit.common.Util._
import cs.datastructures.Users._
import cs.util.Common._

object ExchangeMgr {                   
  import WalletsMgr._

  val referralPercent = 10.0
  
  val markets = Array(
    getPairs(INR_ExchangeWallet, BTC_ExchangeWallet), //getPairs(BCH_CryptoWallet, BTC_CryptoWallet),
    getPairs(BCH_ExchangeWallet, BTC_ExchangeWallet) //getPairs(ETH_CryptoWallet, BTC_CryptoWallet), getPairs(ZEC_CryptoWallet, BTC_CryptoWallet)
  ).toMap

  println("Loaded following markets")
  markets foreach (m => println(m._1))

  private def getPairs[Fiat <: Cur, Coin <: Cur](fiatW:ExchangeWallet[Fiat], coinW:ExchangeWallet[Coin])(implicit ev: Fiat =!= Coin) = {
    val (fiat, coin) = (fiatW.$cur, coinW.$cur)
    val th = new TradeHandlers(fiat, coin)
    val tradeDB = new TradeDB(fiat, coin)
    val te = new TradeEngine(th, fiatW, coinW, new TradeRequests(fiatW, coinW, tradeDB), new TradeResults(fiatW, coinW, tradeDB, th, referralPercent, referralPercent), tradeDB, new MemOrderBook(fiat, coin))
    val lf = new LiveFeed (te, th){val qSize: Int = 100} // wrapper for above, hides lots of junk methods
    fiat.symbol+coin.symbol -> (th, te, lf)
  }
  
  private def noMarketError(market:String) = throw new Exception(s"No such market $market")
  def getTE(market:String):TradeEngine[_, _] = markets.get(market).map(_._2).getOrElse(noMarketError(market))
  def getTH(market:String):TradeHandlers[_, _] = markets.get(market).map(_._1).getOrElse(noMarketError(market))
  def getFeed(market:String):LiveFeed[_, _] = markets.get(market).map(_._3).getOrElse(noMarketError(market))
}

//class FeedWrapperOld[Fiat <:Cur, Coin <:Cur](f:LiveFeed[Fiat, Coin]) { // contains only methods we want to expose externally
//  import scala.collection.mutable.{Queue => MQ}
//  import cs.datastructures.OrderBook._
//  import cs.datastructures.Trades._
//  type RVT = RateVolTime[Fiat, Coin]
//  type Q = MQ[RVT] // mutable queue of RateVolTime 
//  type TQ = MQ[(RVT, OrdType)] // mutable queue of RateVolTime 
//  type FN = RVT => Unit // Function mapping RateVolTime to Unit
//  type FNU = () => Unit // Function mapping Unit to Unit
//  type HISTORY = History[Fiat, Coin]
//  type HISTORIES = List[HISTORY]
//
//  def startTime = f.startTime
//  def uptimeDays = uptimeHours / 24
//  def uptimeHours = uptimeMins / 60
//  def uptimeMins = uptimeSecs / 60
//  def uptimeSecs = uptimeMillis / 1000
//  def uptimeMillis = getTime - startTime
//  def aggrBids:Array[RateVol[Fiat, Coin]] = f.aggrBids
//  def aggrAsks:Array[RateVol[Fiat, Coin]] = f.aggrAsks
//  def buyTradeQ:Q = f.buyTradeQ
//  def sellTradeQ:Q = f.sellTradeQ
//  def bidQ:Q = f.bidQ
//  def askQ:Q = f.askQ
//  def tradeQ:TQ = f.tradeQ
//  
//  // the following keep details of the last trade information. Initially on program start, this is populated from db
//  // later on this information is kept updated using live data as the program runs
//  def lastTrade:TradeDetail[Fiat, Coin] = f.lastTrade
//  
//  def highestBidRate:Rate[Fiat, Coin] = f.highestBidRate
//  def lowestAskRate:Rate[Fiat, Coin] = f.lowestAskRate
//  
//  // following are aggregate functions. Initially these are 
//  def sum24HrFiatVol:FiatVol[Fiat, Coin] = f.sum24HrFiatVol
//  def avg24HrRate:Rate[Fiat, Coin] = f.avg24HrRate
//    
//  def max24HrRate:Rate[Fiat, Coin] = f.max24HrRate
//  def min24HrRate:Rate[Fiat, Coin] = f.min24HrRate
//  
//  def avg24HrRateDiff = f.avg24HrRateDiff
//  def max24HrRateDiff = f.max24HrRateDiff 
//  def min24HrRateDiff = f.min24HrRateDiff
//  def sum24HrFiatVolDiff = f.sum24HrFiatVolDiff
//  def highestBidDiff = f.highestBidDiff
//  def lowestAskDiff = f.lowestAskDiff
//  
//  // following are for charts anhd graphs
//  // def minutely:HISTORIES = f.minutely
//  def hourly:HISTORIES = f.hourly
//  def daily:HISTORIES = f.daily
//  def weekly:HISTORIES = f.weekly
//  def monthly:HISTORIES = f.monthly
//  def yearly:HISTORIES = f.yearly
//  def full:HISTORIES = f.full
//  
//  /////////////////////////////////////////////////////////////////////
//  //// live feed data end /////////////////////////////////////////////
//  /////////////////////////////////////////////////////////////////////
//  
//  /*
//   * for adding handlers
//   */
//  def addOnBid(fn:FN*) = f.addOnAsk(fn : _*)
//  def addOnAsk(fn:FN*) = f.addOnBid(fn : _*)
//  def addOnBuyTrade(fn:FN*) = f.addOnBuyTrade(fn : _*)
//  def addOnSellTrade(fn:FN*) = f.addOnSellTrade(fn : _*)
//  def addOnCancelAsk(fn:FN*) = f.addOnCancelAsk(fn : _*)
//  def addOnCancelBid(fn:FN*) = f.addOnCancelBid(fn : _*)
//  def addOnOBChange(fnu:FNU*) = f.addOnOBChange(fnu: _*)
//}
