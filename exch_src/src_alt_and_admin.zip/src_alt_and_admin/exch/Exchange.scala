
package exch

import cs.datastructures.Users._
import cs.datastructures.Currencies._
import cs.datastructures.OrderBook._
import cs.datastructures.Trades._
import cs.datastructures.Transfers._
import java.util.concurrent.atomic.AtomicInteger

object Exchange{
  import ExchangeMgr._
  def toDo = {
    Array(
      "Withdraws", // 1 day
      "Referrals", // 2 days
      "Migration of trades, orders, transfers (TE), referrals", // 1 day
      "Migration of addresses, user-wallet and cold-wallet data", // make separate "LegacyAddress" table? // 2 days
      "Archive older data from completed, canceled orders and trades", // 1 day
      "Create audit", // 1 day
      "Make key generation more secure", // 1/2 day
      "Note: No migration for KYC, Bank, Auth !!"      
    )
  }
  def getMarkets = markets.keys.toArray
  def createBid(market:String, userID:UserID, vol:BD, rate:BD) = getTE(market).createBid(userID, vol, rate, Ref.getOrigUserID(userID))
  def createAsk(market:String, userID:UserID, vol:BD, rate:BD) = getTE(market).createAsk(userID, vol, rate, Ref.getOrigUserID(userID))
  // in following two methods, userID is not needed but given for additional security check (userID should own orderID)
  def cancelBid(market:String, userID:UserID, bidID:OrderID) = getTE(market).cancelBid(userID, bidID)
  def cancelAsk(market:String, userID:UserID, askID:OrderID) = getTE(market).cancelAsk(userID, askID)
  def buyNow(market:String, userID:UserID, maxFiat:BD) = getTE(market).buyNow(userID, maxFiat, Ref.getOrigUserID(userID))   
  def sellNow(market:String, userID:UserID, maxFiat:BD) = getTE(market).sellNow(userID, maxFiat, Ref.getOrigUserID(userID))  
  def trades_disable(market:String):String = getTE(market).trades_disable  
  def trades_enable(market:String):String = getTE(market).trades_enable  
  def trades_isEnabled(market:String) = getTE(market).trades_isEnabled
  
  @deprecated("Does not have caching added yet.", "28 Nov 2017")
  def getAllTrades(market:String, to: Time,max: Int,offset: Long) = getTE(market).db_getAllTrades(to, max, offset) 
  ///////////////////////////////////  
  def getAllOpenBids(market:String, max:Int) = getTE(market).getAllOpenBids(max)
  def getAllOpenAsks(market:String, max:Int) = getTE(market).getAllOpenAsks(max)
  // Below sorted by RATE ! (Not time!!)
  def getApproxBuyFiat(market:String, vol:BD) = getTE(market).getApproxBuyFiat(vol)
  def getApproxSellFiat(market:String, vol:BD) = getTE(market).getApproxSellFiat(vol)
  def getApproxBuyCoin(market:String, fiat:BD) = getTE(market).getApproxBuyCoin(fiat)
  def getApproxSellCoin(market:String, fiat:BD) = getTE(market).getApproxSellCoin(fiat)
  // aggregate stuff, for live feed
  def getHighestBidRate(market:String) = getTE(market).getHighestBidRate
  def getHighestBidRateFor(market:String, userID:UserID) = getTE(market).getHighestBidRateFor(userID)
  def getLowestAskRate(market:String) = getTE(market).getLowestAskRate
  def getLowestAskRateFor(market:String, userID:UserID) = getTE(market).getLowestAskRateFor(userID)
  def getOpenAsks(market:String, userID:UserID, max: Int) = getTE(market).getOpenAsks(userID, max)
  def getOpenBids(market:String, userID:UserID, max: Int) = getTE(market).getOpenBids(userID, max)
  
  ///////////////////////////////////
    
  def getTopBids_RateVol(market:String, max:Int) = getTE(market).getTopBids_RateVol(max)
  def getTopAsks_RateVol(market:String, max:Int) = getTE(market).getTopAsks_RateVol(max)
  def getTotalSellVol(market:String) = getTE(market).getTotalSellVol 
  def getTotalBuyVol(market:String) = getTE(market).getTotalBuyVol
  ///////////////////////////////////
  def getOrigBid(market:String, userID:UserID, id:OrderID) = getTE(market).getOrigBid(userID, id)
  def getOrigAsk(market:String, userID:UserID, id:OrderID) = getTE(market).getOrigAsk(userID, id)
  def getClosedBids(market:String, userID:UserID, to:Time, max:Int, offset:Long) = getTE(market).getClosedBids(userID, to, max, offset)
  def getClosedAsks(market:String, userID:UserID, to:Time, max:Int, offset:Long) = getTE(market).getClosedAsks(userID, to, max, offset)
  def getClosedBid(market:String, userID:UserID, id:OrderID) = getTE(market).getClosedBid(userID, id)
  def getClosedAsk(market:String, userID:UserID, id:OrderID) = getTE(market).getClosedAsk(userID, id)
  def getCanceledBids(market:String, userID:UserID, to:Time, max:Int, offset:Long) = getTE(market).getCanceledBids(userID, to, max, offset)
  def getCanceledAsks(market:String, userID:UserID, to:Time, max:Int, offset:Long) = getTE(market).getCanceledAsks(userID, to, max, offset)
  
  def getLockedAmtAsks(market:String, userID:String) = getTE(market).getLockedAmtAsks(userID)
  def getLockedAmtBids(market:String, userID:String) = getTE(market).getLockedAmtBids(userID)

  ///////
  private val $int = new AtomicInteger(0)
  def addOnOBChange(market:String, f:Unit => Unit) = getTH(market).obChangeHandler.addOn($int.incrementAndGet, f)
  def addOnTrade(market:String, f: SimpleTradeDetail => Unit) = getTH(market).addOnTrade($int.incrementAndGet, f)
  def addOnCreateBid(market:String, f: SimpleOrder => Unit) = getTH(market).addOnCreateBid($int.incrementAndGet, f)
  def addOnCreateAsk(market:String, f: SimpleOrder => Unit) = getTH(market).addOnCreateAsk($int.incrementAndGet, f)
  def addOnCancelBid(market:String, f: SimpleOrder => Unit) = getTH(market).addOnCancelBid($int.incrementAndGet, f)
  def addOnCancelAsk(market:String, f: SimpleOrder => Unit) = getTH(market).addOnCancelAsk($int.incrementAndGet, f)
  def addOnCloseBid(market:String, f:SimpleClosedOrder => Unit) = getTH(market).addOnCloseBid($int.incrementAndGet, f)
  def addOnCloseAsk(market:String, f:SimpleClosedOrder => Unit) = getTH(market).addOnCloseAsk($int.incrementAndGet, f)
  
  def getTicker:Array[TickerData] = getMarkets.map{market =>
    val feed = getFeed(market)
    
    TickerData(
      market, 
      feed.max24HrRate.rate, 
      feed.min24HrRate.rate, 
      feed.avg24HrRate.rate,
      feed.lowestAskRate.rate, 
      feed.highestBidRate.rate,
      feed.last24HrData.sumFiatVol.vol.amt,
      feed.last24HrData.sumFiatVol.fiat.amt      
    )
  }

}
