package exch

import mux.db.config.TraitDBConfig
import mux.db.core.DataStructures.Col
import amit.common.Util._
import cs.datastructures.Users._
import mux.db.BetterDB._
import amit.common.file.TraitFilePropertyReader
import cs.datastructures.CommonDBCols._
import cs.util.DBs._

object Ref {

  val $newUserIDCol = Col("newUserID", STR)
  val $refIDCol = Col("refID", STR)
  protected implicit val $dbconfig:TraitDBConfig = new TraitDBConfig with TraitFilePropertyReader{
    val propertyFile = s"refDB.properties"
    val dbname = read ("dbname", s"refDB")
    val dbuser = read ("dbuser", "cs")
    val dbpass = read ("dbpass", "eipoxj4i4xm4lmw")
    val dbhost = read ("dbhost", "localhost")
    //val dbms = read ("dbms", "postgresql")
    val dbms = read ("dbms", "h2")
    val connTimeOut = read("dbConnTimeOut", 2000)
    val usePool = read("usePool", true)
    val configSource = "file:"+propertyFile
  }
  val $refDB = Tab.withName("ref").withConfig($dbconfig).withCols(userIDCol, $refIDCol, timeCol).withPriKey($refIDCol)
  val $succRefDB = Tab.withName("succRef").withConfig($dbconfig).withCols(userIDCol, $newUserIDCol, $refIDCol, timeCol).withPriKey($newUserIDCol)
  
  def generateRef(userID:String) = {
    val refID = getPriKeyID($refDB, 8)
    usingCount($refDB.insert(userID, refID, getTime), "Unable to insert unique refID")
    refID
  }
  def addCustomRefID(userID:String, refID:String) = {
    if ($refDB.exists($refIDCol === refID)) throw new Exception("RefID not available")
    usingCount($refDB.insert(userID, refID, getTime), "Unable to insert unique refID")
    refID
  }
  def addVerifiedUserRef(refID:String, newUserID:UserID) = {
    $refDB.select(userIDCol).where($refIDCol === refID).firstAsT[String].headOption.map{userID =>
      $succRefDB.insert(userID, newUserID, refID, getTime)
    }
  }
  def getOrigUserID(newUserID:UserID):RefUserID = {
    $refDB.select(userIDCol).where($newUserIDCol === newUserID).firstAsT[UserID].headOption
  }
}
